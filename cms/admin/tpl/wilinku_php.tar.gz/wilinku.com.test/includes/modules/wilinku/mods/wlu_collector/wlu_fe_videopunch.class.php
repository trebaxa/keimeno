<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_videopunch_class extends wlu_colmaster_class {

    function __construct() {
        parent::__construct();
        $this->TCR = new tc_request_class($this);
        $this->ADHOCV = new wlu_adhocvideo_class();
        $this->YTV = new wlu_yt_class();
        $this->VI = new wlu_vimeo_class();
        $this->COMMENTS = new wlu_comments_class();
        $this->allowed_countries = array();
    }

    function get_allowed_countries() {
        // get allowed countries
        $this->allowed_countries = array();
        if ($_SESSION['WLU']['tree']['filter'] == 'country') {
            $this->allowed_countries = array((int)$_SESSION['WLU']['selected']['countryid']);
        }
        else
            if ($_SESSION['WLU']['tree']['filter'] == 'region') {
                foreach ($this->countries as $key => $row) {
                    if ($row['REGIONID'] == $_SESSION['WLU']['selected']['regionid']) {
                        $this->allowed_countries[] = $row['COUNTRYID'];
                    }
                }
            }
            else
                if ($_SESSION['WLU']['tree']['filter'] == 'continent') {
                    foreach ($this->countries as $key => $row) {
                        if ($row['CONID'] == $_SESSION['WLU']['selected']['conid']) {
                            $this->allowed_countries[] = $row['COUNTRYID'];
                        }
                    }
                }
                else {
                    foreach ($this->countries as $key => $row) {
                        $this->allowed_countries[] = $row['COUNTRYID'];
                    }
                }
    }

    function init($is_ajax_call = false) {
        $this->selected['countryid'] = (int)$_SESSION['WLU']['selected']['countryid'];
        $this->load_crc_tab();
        $this->get_allowed_countries();
        if (!$is_ajax_call) {
            $this->init_level1();
        }
        if ($this->TCR->REQUEST['cid'] > 0) {
            $this->set_category($this->TCR->REQUEST['cid']);
        }
        $this->selected['cid'] = (int)$_SESSION['WLU']['selected']['cid'];
        $this->selected['level1'] = (int)$_SESSION['WLU']['selected']['level1'];
        if (!$is_ajax_call) {
            $this->load_related_links();
        }
        $this->VP['faultform'] = false;
    }

    function load_crc_tab() {
        $this->crc_tab = array();
        $sql = "SELECT *,C.id COUNTRYID, CO.id AS CONID, R.id AS REGIONID FROM
	" . TBL_CMS_LAND . " C
	, " . TBL_CMS_LANDCONTINET . " CO
	, " . TBL_CMS_LANDREGIONS . " R
	WHERE R.lr_continet_id=CO.id
	AND C.region_id=R.id
	";
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->crc_tab[$row['lr_continet_id']][$row['region_id']][$row['COUNTRYID']] = $row;
            $this->continents[$row['lr_continet_id']] = $row;
            $this->regions[$row['region_id']] = $row;
            $this->countries[$row['COUNTRYID']] = $row;
            if ($this->selected['countryid'] == $row['COUNTRYID']) {
                $this->VP['location']['country'] = $row;
            }
        }
        if ($this->selected['countryid'] > 0) {
            $this->VP['location']['region'] = $this->regions[$this->VP['location']['country']['region_id']];
            $this->VP['location']['continent'] = $this->continents[$this->VP['location']['country']['lr_continet_id']];
            $_SESSION['WLU']['selected']['conid'] = $this->VP['location']['country']['lr_continet_id'];
            $_SESSION['WLU']['selected']['regionid'] = $this->VP['location']['country']['region_id'];
        }
        else {
            if ($_SESSION['WLU']['selected']['regionid'] > 0) {
                $this->VP['location']['region'] = $this->regions[$_SESSION['WLU']['selected']['regionid']];
            }
            if ($_SESSION['WLU']['selected']['conid'] > 0) {
                $this->VP['location']['continent'] = $this->continents[$_SESSION['WLU']['selected']['conid']];
            }
        }
    }


    function load_start_page_settings() {
        $this->load_most_recent();
    }


    function load_most_recent() {
        $this->load_videos_ordered('yt_apptime', $this->gbl_config['wlu_startpage_vpcount'], $this->VP['sp_videos']);
    }

    function load_most_viewed() {
        $this->load_videos_ordered('yt_views', $this->gbl_config['wlu_startpage_vpcount'], $this->VP['sp_videos']);
    }

    function load_latest() {
        $this->load_videos_ordered('yt_upload_date', $this->gbl_config['wlu_startpage_vpcount'], $this->VP['latest_videos']);
    }

    function add_video_counts(&$v_obj) {
        $v_obj['video_count'] = getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, "vc_videoid", "vc_countryid=" . $v_obj['COUNTRYID']);
    }


    function init_level1() {
        $this->load_level1_menu();
        if ($this->TCR->REQUEST['level1'] > 0) {
            $this->set_level1($this->TCR->REQUEST['level1']);
        }
        else {
            $this->selected['level1'] = (int)$_SESSION['WLU']['selected']['level1'];
        }
    }

    function set_level1($id) {
        $_SESSION['WLU']['selected']['level1'] = $this->selected['level1'] = (int)$id;
    }

    function unset_level1() {
        unset($_SESSION['WLU']['selected']['level1']);
        unset($this->selected['level1']);
    }

    function unset_cid() {
        unset($_SESSION['WLU']['selected']['cid']);
        unset($this->selected['cid']);
    }

    function cmd_load_level1() {
        // load cat. tree
        $this->set_level1($this->TCR->REQUEST['level1']);
        $this->load_vptree_by_parent($this->selected['level1']);
        // Videos load
        $this->load_videos($this->selected['level1'], 0); // cid , start
        $this->unset_cid();
        $this->set_category($this->selected['level1']);
        $this->VP['vpsection'] = 'videotable';
    }

    function cmd_default() {
        $this->unset_cid();
        $this->unset_level1();
        $this->load_videos(0, 0); // cid , start
        $this->VP['vpsection'] = 'videotable';
    }


    function set_video_feoptions(&$row) {
        #	$row['localthumb'] = parent::gen_thumbnail($row['yt_thumbnailurl'],$row['yt_videoid']);
        $row['lastexec_datetime'] = ($row['yp_lastexec'] > 0) ? date('d.m.Y H:i:s', $row['yp_lastexec']) : '-';
        $row['detaillink'] = $this->gen_videodeatil_link($row, $this->set_crc_for_link());
        $row['videotags'] = explode(';', $row['yt_videotags']);
        $row['lastupdate'] = myDate('M/Y', $row['yt_lastupdate']);
        if (is_array($this->VP['lng_iso_table'])) {
            $row['yt_wlulng_name'] = $this->VP['lng_iso_table'][$row['yt_wlulng']]['lname'];
        }
        // Load Rating
        require_once (CMS_ROOT . "includes/rating.class.php");
        $RATING = new rating_class();
        $row['averageStars'] = $RATING->CalculateAverageRating($row['VID'], TBL_CMS_WLU_RATING);
        $R = $this->db->query_first("SELECT COUNT(*) AS VCOUNT FROM " . TBL_CMS_WLU_RATING . " WHERE ra_id='" . $row['VID'] . "'");
        $row['rating_votes'] = $R['VCOUNT'];
        unset($RATING);


    }

    function load_vptree_by_parent($parent, $target = 'vptree') {
        $_SESSION['WLU']['treestart_next'] = 0;
        $_SESSION['WLU']['treestart_previous'] = 0;
        $parent = (int)$parent;
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'approval_col' => 'ytc_approval', 'visible_col' =>
            'ytc_visible', ));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_name", $parent, 0, -1);
        #echoarr($this->allowed_countries);
        $this->remove_countries_by_list(&$menutree, $this->allowed_countries);
        $menutree->build_flat_obj_arr($menutree->menu_array, $flat_menu_arr);
        $new_arr = array();
        $counter = 0;
        $this->set_menu_opt($menutree->menu_array, $new_arr, $flat_menu_arr, $counter, $this->set_crc_for_link());
        $this->merge_subcounts($new_arr, &$vptree, $flat_menu_arr);
        $this->VP[$target] = $vptree;
        unset($menutree);
    }

    function validate_country_relationship($cid) {
        $cid = (int)$cid;
        if ($cid == 0 || $this->selected['cid'] == 0 || $this->selected['countryid'] == 0)
            return true;
        $cat_countries = array();
        $result = $this->db->query("SELECT cm_countryid FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE cm_cid=" . (int)$cid);
        while ($row = $this->db->fetch_array_names($result)) {
            $cat_countries[] = $row['cm_countryid'];
        }
        return in_array($this->selected['countryid'], $cat_countries);
    }

    function set_category($cid) {
        $_SESSION['WLU']['selected']['cid'] = $this->selected['cid'] = (int)$cid;
        $this->selected['catobj'] = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$cid);
    }

    function cmd_loadvideos() {
        $cid = (int)$this->TCR->REQUEST['cid'];
        if (!$this->validate_country_relationship($cid)) {
            unset($_SESSION['WLU']['selected']['cid']);
            unset($_SESSION['WLU']['selected']['level1']);
            $this->TCR->redirecto = VP_HTML_SITE;
            return;
        }
        $this->set_category($cid);
        $this->set_level1_by_cid($this->selected['cid']);
        if ($this->selected['cid'] > 0)
            $this->load_vptree_by_parent($this->selected['level1']);
        $this->load_videos($cid, (int)$this->TCR->REQUEST['start']);
        $this->VP['vpsection'] = 'videotable';
    }

    function get_videocount_by_location($cid) {
        $cid = (int)$cid;
        $countryid = (int)$_SESSION['WLU']['selected']['countryid'];
        if ($countryid > 0) {
            $sql_addon = "VC.vc_countryid=" . (int)$countryid;
        }
        else
            if ($countryid == 0 && $_SESSION['WLU']['selected']['regionid'] > 0) {
                $sql_addon .= (($sql_addon != "") ? " OR " : "") . "VC.vc_regionid=" . (int)$_SESSION['WLU']['selected']['regionid'];
            }
            else
                if ($countryid == 0 && $_SESSION['WLU']['selected']['regionid'] == 0 && $_SESSION['WLU']['selected']['conid'] > 0) {

                    $sql_addon .= (($sql_addon != "") ? " OR " : "") . "VC.vc_contid=" . (int)$_SESSION['WLU']['selected']['conid'];
                }
                else {
                    $sql_addon = "VC.vc_countryid>0";
                }
                $sql = "SELECT COUNT(V.yt_videoid) AS VCOUNT
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_WLU_VCATMATRIX . " VCAT
	WHERE 1
    AND VC.vc_videoid=V.yt_videoid   
	AND V.yt_blocked=0
	AND C.id=" . $cid . "
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
    AND (" . $sql_addon . ") 
	GROUP BY C.id
	";

        $VIDEOCOUNT = $this->db->query_first($sql);
        return (int)$VIDEOCOUNT['VCOUNT'];
    }

    function load_videos_ordered($orderby = 'yt_views', $limit = 100, &$videos = array()) {
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
            TBL_CMS_WLU_VCATMATRIX . " VCAT,
	" . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND L.region_id=R.id
	AND CON.id=R.lr_continet_id
	AND V.yt_blocked=0
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	" . (($_SESSION['WLU']['selected']['countryid'] > 0) ? " AND L.id=" . (int)$_SESSION['WLU']['selected']['countryid'] : "") . "
	" . (($_SESSION['WLU']['selected']['regionid'] > 0) ? " AND L.region_id=" . (int)$_SESSION['WLU']['selected']['regionid'] : "") . "
	" . (($_SESSION['WLU']['selected']['conid'] > 0) ? " AND CON.id=" . (int)$_SESSION['WLU']['selected']['conid'] : "") . "
	GROUP BY V.yt_videoid
	ORDER BY V." . $orderby . " DESC
	LIMIT " . (int)$limit;
        $videos = array();
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $this->set_video_feoptions($row);
            $videos[$row['VID']] = $row;
        }
        $sql = "SELECT COUNT(yt_videoid) AS VCOUNT
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
            TBL_CMS_WLU_VCATMATRIX . " VCAT
	," . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND L.region_id=R.id
	AND CON.id=R.lr_continet_id		
	AND V.yt_blocked=0
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	" . (($_SESSION['WLU']['selected']['countryid'] > 0) ? " AND L.id=" . (int)$_SESSION['WLU']['selected']['countryid'] : "") . "
	" . (($_SESSION['WLU']['selected']['regionid'] > 0) ? " AND L.region_id=" . (int)$_SESSION['WLU']['selected']['regionid'] : "") . "
	" . (($_SESSION['WLU']['selected']['conid'] > 0) ? " AND CON.id=" . (int)$_SESSION['WLU']['selected']['conid'] : "") . "

	GROUP BY V.yt_videoid
	ORDER BY V." . $orderby . " DESC
	";
        $VC = $this->db->query_first($sql);
        return array('total_count' => $VC['VCOUNT']);
        #return (array)$videos;
    }

    function search_by_tag($tag, $start, $limit) {
        $SW = new wlu_vsearch_class();
        $video_ids = $SW->search($tag, $start, $limit);
        unset($SW);
        if (is_array($video_ids['ids'])) {
            foreach ($video_ids['ids'] as $vid) {
                $sql_addon .= (($sql_addon != "") ? " OR " : "") . " yt_videoid='" . $vid . "' ";
            }
        }
        $videos = array();
        if (count($video_ids['ids']) > 0) {
            $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID
		FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
                TBL_CMS_WLU_VCATMATRIX . " VCAT	," . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R
		WHERE  VC.vc_videoid=V.yt_videoid
		AND VC.vc_countryid=L.id
        AND L.region_id=R.id
        AND CON.id=R.lr_continet_id	
		AND V.yt_blocked=0
		AND C.id=VCAT.vcm_cid
		AND V.yt_videoid=VCAT.vcm_videoid
		" . (($sql_addon != "") ? " AND (" . $sql_addon . ") " : "") . "
	    " . (($_SESSION['WLU']['selected']['countryid'] > 0) ? " AND L.id=" . (int)$_SESSION['WLU']['selected']['countryid'] : "") . "
	    " . (($_SESSION['WLU']['selected']['regionid'] > 0) ? " AND L.region_id=" . (int)$_SESSION['WLU']['selected']['regionid'] : "") . "
	    " . (($_SESSION['WLU']['selected']['conid'] > 0) ? " AND CON.id=" . (int)$_SESSION['WLU']['selected']['conid'] : "") . "
        
		GROUP BY V.yt_videoid
		ORDER BY V.yt_lastupdate DESC
		LIMIT 0," . $limit;
            $result = $this->db->query($sql);
            while ($row = $this->db->fetch_array_names($result)) {
                $this->set_video_options($row);
                $this->set_video_feoptions($row);
                $videos[$row['VID']] = $row;
            }
            return $videos;
            unset($SW);
        }
    }

    function load_videos_by_cat($cid, &$videos, $start = 0, $orderby = 'yt_views', $count = 0) {
        $childs = $this->build_flatarr_of_children($cid);
        $count = ($count == 0) ? (int)$this->gbl_config['wlu_videosperpage'] : (int)$count;
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
            TBL_CMS_WLU_VCATMATRIX . " VCAT
	," . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R, " . TBL_CMS_WLU_COUNTRY_TO_CAT . " CC
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND L.region_id=R.id
	AND CON.id=R.lr_continet_id	
	AND V.yt_blocked=0
	AND (" . $childs['sql_cid_filter'] . ")
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid 
    AND CC.cm_countryid=VC.vc_countryid
    AND CC.cm_cid=C.id
	" . (($_SESSION['WLU']['selected']['countryid'] > 0) ? " AND L.id=" . (int)$_SESSION['WLU']['selected']['countryid'] : "") . "
	" . (($_SESSION['WLU']['selected']['regionid'] > 0) ? " AND L.region_id=" . (int)$_SESSION['WLU']['selected']['regionid'] : "") . "
	" . (($_SESSION['WLU']['selected']['conid'] > 0) ? " AND CON.id=" . (int)$_SESSION['WLU']['selected']['conid'] : "") . "
	GROUP BY V.yt_videoid
	ORDER BY V." . $orderby . " DESC
	LIMIT " . $start . "," . $count;
        #echo $sql;
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $this->set_video_feoptions($row);
            $videos[$row['VID']] = $row;
        }
        #	echo count($videos);
        $sql = "SELECT COUNT(yt_videoid) AS VCOUNT
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
            TBL_CMS_WLU_VCATMATRIX . " VCAT
	," . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R, " . TBL_CMS_WLU_COUNTRY_TO_CAT . " CC
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND L.region_id=R.id
	AND CON.id=R.lr_continet_id		
	AND V.yt_blocked=0
	AND (" . $childs['sql_cid_filter'] . ")
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
    AND CC.cm_countryid=VC.vc_countryid
    AND CC.cm_cid=C.id    
	" . (($_SESSION['WLU']['selected']['countryid'] > 0) ? " AND L.id=" . (int)$_SESSION['WLU']['selected']['countryid'] : "") . "
	" . (($_SESSION['WLU']['selected']['regionid'] > 0) ? " AND L.region_id=" . (int)$_SESSION['WLU']['selected']['regionid'] : "") . "
	" . (($_SESSION['WLU']['selected']['conid'] > 0) ? " AND CON.id=" . (int)$_SESSION['WLU']['selected']['conid'] : "") . "
	";
        #	echo $sql;
        $VC = $this->db->query_first($sql);
        return array('total_count' => $VC['VCOUNT']);
    }


    function gen_paging_link($start, $toadd = '') {
        $link = $this->gen_vpcat_link($this->selected['catobj'], $this->set_crc_for_link());
        # VP_HTML_SITE
        # return  $link . '?start=' . (int)$start .$toadd;
        return $this->modify_url($link . '?start=' . (int)$start, $this->parse_query($toadd));
    }

    function genPaging($total, $ovStart, $link, $max_per_page) {
        $start = (isset($ovStart)) ? abs((int)$ovStart) : 0;
        $total_pages = ceil($total / $max_per_page);
        $akt_page = round($start / $max_per_page) + 1;
        if ($total_pages > 0)
            $akt_pages = $akt_page . '/' . $total_pages;
        $start = ($start > $total) ? $total - $max_per_page : $start;
        $next_pages_arr = $back_pages_arr = array();
        if ($start > 0)
            $newStartBack = ($start - $max_per_page < 0) ? 0 : ($start - $max_per_page);
        if ($start > 0) {
            for ($i = $this->gbl_config['wlu_pro_num_prepages'] - 1; $i >= 0; $i--) {
                if ($newStartBack - ($i * $max_per_page) >= 0) {
                    $back_pages_arr[] = array('link' => $this->gen_paging_link(($newStartBack - ($i * $max_per_page)), $link), 'index' => ($akt_page - $i - 1));
                }
            }
        }
        if ($start + $max_per_page < $total) {
            $newStart = $start + $max_per_page;
            for ($i = 0; $i < $this->gbl_config['wlu_pro_num_prepages']; $i++) {
                if ($newStart + ($i * $max_per_page) < $total) {
                    $next_pages_arr[] = array('link' => $this->gen_paging_link(($newStart + ($i * $max_per_page)), $link), 'index' => ($akt_page + $i + 1));
                }
            }
        }
        $_paging['start'] = $start;
        $_paging['total_pages'] = $total_pages;
        $_paging['startback'] = $newStartBack;
        $_paging['newstart'] = $newStart;
        $_paging['base_link'] = $this->modify_url($_SERVER['PHP_SELF'], $this->parse_query($link));
        $_paging['back_pages'] = $back_pages_arr;
        $_paging['akt_page'] = $akt_page;
        $_paging['next_pages'] = $next_pages_arr;
        $_paging['backlink'] = $this->gen_paging_link($newStartBack, $link);
        $_paging['nextlink'] = $this->gen_paging_link($newStart, $link);
        $_paging['count_total'] = $total;
        $this->VP['paging'] = $_paging;
    }

    function add_related_cats_to_video(&$V) {
        $V['related_cids'] = array();
        $V['related_categories'] = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_videoid='" . $V['VID'] . "'");
        while ($row = $this->db->fetch_array_names($result)) {
            $V['related_categories'][] = $row;
            $V['related_cids'][] = $row['vcm_cid'];
        }
    }

    function set_level1_by_cid($cid) {
        $cid = (int)$cid;
        if ($cid > 0) {
            //LEVEL 1 Bestimmung
            $L = $this->db->query_first("SELECT ytc_parent,id FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $cid);
            while ($L['ytc_parent'] > 0 && $L['id'] > 0) {
                $L = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$L['ytc_parent']);
            }
            $this->set_level1($L['id']);
        }
    }

    function set_level1_by_video($V) {
        //LEVEL 1 Bestimmung
        $L = array('ytc_parent' => $V['ytc_parent'], 'id' => $V['CID']);
        while ($L['ytc_parent'] > 0 && $L['id'] > 0) {
            $L = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$L['ytc_parent']);
        }
        $this->set_level1($L['id']);
    }

    function load_level1_menu() {
        $this->load_vptree_by_parent(0, 'vptreelevel1');
        if (count($this->VP['vptreelevel1']) > 0) {
            foreach ($this->VP['vptreelevel1'] as $key => $cat) {
                if ($cat['video_subcount_by_location'] == 0)
                    unset($this->VP['vptreelevel1'][$key]);
            }
        }
    }

    function load_samepic_videos($cid) {
        return $this->load_videos($cid, 0, $this->gbl_config['wlu_samepick_count']); // same pic videos
    }

    function cmd_showplayer() {
        $this->VP['lng_iso_table'] = $this->load_iso_table();
        $vid = strval(trim($this->TCR->REQUEST['vid']));

        // Category verify and set
        if ($this->selected['level1'] == $_SESSION['WLU']['selected']['cid']) { // wenn nur level1
            $this->unset_cid();
        }
        if ($_SESSION['WLU']['selected']['cid'] > 0) {
            $V = $this->load_single_video($vid, 0, $_SESSION['WLU']['selected']['cid']);
        }
        if (empty($V['VID']) || $_SESSION['WLU']['selected']['cid'] == 0) {
            $V = $this->load_single_video($vid);
        }
        if (empty($V['VID'])) {
            $this->TCR->redirecto = VP_HTML_SITE;
            return;
        }
        // validate SESSION category
        $this->add_related_cats_to_video($V);
        if (!in_array($_SESSION['WLU']['selected']['cid'], $V['related_cids']) && $V['CID'] > 0) {
            $this->set_category($V['CID']);
        }
        $V['CID'] = $_SESSION['WLU']['selected']['cid'];


        // View Counter
        if ((int)$_SESSION['WLU']['viewcounter'][$_SERVER['REMOTE_ADDR']][$vid] == 0) {
            $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_views=yt_views+1 WHERE yt_videoid='" . $vid . "'");
            $V['yt_views']++;
            $_SESSION['WLU']['viewcounter'][$_SERVER['REMOTE_ADDR']][$vid]++;
        }


        $this->load_crc_tab();
        $this->get_allowed_countries();
        $this->set_level1_by_video($V);
        $this->load_level1_menu();
        $this->load_vptree_by_parent($this->selected['level1']);
        $this->set_video_options($V);
        $this->set_video_feoptions($V);

        //Comments
        $VC = $this->COMMENTS->load_comments($vid, $V);
        $V['comments'] = $VC['comments'];
        $V['comments_count'] = $VC['comments_count'];

        // BreadCrumb
        $this->VP['cat_bread_crumb'] = array();
        $this->create_path_with_links($this->selected['cid'], $this->VP['cat_bread_crumb'], $this->selected['countryid'], $this->countries[$this->selected['countryid']]['land']);
        $this->VP['cat_bread_crumb'] = array_reverse($this->VP['cat_bread_crumb']);

        $this->VP['video'] = $V;

        // same pick videos
        if ((int)$this->TCR->REQUEST['relatedvideos'] == 0) {
            # $this->load_videos($V['CID'], 0, $this->gbl_config['wlu_samepick_count']); // same pic videos
            $this->VP['video_list'] = $this->load_samepic_videos($V['CID']);
        }

        //find next/previous samepic video
        if ((int)$this->TCR->REQUEST['relatedvideos'] == 1) {
            if (is_array($this->VP['video_list']))
                $this->VP['video']['next_video'] = array_shift($this->VP['video_list']);
        }
        else {
            $found = false;
            if (is_array($this->VP['video_list'])) {
                foreach ($this->VP['video_list'] as $key => $vrow) {
                    if ($found == true) {
                        $this->VP['video']['next_video'] = $this->VP['video_list'][$key];
                        break;
                    }
                    if ($key == $vid) {
                        $found = true;
                        $this->VP['video']['previous_video'] = (array )$this->VP['video_list'][$last_index];
                    }
                    $last_index = $key;
                }
            }
        }


        // related videos
        $this->load_related_videos($V);
        if ((int)$this->TCR->REQUEST['relatedvideos'] == 1) {
            $this->VP['video_list'] = $this->VP['related_videos'];
        }

        if ((int)$this->TCR->REQUEST['relatedvideos'] == 0) {
            if (is_array($this->VP['related_videos']))
                $this->VP['video']['next_related_video'] = array_shift($this->VP['related_videos']);
        }
        else {
            //find next/previous related video
            $found = false;
            if (is_array($this->VP['related_videos'])) {
                foreach ($this->VP['related_videos'] as $key => $vrow) {
                    if ($found == true) {
                        $this->VP['video']['next_related_video'] = $this->VP['related_videos'][$key];
                        #echoarr($this->VP['video']['next_related_video']);
                        break;
                    }
                    if ($key == $vid) {
                        $found = true;
                        $this->VP['video']['previous_related_video'] = (array )$this->VP['related_videos'][$last_index];
                    }
                    $last_index = $key;
                }
            }
        }
        // Autoplay
        if ($this->TCR->REQUEST['startautoplay'] >= 1) {
            $_SESSION['WLU']['selected']['startautoplay'] = (int)$this->TCR->REQUEST['startautoplay'];
        }

        //Meta
        $this->meta_title = $V['yt_videotitle'];
        $this->meta_description = $V['yt_videodescription'];
        $this->meta_keywords = implode(',', $this->trim_array(explode(';', $V['yt_videotags'])));

        // Load Category
        $this->VP['CATOBJ'] = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$V['CID']);
    }


    function load_related_videos($VIDEO_OBJ) {
        $childs = $this->build_flatarr_of_children($VIDEO_OBJ['ytc_parent']);
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
            TBL_CMS_WLU_VCATMATRIX . " VCAT
	," . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R, " . TBL_CMS_WLU_COUNTRY_TO_CAT . " CC
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND L.region_id=R.id
	AND CON.id=R.lr_continet_id	
	AND V.yt_blocked=0
	AND (" . $childs['sql_cid_filter'] . ")
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid 
    AND CC.cm_countryid=VC.vc_countryid
    AND CC.cm_cid=C.id
	" . (($_SESSION['WLU']['selected']['countryid'] > 0) ? " AND L.id=" . (int)$_SESSION['WLU']['selected']['countryid'] : "") . "
	" . (($_SESSION['WLU']['selected']['regionid'] > 0) ? " AND L.region_id=" . (int)$_SESSION['WLU']['selected']['regionid'] : "") . "
	" . (($_SESSION['WLU']['selected']['conid'] > 0) ? " AND CON.id=" . (int)$_SESSION['WLU']['selected']['conid'] : "") . "
	GROUP BY V.yt_videoid
	ORDER BY V.yt_apptime DESC
	LIMIT 0," . (int)$this->gbl_config['wlu_rlv_count'];
        #echo $sql;
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $this->set_video_feoptions($row);
            $videos[$row['VID']] = $row;
        }
        #	echo count($videos);

        $this->VP['related_videos'] = $videos;
        return $this->VP['related_videos'];
    }

    function load_related_videos_OLD($VIDEO_OBJ) {
        $tags = explode(';', $VIDEO_OBJ['yt_videotags']);
        if (count($tags) == 0) {
            $tags = explode(' ', $VIDEO_OBJ['yt_videotitle']);
        }
        $max = $this->gbl_config['wlu_tagcount_realtedvideos'];
        $all_videos = array();
        if (count($tags) < 3)
            $max = count($tags);
        $tags_search = $this->get_part_of_array($tags, 0, $max);
        # echoarr($tags_search);
        $all_videos = $this->search_by_tag($tags_search, 0, $this->gbl_config['wlu_rlv_count']);
        $this->VP['related_videos'] = $all_videos;
    }

    function cmd_save_comment() {
        $FORM = $this->TCR->POST['FORM'];
        if ($_SESSION['WLU']['vp_capcha'] == 1) {
            if (isset($_SESSION['captcha_spam']) AND $this->TCR->POST["securecode"] == $_SESSION['captcha_spam']) {
                unset($_SESSION['captcha_spam']);
                $_SESSION['WLU']['vp_capcha'] = 2;
                $capcha = TRUE;
            }
            else
                $capcha = FALSE;
        }
        if ($FORM['c_name'] == "" || $FORM['c_text'] == "" || ($capcha == false && $_SESSION['WLU']['vp_capcha'] == 1)) {
            $this->VP['faultform'] = true;
            $this->VP['capcha_check'] = $capcha;
            $this->cmd_showplayer();
            $this->TCR->reset_cmd('showplayer');
            $this->TCR->set_fault_form(true);
            return;
        }
        else {
            $FORM['c_createtime'] = time();
            insertTable(TBL_CMS_WLU_COMMENTS, $FORM);
            $C = new wlu_comments_class();
            $C->update_comment_count($this->TCR->POST['vid']);
            unset($C);
            $_SESSION['WLU']['vp_capcha']++;
            $this->TCR->add_url_tag('vid', $this->TCR->POST['vid']);
            $this->TCR->reset_cmd('showplayer');
            $this->TCR->add_msg('{LBL_SAVED}');
        }
    }


    function load_videos($cid, $start, $count = 0) {
        $cid = (int)$cid;
        $start = (int)$start;
        $videos = array();
        $col = strtolower(strip_tags(strval(trim($this->TCR->GET['col']))));
        $allowed_cols = array('apptime', 'comment_count', 'views', '');
        if (!in_array($col, $allowed_cols))
            $col = 'views';
        if ($col == "") {
            $col = ($_SESSION['WLU']['selected']['last_sort'] != "") ? $_SESSION['WLU']['selected']['last_sort'] : 'apptime';
        }
        $orderby = 'yt_' . $col;
        $this->set_category($cid);
        $_SESSION['WLU']['selected']['last_sort'] = $col;
        $VR = $this->load_videos_by_cat($cid, $videos, $start, $orderby, $count);

        // category with 0 videos are not allowed
        if (count($videos) == 0) {
            if ($this->selected['countryid'] > 0) {
                $link = $this->gen_setcountry_link($this->selected['countryid'], $this->countries[$this->selected['countryid']]['land']);
                header('location: ' . $link);
                exit;
            }
            #else {
            #    $link = VP_HTML_SITE;
            #}

        }

        $direc = 'SORT_DESC'; // WiLinkU Request
        $this->VP['video_list'] = $videos;
        $this->VP['video_totalcount'] = $VR['total_count'];
        $this->VP['catlink'] = $this->gen_vpcat_link($this->selected['catobj'], $this->set_crc_for_link());
        //PAGING
        $add = 'col=' . $col;
        #$link = $_SERVER['PHP_SELF'] . '?page=' . $this->TCR->REQUEST['page'] . $add . '&cid=' . $cid . '&cmd=loadvideos';
        $link = $_SERVER['PHP_SELF'] . '?'; # . $add;

        $this->genPaging($this->VP['video_totalcount'], $start, $link, (int)$this->gbl_config['wlu_videosperpage']);
        // BreadCrumb
        $this->VP['cat_bread_crumb'] = array();
        $this->create_path_with_links($this->selected['cid'], $this->VP['cat_bread_crumb'], $this->selected['countryid'], $this->countries[$this->selected['countryid']]['land']);
        $this->VP['cat_bread_crumb'] = array_reverse($this->VP['cat_bread_crumb']);
        $this->VP['cat_bread_crumb_last'] = $this->VP['cat_bread_crumb'][count($this->VP['cat_bread_crumb']) - 1];
        if ($this->selected['cid'] == $this->selected['level1'] || $this->selected['cid'] == 0) {
            $CAT = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$this->selected['level1']);
            $this->VP['cat_bread_crumb'][] = array('title' => '{LBL_ALLCATEGROIES}', 'link' => $this->gen_level1_link($CAT, $this->countries[$this->selected['countryid']]['land']));
        }
        return $this->VP['video_list'];
    }


    function cmd_vp_search() {
        $start = (int)$this->TCR->REQUEST['start'];
        $videos = $this->search_by_tag($this->TCR->REQUEST['setvalue'], $start, $this->gbl_config['wlu_videosperpage']);
        //sorting
        $direc = ($this->TCR->REQUEST['direc'] == 'ASC') ? 'SORT_ASC' : 'SORT_DESC';
        $sorttype = ($this->TCR->REQUEST['sorttype'] == 'NUM') ? 'SORT_NUMERIC' : 'SORT_STRING';
        if (count($videos) > 0)
            $videos = sortDbResult($videos, strval('yt_lastupdate'), constant($direc), constant($sorttype));
        $direc = ($this->TCR->REQUEST['direc'] == 'ASC') ? 'DESC' : 'ASC';


        $this->smarty->assign('FILTER', array('direc' => $direc));
        $this->smarty->assign('qfilter_query', http_build_query(array('QFILTER' => $QFILTER)));
        $this->VP['video_list'] = $videos;
        $this->VP['video_totalcount'] = $video_ids['total'];

        //PAGING
        $add = "";
        if (is_array($this->TCR->REQUEST['QFILTER'])) {
            foreach ($this->TCR->REQUEST['QFILTER'] as $key => $value) {
                $add .= '&QFILTER[' . $key . ']=' . $value;
            }
        }
        #$link = $_SERVER['PHP_SELF'] . '?page=' . $this->TCR->REQUEST['page'] . $add . '&cmd=vp_search&setvalue=' . urlencode($this->TCR->REQUEST['setvalue']);
        $link = $_SERVER['PHP_SELF'] . '?page=' . $this->TCR->REQUEST['page'] . $add . '&cmd=vp_search&setvalue=' . urlencode($this->TCR->REQUEST['setvalue']);
        $this->genPaging($this->VP['video_totalcount'], $start, $link, (int)$this->gbl_config['wlu_videosperpage']);
        $this->VP['vpsection'] = 'videotable';
    }

    function set_metas() {
        global $meta_keywords, $meta_title, $meta_description;
        if (!empty($this->meta_keywords))
            $meta_keywords = $this->meta_keywords;
        if (!empty($this->meta_description))
            $meta_description = $this->meta_description;
        if (!empty($this->meta_title))
            $meta_title = $this->meta_title;
    }

    function parse_to_smarty() {
        $this->VP = array_merge((array )$this->VP, array('continents' => $this->continents, 'regions' => $this->regions, 'countries' => $this->countries, 'selected' =>
            $this->selected, 'crc_tab' => $this->crc_tab, 'vp_capcha' => (int)$_SESSION['WLU']['vp_capcha'], 'vp_level1' => (int)$_SESSION['WLU']['selected']['level1'],
            'sess' => $_SESSION['WLU']['selected'], ));
        $this->smarty->assign('VP', $this->VP);
        $this->set_metas();
    }

    function cmd_load_video_mixer() {
        $result = $this->db->query("SELECT *, id AS MID FROM " . TBL_CMS_ADMINS . " WHERE gid=11");
        while ($row = $this->db->fetch_array_names($result)) {
            $mixers[$row['MID']] = $row;
        }
        $this->VP['mixers'] = $mixers;
    }

    function cmd_load_right_column_videoplayer() {
        ECHORESULTCOMPILEDFE('<% include file="wlu_video-player_right_column_10073.tpl" %>');
    }

    function cmd_axrate() {
        require_once (CMS_ROOT . "includes/rating.class.php");
        $RATING = new rating_class();
        $ratedfeedback = $RATING->RateItem($_POST['vid'], $_POST['rating'], TBL_CMS_WLU_RATING);
        unset($RATING);
    }

    function cmd_load_all_categories() {
        $this->load_videos($this->TCR->REQUEST['cid'], (int)$this->TCR->REQUEST['start']);
        if ($this->TCR->REQUEST['cid'] > 0)
            $this->load_vptree_by_parent($this->selected['level1']);
        $this->VP['vpsection'] = 'videotable';
    }

    function load_related_links() {
        $RL = new wlu_relatedlinks_class();
        $cid = ($this->selected['cid'] == 0) ? $this->selected['level1'] : $this->selected['cid'];
        $relevant_country_ids = array();
        foreach ($this->countries as $key => $country) {
            if ($this->VP['location']['continent']['REGIONID'] == $country['REGIONID']) {
                $relevant_countryregion_ids[] = $country['COUNTRYID'];
                $relevant_countryregion_codes[] = $country['country_code_2'];
            }
            if ($this->VP['location']['continent']['CONID'] == $country['CONID']) {
                $relevant_country_ids[] = $country['COUNTRYID'];
                $relevant_country_codes[] = $country['country_code_2'];
            }
        }
        $RL->load_links_fe($cid, $this->VP['location']['country'], $relevant_country_ids, $relevant_country_codes, $relevant_countryregion_ids, $relevant_countryregion_codes);
        $this->VP['related_links'] = $RL->link_list;
        unset($RL);
    }


    function set_crc_for_link() {
        $country_name = $this->countries[$this->selected['countryid']]['land'];
        $regionid = $_SESSION['WLU']['selected']['regionid'];
        $conid = $_SESSION['WLU']['selected']['conid'];
        if ($country_name == "")
            $country_name = $this->regions[$regionid]['lr_name'];
        if ($country_name == "")
            $country_name = $this->continents[$conid]['lc_name'];
        if ($country_name == "")
            $country_name = 'all';
        return $country_name;
    }


    function set_country($countryid) {
        $countryid = $_SESSION['WLU']['selected']['countryid'] = (int)$countryid;
        $_SESSION['WLU']['selected']['regionid'] = $this->countries[$countryid]['REGIONID'];
        $_SESSION['WLU']['selected']['conid'] = $this->continents[$this->regions[$_SESSION['WLU']['selected']['regionid']]['lr_continet_id']];
        $_SESSION['WLU']['tree']['filter'] = 'country';
        return $countryid;
    }

    function cmd_setcountry() {
        $countryid = $this->set_country($this->TCR->REQUEST['countryid']);
        if (strstr($_SESSION['last_mod_exec'], 'wlu_coll')) {
            # $link = $this->gen_setcountry_link($this->TCR->REQUEST['regionid'], $this->set_crc_for_link());
            $link = VP_HTML_SITE;
        }
        else {
            $link = VP_HTML_SITE; #$_SESSION['lastPage'];
        }
        $this->TCR->redirecto = $link;
    }

    function set_region() {
        $regionid = (int)$this->TCR->REQUEST['regionid'];
        $_SESSION['WLU']['selected']['countryid'] = 0;
        $_SESSION['WLU']['selected']['regionid'] = $regionid;
        $_SESSION['WLU']['selected']['test'] = $regionid;
        $_SESSION['WLU']['selected']['conid'] = $this->regions[$regionid]['CONID'];
        $_SESSION['WLU']['tree']['filter'] = 'region';
        return $regionid;
    }

    function cmd_setregion() {
        $regionid = $this->set_region();
        if (strstr($_SESSION['last_mod_exec'], 'wlu_coll')) {
            #$link = $this->gen_setregion_link($this->TCR->REQUEST['regionid'], $this->set_crc_for_link());
            $link = VP_HTML_SITE;
        }
        else {
            $link = $_SESSION['lastPage'];
        }
        $this->TCR->redirecto = $link; #$_SESSION['lastPage'];
    }

    function set_continent() {
        $conid = (int)$this->TCR->REQUEST['conid'];
        $_SESSION['WLU']['selected']['countryid'] = 0;
        $_SESSION['WLU']['selected']['regionid'] = 0;
        $_SESSION['WLU']['selected']['conid'] = $conid;
        $_SESSION['WLU']['tree']['filter'] = 'continent';
        return $conid;
    }

    function cmd_setcontinent() {
        $conid = $this->set_continent();
        if (strstr($_SESSION['last_mod_exec'], 'wlu_coll')) {
            $link = $this->gen_setcontinent_link($conid, $this->set_crc_for_link());
        }
        else {
            $link = $_SESSION['lastPage'];
        }
        $this->TCR->redirecto = $link; #$_SESSION['lastPage'];
    }


    function cmd_showcountry() {
        $this->set_country($this->TCR->REQUEST['countryid']);
        $this->init();
        $this->cmd_default();
    }

    function cmd_showregion() {
        $this->set_region();
        $this->init();
        $this->cmd_default();
    }

    function cmd_showcontinent() {
        $this->set_continent();
        $this->init();
        $this->cmd_default();
    }

    function cmd_reset_destination() {
        unset($_SESSION['WLU']['tree']['filter']);
        unset($_SESSION['WLU']['selected']['countryid']);
        unset($_SESSION['WLU']['selected']['regionid']);
        unset($_SESSION['WLU']['selected']['conid']);
        if (strstr($_SESSION['last_mod_exec'], 'wlu_')) {
            $link = VP_HTML_SITE;
        }
        else {
            $link = $_SESSION['lastPage'];
        }
        $this->TCR->redirecto = $link;

    }
}

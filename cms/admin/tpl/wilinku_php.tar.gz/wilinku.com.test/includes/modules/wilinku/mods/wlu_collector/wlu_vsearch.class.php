<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
DEFINE('TBL_CMS_WLU_VSWORDS', TBL_CMS_PREFIX.'wlu_vswords'); 
DEFINE('TBL_CMS_WLU_VSREL', TBL_CMS_PREFIX.'wlu_vsrel'); 
DEFINE('TBL_CMS_WLU_VSWC', TBL_CMS_PREFIX.'wlu_vswc'); 

class wlu_vsearch_class extends wlu_colmaster_class {
	
function __construct() {
	parent::__construct();
}

function del_word($word) {
	$W = $this->db->query_first("SELECT * FROM " .TBL_CMS_WLU_VSWORDS." WHERE s_word='".$word."'");
	if ($W['id'] > 0) {
		$this->db->query("DELETE FROM ".TBL_CMS_WLU_VSWORDS." WHERE id=" . $W['id']);
		$this->db->query("DELETE FROM ".TBL_CMS_WLU_VSREL." WHERE sr_wordid=" . $W['id']);
	}
}

function del_by_videoid($videoid) {
		$this->db->query("DELETE FROM ".TBL_CMS_WLU_VSREL." WHERE sr_videoid='".$videoid."'");
}



function clean_index_by_videoid($videoid="") {
 if (!empty($videoid)) $this->db->query("DELETE FROM ".TBL_CMS_WLU_VSREL." WHERE sr_videoid='".$videoid."'");
	$sql="SELECT W.id,COUNT(sr_wordid) WCOUNT 
 	FROM ".TBL_CMS_WLU_VSWORDS." W  
	LEFT JOIN ".TBL_CMS_WLU_VSREL." R ON (R.sr_wordid=W.id)
 	WHERE 1
 	GROUP BY W.id
 	HAVING COUNT(sr_wordid)=0";
 $result = $this->db->query($sql);
 	while($row = $this->db->fetch_array_names($result)) {
 		$sqls.= (($sqls!="") ? ' OR '  : '') . ' id='.$row['id'];
 	}
 if ($sqls!="") $this->db->query("DELETE FROM ".TBL_CMS_WLU_VSWORDS." WHERE " . $sqls);	
}

function add_word($word, $countryid, $regionid, $conid, $videoid) {
	$FORM=array(
	's_word' 				=> $word,
	's_insert'			=> time(),
	);
	$W = $this->db->query_first("SELECT * FROM " .TBL_CMS_WLU_VSWORDS." WHERE s_word='".$word."'");
	if ($W['id']==0) {
		$W['id'] = insertTable(TBL_CMS_WLU_VSWORDS, $FORM);
		replaceTable(TBL_CMS_WLU_VSREL, array(
		'sr_wordid' 		=> $W['id'],
		'sr_videoid'		=> $videoid		
		));
		} else {
			$WR = $this->db->query_first("SELECT * FROM " .TBL_CMS_WLU_VSREL."
			WHERE sr_videoid='".$videoid."'
			AND sr_wordid='".$W['id']."'"
			);
			if ($WR['sr_videoid']=='') {
				replaceTable(TBL_CMS_WLU_VSREL, array(
				'sr_wordid' 		=> $W['id'],
				'sr_videoid'		=> $videoid,
				));
			}
		}

		replaceTable(TBL_CMS_WLU_VSWC, array(
		'sc_wordid' 		=> $W['id'],
		'sc_countryid' 	=> $countryid,
		'sc_regionid' 	=> $regionid,
		'sc_conid' 			=> $conid
		));

	}

function add_words($keywords,$country_matrix, $id) {
	foreach ($keywords as $word) {
		foreach ($country_matrix as $c_obj) {
			$COUNTRY = $this->db->query_first("SELECT *,C.id COUNTRYID, CO.id AS CONID, R.id AS REGIONID FROM
			".TBL_CMS_LAND." C
			, ".TBL_CMS_LANDCONTINET." CO
			, ".TBL_CMS_LANDREGIONS." R
			WHERE R.lr_continet_id=CO.id
			AND C.region_id=R.id
			AND C.id=".$c_obj['vc_countryid']."
			");
			$this->add_word($word, $COUNTRY['COUNTRYID'], $COUNTRY['REGIONID'], $COUNTRY['CONID'], $id);
		}
	}
}

function gen_keyword_list($sb) {
	if (!get_magic_quotes_runtime()) $sb = addslashes($sb);
	if (strlen($sb) > 50) exit;
	$sb = mb_strtolower(html_entity_decode($sb), "UTF-8");
	$sb = preg_replace('/\[^\pL]/u', '', $sb ); //UTF8 kompatibel, umlaute bleiben erhalten
	$sb = preg_replace('/[^\w\pL]/u', '', $sb); // entferhnt nun hier sauber alle Satzzeichen

	$json = array();
	$sql = "SELECT s_word FROM ".TBL_CMS_WLU_VSWORDS." W, ".TBL_CMS_WLU_VSWC." C
	WHERE LOWER(W.s_word) LIKE '".$sb."%'  COLLATE utf8_bin
	AND C.sc_wordid=W.id 
	".(($_SESSION['WLU']['selected']['countryid'] > 0) 	? " AND C.sc_countryid=".(int)$_SESSION['WLU']['selected']['countryid'] : "")."
	".(($_SESSION['WLU']['selected']['regionid'] > 0) 	? " AND C.sc_regionid=".(int)$_SESSION['WLU']['selected']['regionid'] 	: "")."
	".(($_SESSION['WLU']['selected']['conid'] > 0) 			? " AND C.sc_conid=".(int)$_SESSION['WLU']['selected']['conid'] 				: "")."
	GROUP BY W.s_word
	ORDER BY W.s_word
	LIMIT 10";
	#echo $sql;die;
	$result = $this->db->query($sql);
	while($row = $this->db->fetch_array_names($result)){
		$txt .= "".$row['s_word']."|".$row['s_word']."\n";
	}
	return $txt;
}

function format_word($sb) {
	if (!get_magic_quotes_runtime()) $sb = addslashes($sb);
	$sb = mb_strtolower(html_entity_decode($sb), "UTF-8");
	$sb = preg_replace('/\[^\pL]/u', ' ', $sb ); //UTF8 kompatibel, umlaute bleiben erhalten
	$sb = preg_replace('/[^\w\pL]/u', ' ', $sb); // entfernt nun hier sauber alle Satzzeichen	
return trim($sb);
}
 
function search($sb, $start) {
	$ids = array();
	if (is_array($sb)) {
		foreach ($sb as $key => $word) {
			$sql_add.= (($sql_add!="") ? " OR " : "") . " LOWER(W.s_word) LIKE '%".$this->format_word($word)."%'  COLLATE utf8_bin ";
		}
	} else {
	 $sql_add = " LOWER(W.s_word) LIKE '%".$this->format_word($sb)."%' COLLATE utf8_bin ";
	}
	$sql = "SELECT *,R.sr_videoid AS VID FROM ".TBL_CMS_WLU_VSWORDS." W, ".TBL_CMS_WLU_VSWC." C, ".TBL_CMS_WLU_VSREL." R, ".TBL_CMS_WLU_APPROVED_VIDEOS." V
	WHERE (".$sql_add.")
	AND C.sc_wordid=W.id
	AND R.sr_wordid=W.id
	AND V.yt_videoid=R.sr_videoid
	".(($_SESSION['WLU']['selected']['countryid'] > 0) 	? " AND C.sc_countryid=".(int)$_SESSION['WLU']['selected']['countryid'] : "")."
	".(($_SESSION['WLU']['selected']['regionid'] > 0) 	? " AND C.sc_regionid=".(int)$_SESSION['WLU']['selected']['regionid'] 	: "")."
	".(($_SESSION['WLU']['selected']['conid'] > 0) 			? " AND C.sc_conid=".(int)$_SESSION['WLU']['selected']['conid'] 				: "")."
	GROUP BY R.sr_videoid
	ORDER BY V.yt_lastupdate DESC
	LIMIT ".$start."," . (int)$this->gbl_config['wlu_videosperpage'];
    
	$result = $this->db->query($sql);
	while($row = $this->db->fetch_array_names($result)){
		$ids[] = $row['VID'];
	}
	$VC = $this->db->query_first("SELECT COUNT(R.sr_videoid) AS VCOUNT
	FROM ".TBL_CMS_WLU_VSWORDS." W, ".TBL_CMS_WLU_VSWC." C, ".TBL_CMS_WLU_VSREL." R
	WHERE LOWER(W.s_word) LIKE '%".$sb."%'  COLLATE utf8_bin
	AND C.sc_wordid=W.id
	AND R.sr_wordid=W.id
	".(($_SESSION['WLU']['selected']['countryid'] > 0) 	? " AND C.sc_countryid=".(int)$_SESSION['WLU']['selected']['countryid'] : "")."
	".(($_SESSION['WLU']['selected']['regionid'] > 0) 	? " AND C.sc_regionid=".(int)$_SESSION['WLU']['selected']['regionid'] 	: "")."
	".(($_SESSION['WLU']['selected']['conid'] > 0) 			? " AND C.sc_conid=".(int)$_SESSION['WLU']['selected']['conid'] 				: "")."
	");
	return array(
		'ids' 		=> $ids,
		'total' 	=> $VC['VCOUNT']		
		);
}


}
<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************


class wlu_query_class extends wlu_colmaster_class {


    function __construct() {
        parent::__construct();
    }

    
    function load_query($id) {
        $id = (int)$id;
        $sql = "SELECT *,Q.id AS QID,L.id AS COUNTRYID FROM " . TBL_CMS_WLU_VPQUERY . " Q 
	LEFT JOIN " . TBL_CMS_LAND . " L ON (L.id=Q.vp_countryid) 
	WHERE Q.id=" . $id . " 
	GROUP BY QID";
        $Q = $this->db->query_first($sql);
        $Q['qobj'] = unserialize($Q['vp_query']);
        $result = $this->db->query("SELECT C.* 
        FROM " . TBL_CMS_WLU_QUERY_TO_CAT . " M, " . TBL_CMS_WLU_VPQUERY . " Q, " . TBL_CMS_WLU_CATS . " C
	WHERE Q.id=M.qc_qid AND M.qc_cid=C.id AND Q.id=" . $id . "
    GROUP BY C.id
	ORDER BY M.qc_prio");
        while ($row = $this->db->fetch_array_names($result)) {
            $Q['assigned_cats'][] = $row;
            $Q['assigned_cat_ids'][] = $row['id'];
            $Q['pathes'][] = $row['ytc_path'];
        }
        $this->QUERY['query'] = $Q;
        return $this->QUERY['query'];
    }


    function delete_query($id) {
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VPQUERY . " WHERE id=" . (int)$id . " LIMIT 1");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " WHERE vq_queryid=" . (int)$id);
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VP . " WHERE yt_qid=" . (int)$id);
    }

    function set_query_options(&$row) {
        $row['icons'][] = genDelImgTagADMINConfirm($row['QID'], 'yt_query_delete', '{LBLA_CONFIRM}', '&section=qrun');
        $row['lastexec_datetime'] = ($row['yp_lastexec'] > 0) ? date('d.m.Y H:i:s', $row['yp_lastexec']) : '-';
        $row['yt_lastupdate_date'] = myDate('d.m.Y', $row['yt_lastupdate']);
        $row['vtags'] = str_replace(';', ', ', $row['yt_videotags']);
    }


}

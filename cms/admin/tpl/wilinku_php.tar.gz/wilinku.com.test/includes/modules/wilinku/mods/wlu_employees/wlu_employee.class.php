<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}


class wlu_employee_class extends employee_class {
	var $redirect_page 	= 'wlu_employee.inc';
	var $EMP 						= array();
	
function __construct() {
	parent::__construct();
	parent::set_redirect($this->redirect_page);
}

function interpreter($method) {
	if (method_exists($this, $method)) {
		return $this->$method();
	}
}

function gen_employee_ident($mid) {
	$mid = (int)$mid;
	$CO = $this->db->query_first("SELECT C.* FROM ".TBL_CMS_ADMINS." M, ".TBL_CMS_WLU_COMPANIES." C
	WHERE M.mi_company_id=C.id AND M.id=".$mid." LIMIT 1");
	$to = 3-strlen($mid);
	for ($i=0;$i <= $to;$i++) {
		$ident.='0';
	}
	return strtoupper($CO['co_ident'] . $ident . $mid);
}

function set_country_responsibilities($empid) {
	parent::set_country_responsibilities($empid);
	$WLU_COMPANY = new wlu_company_class();
	$WLU_COMPANY->load_company_by_id($this->employee_obj['mi_company_id']);
	foreach ($WLU_COMPANY->loaded_company['countries'] as $con_id => $continent) {
		if (is_array($continent)) {
			foreach ($continent as $rid => $region) {
				if (is_array($region)) {
					foreach ($region as $landid => $land) {
						if (is_array($land) && $land['land']!="") {
							$EC_MARTIX = array(
							'ec_eid'	=> $empid,
							'ec_countryid'	=> $landid
							);
							$this->db->query("DELETE FROM ".TBL_CMS_ADMIN_RESPCOUNTRIES." WHERE ec_countryid=".$landid." AND ec_eid=".$empid);
							insertTable(TBL_CMS_ADMIN_RESPCOUNTRIES, $EC_MARTIX);
						}
					}
				}
			}
		}
	}
}


function emp_saveemployee() {
	$ret = parent::emp_saveemployee();
	$this->employee_id = parent::get_employee_id();
	if ($this->employee_id > 0) {
		if ($ret['msge']=="") {
			$E = array(
			'mi_ident' 		=> $this->gen_employee_ident($this->employee_id)
			);
			updateTable(TBL_CMS_ADMINS, 'id', $this->employee_id, $E);
		}
		$this->set_country_responsibilities($this->employee_id);
	}
	$ret['redirect'] = $_SERVER['PHP_SELF'] . '?epage='.$this->redirect_page.'&aktion=edit&id=' . $this->employee_id;
	return $ret;
}

function load_employees() {
	parent::load_employees();
	$this->set_additional_options();
}

function load_employee($mid, $smarty_joker='EMPLOYEE') {
	parent::load_employee($mid,$smarty_joker);
	$this->load_companies();
	$WLU_COMPANY = new wlu_company_class();
	$WLU_COMPANY->load_company_by_id($this->employee_obj['mi_company_id']);
	$this->employee_obj['COMPANY'] = $WLU_COMPANY->loaded_company;
	$this->smarty->assign($smarty_joker, $this->employee_obj);
	unset($WLU_COMPANY);
}

function set_additional_options() {
	unset($this->employees[100]); // Support Mitarbeiter weg
	foreach ($this->employees as $key => $value) {
		$this->employees[$key]['icons'][] = '<a title="{LBL_COMPANIES}" href="'.$_SERVER['PHP_SELF'].'?epage=wlu_company.inc"><img src="./images/tower.png" border="0"></a>';
	  $this->employees[$key]['company'] = $this->db->query_first("SELECT C.* FROM ".TBL_CMS_ADMINS." M, ".TBL_CMS_WLU_COMPANIES." C	WHERE M.mi_company_id=C.id AND M.id=".$key." LIMIT 1");
	}
	$this->EMPGBL['employees']	= $this->employees;
}

function load_companies() {
	$WLU_COM = new wlu_company_class();
	$WLU_COM->load_companies();
	$this->EMPGBL['companies']	= $WLU_COM->companies;
	unset($WLU_COM);
}

function parse_to_smarty() {
 $this->smarty->assign('EMPGBL', $this->EMPGBL); 
}

} //CLASS

?>
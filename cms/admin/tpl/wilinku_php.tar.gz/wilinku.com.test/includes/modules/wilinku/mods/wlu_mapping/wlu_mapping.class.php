<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

DEFINE('TBL_CMS_WLU_LINKMATRIX', TBL_CMS_PREFIX.'wlu_linkmatrix');


class wlu_mapping_class extends tc_class {
	
	
function __construct() {
	parent::__construct();
	$this->TCR 					= new tc_request_class($this);
	$this->LINK_OBJ 		= new links_class();

	$this->MAPPING = array();
}

function cmd_save_link_matrix() {
	$lm = $_POST['linkmapping'];
	$this->db->query("DELETE FROM ".TBL_CMS_WLU_LINKMATRIX);
	if (count($lm) > 0 ) {
		foreach ($lm as $lm_link_id => $lm_cat_id) {
			$this->db->query("INSERT INTO ".TBL_CMS_WLU_LINKMATRIX." SET lm_link_id=".(int)$lm_link_id.", lm_cat_id=" . (int)$lm_cat_id);
		}
	}
	$this->TCR->set_just_turn_back(true);
	$this->TCR->add_msg('{LBL_SAVED}'); 		
}

function cmd_init_links() {
 $this->LINK_OBJ->load_groups();
 $this->MAPPING['link_cats'] = $this->LINK_OBJ->lc_groups; 
 $result=$this->db->query("SELECT * FROM ".TBL_CMS_WLU_LINKMATRIX." WHERE 1");
	while($row = $this->db->fetch_array_names($result)){
		$this->link_matrix[$row['lm_link_id']]=$row['lm_cat_id'];
	}
 $this->build_cat_selectboxes();
}

function build_cat_selectboxes($country_id=0) {
	$this->VIDEOPUNCH 	= new wlu_collector_class();
	$this->VIDEOPUNCH->EMPLOYEE = $this->EMPLOYEE;
	$country_id = (int)$country_id;
	$this->MAPPING['category']['cat_selectboxes'] = array();
	$menutree = new nestedArrClass();
	$menutree->init(
	array(
	'label_column' 	=> 'ytc_name',
	'label_parent' 	=> 'ytc_parent',
	'label_id' 			=> 'id',
	'sign'					=> '|_'
	)
	);
	$menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS. " ORDER BY ytc_parent,ytc_name", 0, 0, -1);
	if ($country_id==0) {
		$this->VIDEOPUNCH->remove_cats_by_country_relationship($menutree);
		} else {
			$this->VIDEOPUNCH->remove_countries_by_list(&$menutree, array($country_id));
		}
		if (is_array($this->MAPPING['link_cats'])) {
			foreach ($this->MAPPING['link_cats'] as $key => $link_obj) {
				$cid = $this->link_matrix[$link_obj['id']];
				$this->MAPPING['link_cats'][$link_obj['id']]['cat_selectbox'] = $menutree->output_as_selectbox((int)$cid, 0, array('key' => 0, 'value'=>'- NONE -'));
			}
		}
		unset($menutree);
}

function parse_to_smarty() {
 $this->smarty->assign('MAPPING', $this->MAPPING);
}

}
?>
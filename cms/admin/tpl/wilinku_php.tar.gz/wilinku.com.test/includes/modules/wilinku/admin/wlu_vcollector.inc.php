<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2009     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

$_GET['id'] 				= (int)$_REQUEST['id'];
$_GET['starttree']	= (int)$_REQUEST['starttree'];
$_GET['section'] 		= $_REQUEST['section'];
if (!empty($_GET['section'])) $_SESSION['section'] = $_GET['section'];
if (empty($_GET['section'])) 	$_GET['section'] = $_SESSION['section'];

include(CMS_ROOT .  'admin/inc/module.class.php'); 	
$MODULE_OBJ = new module_class(MODULE_ROOT . 'wilinku/');
$MODULE_OBJ->interpreter($_REQUEST);

$ir = $WLU_COLLECTOR_OBJ->interpreter($_REQUEST['aktion']);

if ($ir['status']===TRUE) {
	$ir['redirect'] = (($ir['redirect']!="") ? $ir['redirect'] : $_SERVER['PHP_SELF'] .'?epage='.$_GET['epage']);
	if (!empty($ir['msg'])) {
		$ir['redirect'] = $WLU_COLLECTOR_OBJ->modify_url($ir['redirect'], array('msg' => base64_encode($ir['msg'])));
		HEADER('location:'. $ir['redirect']);
		}
		if (!empty($ir['msge'])) {
			$ir['redirect'] = $WLU_COLLECTOR_OBJ->modify_url($ir['redirect'], array('msge' => base64_encode($ir['msge'])));
			HEADER('location:'. $ir['redirect']);
		}
		exit;
}

if ($_POST['aktion']=="a_save_config") {
  $CONFIG_OBJ->save($_POST['FORM']);
  $TCMASTER->hard_exit();
}



$menu = array(
	"Video Manager" => "",
	"Categories" 		=> "section=cats&aktion=showall",
	"Style&Files" 	=> "section=modstylefiles&epage=".$_GET['epage'],
	"{LBL_CONFIGURATION}" => "aktion=conf"
	);
buildTopMenu($menu);

if ($_GET['section']=='cats') {
	if ($_GET['aktion']=='showall' || $_GET['aktion']=='') {
		$WLU_COLLECTOR_OBJ->buildATree(0,$_GET['starttree']);
		$WLU_COLLECTOR_OBJ->load_cat_table($_GET['starttree']);
	}
	if ($_GET['aktion']=='catedit') {
		$WLU_COLLECTOR_OBJ->load_cat($_GET['id']);
		$WLU_COLLECTOR_OBJ->build_tree_selectbox($WLU_COLLECTOR_OBJ->CATOBJ['ytc_parent'], $WLU_COLLECTOR_OBJ->CATOBJ['id']);		
		$WLU_COLLECTOR_OBJ->load_countries();
	}
	if ($_GET['cmd']=='catadd') {
		$WLU_COLLECTOR_OBJ->load_cat(0);
		$WLU_COLLECTOR_OBJ->build_tree_selectbox(0,0);
	}
	
}

#*********************************
# SHOW CONFIG
#*********************************
if ($_GET['aktion']=='conf') {
$content.='<h1>{LBL_CONFIGURATION}</h1>' . $CONFIG_OBJ->buildTable(37,37);
}
$content.='<% include file="wlu_collector.tpl" %>';
$WLU_COLLECTOR_OBJ->parse_to_smarty();
?>
<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}

$module_id = 'wlu_companies';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU Companies',
		'intern_aktion' 	=> '',
		'id' 							=> $module_id,
		'php' 						=> WLU_MOD_ROOT . $module_id . '/wlu_company.inc',
		'hasperm' 				=> true,
		'epage' 					=> array('wlu_company.inc'), #admin. PHP Scripts
		'epage_dir'				=> WLU_MOD_ROOT,
		'is_content_page'	=> false,
		'class_name'			=> 'wlu_company_class', #PHP Master Class Name of Modul
		);
DEFINE('TBL_CMS_WLU_COMPANIES', TBL_CMS_PREFIX.'wlu_companies'); 
include(WLU_MOD_ROOT . $MODULE[$module_id ]['id'] . '/wlu_company.class.php'); 	
?>
<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

class wlu_adhocvideo_class extends wlu_colmaster_class {


    function __construct() {
        parent::__construct();
        $this->TCR = new tc_request_class($this);
        $this->ADHOC = array();
        $this->ADHOCINDEX = array('AH' => 'AdHoc', 'WU' => 'WiLinkU');
    }

    function parse_to_smarty() {
        $this->ADHOC['ADHOCINDEX'] = $this->ADHOCINDEX;
        $this->smarty->assign('ADHOC', $this->ADHOC);
    }

    function set_adhoc_video_opt(&$video) {
        list($y, $m, $d) = explode('-', $video['yt_lastupdate']);
        $video['yt_lastupdate'] = $m . '.' . $y;
        $video['preview'] = VIDEOTHUMB_PATH . $video['yt_preview'];
        $video['yt_videoduration_min'] = round($video['yt_videoduration'] / 60, 2);
    }


    function load_adhoc_video($id) {
        $V = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V LEFT JOIN " . TBL_CMS_LAND . " L ON (L.id=V.yt_adhoc_countryid)
	WHERE V.yt_videoid='" . $id . "'");
        $this->set_adhoc_video_opt($V);
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_VCATMATRIX . " M, " . TBL_CMS_WLU_CATS . " C
	WHERE M.vcm_cid=C.id AND M.vcm_videoid='" . $id . "'
	ORDER BY M.vcm_videoid");
        while ($row = $this->db->fetch_array_names($result)) {
            $V['assigned_cats'][] = $row;
            $V['assigned_cat_ids'][$row['vcm_cid']] = $row['vcm_cid'];
            $V['pathes'][] = $row['ytc_path'];
        }

        $this->ADHOCVIDEO = $V;
        return $this->ADHOCVIDEO;
    }

    function generate_rand_string($length = 16) {
        $pattern = "1234567890abcdefghijklmnopqrstuvwxyz";
        for ($i = 0; $i < $length; $i++) {
            srand((double)microtime() * 1000000);
            $key .= $pattern{rand(0, 35)};
        }
        return strtoupper($key);
    }

    function generate_video_id() {
        $s = $this->generate_rand_string(16);
        while (getCount(TBL_CMS_WLU_APPROVED_VIDEOS, 'yt_videoid', "yt_videoid='" . $s . "'") > 0) {
            $s = $this->generate_rand_string(16);
        }
        return $s;
    }

    function trim_array(&$arr) {
        if (is_array($arr)) {
            foreach ($arr as $key => $value)
                $arr[$key] = trim($value);
        }
    }

    function save_video($id, $FORM, $CIDS, $FILES = array()) {
        $insert = false;
        if ($id == "") {
            $id = strtoupper($FORM['yt_stock']) . $this->generate_video_id();
            $insert = true;
        }
        $FORM['yt_adhoc_countryid'] = (int)$FORM['yt_adhoc_countryid'];
        $FORM['yt_isadhoc'] = 1;
        list($m, $y) = explode('.', $FORM['yt_lastupdate']);
        $FORM['yt_lastupdate'] = $y . '-' . $m . '-01';
        $FORM['yt_upload_date'] = $y . '-' . $m . '-01';
        $FORM['yt_author_realname'] = $FORM['yt_author_username'];
        $FORM['yt_videoduration'] = validateNumForSQL($FORM['yt_videoduration']) * 60;

        $tags1 = explode(',', $FORM['yt_videoahtags']);
        $tags2 = explode(',', $FORM['yt_videoembtags']);
        $this->trim_array($tags1);
        $this->trim_array($tags2);
        $FORM['yt_videotags'] = implode(';', array_unique(array_merge($tags2, $tags1)));
        if ($insert === FALSE) {
            updateTable(TBL_CMS_WLU_APPROVED_VIDEOS, 'yt_videoid', $id, $FORM);
        }
        else {
            $FORM['yt_apptime'] = time();
            $FORM['yt_valtime'] = time();
            $FORM['yt_videoid'] = $id;
            $FORM['yt_creator'] = mysql_real_escape_string($this->EMPLOYEE['mitarbeiter_name']);
            $FORM['yt_creatorid'] = $this->EMPLOYEE['MID'];
            insertTable(TBL_CMS_WLU_APPROVED_VIDEOS, $FORM);
        }

        //Country
        $this->load_crc_tab_admin();
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " WHERE vc_videoid='" . $id . "'");
        if ($FORM['yt_adhoc_countryid'] > 0) {
            $VC_MATRIX = array('vc_videoid' => $id, 'vc_countryid' => $FORM['yt_adhoc_countryid'], 'vc_regionid' => $this->get_region_of_country($FORM['yt_adhoc_countryid']),
                'vc_contid' => $this->get_continent_of_country($FORM['yt_adhoc_countryid']));
            replaceTable(TBL_CMS_WLU_VIDEO_TO_COUNTRY, $VC_MATRIX);
        }
        $this->update_location_counts();
        /*else {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE 1");
        while ($row = $this->db->fetch_array_names($result)) {
        $VC_MATRIX = array('vc_videoid' => $id, 'vc_countryid' => $row['id'], );
        replaceTable(TBL_CMS_WLU_VIDEO_TO_COUNTRY, $VC_MATRIX);
        }
        }*/
        // CAT
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_videoid='" . $id . "'");
        if (is_array($CIDS)) {
            foreach ($CIDS as $key => $cid) {
                $I = array('vcm_videoid' => $id, 'vcm_cid' => $cid);
                if ($cid > 0) {
                    replaceTable(TBL_CMS_WLU_VCATMATRIX, $I);
                    $this->update_count_approved_videos($cid);
                }
            }
        }

        // THUMBNAIL
        if ($FILES['thumbfile']['name'] != "") {
            $path_parts = pathinfo($FILES['thumbfile']['name']);
            $file_extention = strtolower($path_parts['extension']);
            if ($file_extention == 'jpeg')
                $file_extention = 'jpg';
            $new_file_name = CMS_ROOT . VIDEOTHUMB_PATH . 'video_thumb_' . $id . '.' . $file_extention;
            if (!is_dir(CMS_ROOT . VIDEOTHUMB_PATH))
                mkdir(CMS_ROOT . VIDEOTHUMB_PATH, 0775);
            move_uploaded_file($FILES['thumbfile']['tmp_name'], $new_file_name);
            clean_cache_like($new_file_name);
            chmod($new_file_name, 0755);
            $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_thumbnailurl='', yt_preview='" . basename($new_file_name) . "' WHERE yt_videoid='" . $id .
                "' LIMIT 1");
        }

        // Cache Thumbnail URL
        if ($FORM['yt_thumbnailurl'] != "" && $FILES['thumbfile']['name'] == "") {
            $path_parts = pathinfo(basename($FORM['yt_thumbnailurl']));
            $file_extention = strtolower($path_parts['extension']);
            if ($file_extention == 'jpeg')
                $file_extention = 'jpg';
            $new_file_name = CMS_ROOT . VIDEOTHUMB_PATH . 'video_thumb_' . $id . '.' . $file_extention;
            file_put_contents($new_file_name, file_get_contents($FORM['yt_thumbnailurl']));
            clean_cache_like($new_file_name);
            chmod($new_file_name, 0755);
            $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_preview='" . basename($new_file_name) . "' WHERE yt_videoid='" . $id . "' LIMIT 1");
        }
        #	echoarr($FORM);die($id);
        return $id;
    }


    function search_adhoc_videos($QFILTER, $childs, &$videos, $c_sql) {
        $sqladd = " FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VCATMATRIX . " VCAT,
	 " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L
	WHERE VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND V.yt_stock='AH'
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	" . (($childs['sql_cid_filter'] != "") ? " AND (" . $childs['sql_cid_filter'] . ")" : '') . "
	 " . ((is_array($QFILTER) && $QFILTER['countryid'] != ALLCOUNTRYID) ? " AND VC.vc_countryid=" . $QFILTER['countryid'] : $c_sql) . ((is_array($QFILTER) && $QFILTER['queryid'] >
            0) ? " AND Q.id='" . $QFILTER['queryid'] . "'" : "") . ((is_array($QFILTER) && $QFILTER['yt_blocked'] > 0) ? " AND V.yt_blocked=1" : " AND V.yt_blocked=0");
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID " . $sqladd . "
	GROUP BY V.yt_videoid
	ORDER BY V.yt_lastupdate DESC
	LIMIT 100";
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $row['lastexec_datetime'] = '-';
            $videos[$row['VID']] = $row;
        }
        $C = $this->db->query("SELECT COUNT(V.yt_videoid) AS VCOUNT " . $sqladd . " GROUP BY V.yt_videoid");
        return (int)$this->db->num_rows($C);
    }

}

?>
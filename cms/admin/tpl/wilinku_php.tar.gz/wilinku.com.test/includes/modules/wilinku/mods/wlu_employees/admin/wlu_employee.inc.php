<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
$WLU_EMPMAN = new wlu_employee_class();
$CM = new country_class();
$WLU_COMPANY = new wlu_company_class(); 

$INTERPRETER = $WLU_EMPMAN;
include(CMS_ROOT .  'admin/inc/interpreter.inc.php'); 	

$menu = array(
	"{LBLA_SHOWALL}" => ""
	);
buildTopMenu($menu);

  
$WLU_EMPMAN->load_employees();
$WLU_EMPMAN->load_admin_groups();	  

if ($_GET['aktion']=="countryrelated") {
	$CM->load_regions();
	$CM->load_regions_by_continent($_GET['continentid']);
	$CM->load_countries_by_region($_GET['regionid']);	
	$WLU_EMPMAN->load_employee((int)$_GET['id'], 'empobj');
}

if ($_GET['aktion']=="edit") {
	$WLU_EMPMAN->load_lang_list();
	$WLU_EMPMAN->load_employee((int)$_GET['id'], 'empobj');
	$WLU_COMPANY->load_company_by_id($WLU_EMPMAN->employee_obj['mi_company_id']);
	if (isset($_POST['FORM'])) {
		$FORM = $_POST['FORM'];
		$smarty->assign('empobj', $FORM);
		}
		if ($_SESSION['admin_obj']['GROUPID']==1) $smarty->assign('mitgroups', buildOptSQLopt(TBL_CMS_ADMINGROUPS, 'id', 'mgname', $where='ORDER BY mgname',$FORM[gid], 0, "-"));
}

$WLU_EMPMAN->parse_to_smarty();
$WLU_COMPANY->parse_to_smarty();
$content.='<% include file="wlu_employee.admin.tpl" %>';
?>
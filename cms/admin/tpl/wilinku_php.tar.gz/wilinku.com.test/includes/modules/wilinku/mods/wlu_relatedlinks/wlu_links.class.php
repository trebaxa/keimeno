<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2010    									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

class wlu_relatedlinks_class extends wilinku_class {

var $xls_file_name = 'related_links_report_grandview.xls';

function __construct() {
	global $GRAPHIC_FUNC;
	parent::__construct();
	$this->TCR 			= new tc_request_class($this);
	$this->GRAPHIC_FUNC = $GRAPHIC_FUNC;

}

function delete_link($id) {
 $id = (int)$id;	
 $linklist_obj = $this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE id=".$id." LIMIT 1"); 
 $this->db->query("DELETE FROM ".TBL_CMS_WLULINKS." WHERE id=".$id." LIMIT 1"); 		
 $this->db->query("DELETE FROM ".TBL_CMS_WLU_LINKMATRIX." WHERE lm_link_id=".$id);
 $this->db->query("DELETE FROM ".TBL_CMS_WLU_LINKLOC." WHERE lc_lid=".$id);
 delete_file(CMS_ROOT . RLICO_PATH . $linklist_obj['rl_bild']);
 delete_file(CMS_ROOT . RLICO_PATH . $linklist_obj['rl_flash']);
 $this->VPLOG->vp_addlog('delete RL link ['.$id.']: '.$linklist_obj['rl_title'], 'RL_LINK_DELETE');
}



function cmd_save_link_table() {
	$category = $this->TCR->POST['category'];
	$sorting = $this->TCR->POST['orders'];
	if (count($sorting) > 0) {
		$sarr=array();
		foreach($sorting as $id => $value) {
			$sarr[$id]	= array(
			'rl_s_order' 	=> (int)$sorting[$id],
			'rl_cat_id' 	=> (int)$category[$id],
			'id' 					=> $id
			);
		}

		$sarr = sortDbResult($sarr, 's_order ', SORT_ASC, SORT_NUMERIC);
				#echoarr($sarr);
		$i=0;
		foreach($sarr as $key => $row) {
			$i+=10;
			$row['rl_s_order'] = $i;
			$id = $row['id'];
			unset($row['id']);
			updateTable(TBL_CMS_WLULINKS, 'id', $id, $row);
		};
	}
	$this->TCR->add_msg('{LBL_SAVED}');
	$this->TCR->set_just_turn_back(true);
}

function approve_link($value, $id) {
 	$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_approval=".(int)$value."".(($value==1) ? ",rl_approve_date=".time()."" : '')." WHERE id=".(int)$id." LIMIT 1"); 
}

function approve_group($value, $id) {
 	$this->db->query("UPDATE ".TBL_CMS_WLULINKS_CATS." SET lc_approval=".(int)$value." WHERE id=".(int)$id." LIMIT 1"); 
}

function cmd_delete_listed_links() {
	$id_list = $this->TCR->POST['metaids'];
	if (count($id_list) > 0) {
		foreach($id_list as $key => $wert) {
			$this->delete_link($wert);
		}
	}
	$this->TCR->add_msg('{LBL_DELETED}');
	$this->TCR->set_just_turn_back(true);
}



function move_cat($id_list) {
	if (count($id_list)>0) {
		foreach($id_list as $key => $wert) {
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET spon_alb='".$cat_alb."' WHERE id=".(int)$wert);
		}
	}
}

function cmd_save_metas() {
	$id_list_save = (array)$this->TCR->POST['metaids'];
	$id_list_del 	= (array)$this->TCR->POST['metaidsdel'];
	$rows 				= (array)$this->TCR->POST['ROW'];
	if (count($rows) > 0) {
		foreach($rows as $id => $row) {
			if (in_array($id, $id_list_save)) updateTable(TBL_CMS_WLULINKS,'id',$id,$row);
			if (in_array($id, $id_list_del)) $this->delete_link($id);
		}
	}
	$this->TCR->add_msg('{LBL_DONE}');	  	
}

function get_first_cid_fe() {
	$LG = $this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS_CATS . " WHERE lc_approval=1 LIMIT 1");
	return (int)$LG['id'];
}

/*
function cmd_deletegroup() {
	$r=$this->del_group($_GET['cid']);
	if ($r===TRUE) {
		$this->TCR->add_msg('{LBL_DELETED}');
		$this->TCR->set_just_turn_back(true);

		} else {
			$this->TCR->add_msg('beinhaltet noch Links');
			$this->TCR->set_just_turn_back(true);
		}
	}
*/


function set_link_to_cat($linkid,$catid) {
	$this->db->query("DELETE FROM ".TBL_CMS_WLU_LINKMATRIX." WHERE lm_link_id=".(int)$linkid);
	$this->db->query("INSERT INTO ".TBL_CMS_WLU_LINKMATRIX." SET lm_link_id=".(int)$linkid.", lm_cat_id=".(int)$catid);
}

function cmd_savegroup() {
	$FORM = $this->TCR->POST['FORM'];
	$cid = (int)$this->TCR->POST['cid'];;
	if ($cid > 0) {
		updateTable(TBL_CMS_WLULINKS_CATS, 'id', $cid, $FORM);
		} else {
			$cid=insertTable(TBL_CMS_WLULINKS_CATS, $FORM);
		}
		$this->TCR->reset_cmd('groupedit');
		$this->TCR->add_url_tag('cid', $cid);
		$this->TCR->add_msg('{LBL_SAVED}');
}

function del_group($id) {
	$id = (int)$id;
	if (getCount(TBL_CMS_WLULINKS,'id',"cat_id=" . $id)==0) {
		$this->db->query("DELETE FROM ".TBL_CMS_WLULINKS_CATS." WHERE id=".$id);
		return true;
	} return false;
}

function cmd_load_links() {
 $this->load_links($this->TCR->REQUEST['QFILTER'], $this->TCR->REQUEST['start'], $this->TCR->REQUEST['col'], $this->TCR->REQUEST['direc']);
}

function get_locations_by_link($lid) {
	$locations=array();
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_WLU_LINKLOC." WHERE lc_lid=".(int)$lid);
	while($row = $this->db->fetch_array_names($result)){
		$locations[]=$this->RELLINK['ccodes'][$row['lc_location']]['country'];
	}
	sort($locations);
	return (array)$locations;
}

function load_links($QFILTER, $start, $col, $direc, $limit=50) {
	$this->load_locations();
	$this->link_list = array();
	$cid	 = (int)$QFILTER['cid'];
	$word  = $QFILTER['word'];
	$start = (int)$start;
	$col = ($col=="") ? "rl_title" : $col;
	$direc 		= ($_GET['direc']=='DESC') ? 'DESC' : 'ASC';
  $this->RELLINK['total_country_count']=getCount(TBL_CMS_LAND,'id',"1"); 
	
	// SECURITY
	$all_cols = $this->get_all_columns(TBL_CMS_WLULINKS);
	if (!in_array($col, $all_cols)) die('ILLEGAL SCRIPT CALL');
	if (is_array($this->EMPLOYEE['responsible_countries_ids']) && $QFILTER['countryid'] > 0 && !in_array($QFILTER['countryid'],$this->EMPLOYEE['responsible_countries_ids'])) {
	 die('ILLEGAL SCRIPT CALL BY COUNTRY');
	}
	
	$from_date =strtotime($QFILTER['r_from']);
	$to_date = strtotime($QFILTER['r_to']);	
	if ($QFILTER['countryid'] == 0 && is_array($this->EMPLOYEE['responsible_countries_ids'])) {
		$c_sql=" AND (CM.cm_countryid=0 OR CM.cm_countryid IN (".implode(',',$this->EMPLOYEE['responsible_countries_ids']).")) ";
	}	

	$sql_filter = " ".(($cid > 0) ? " AND LC.lm_cat_id=".(int)$cid : "")." 
  		".(($word !="") ? " AND S.rl_title LIKE '%".$word."%'" : "")."  	
  		".(($QFILTER['countryid'] == 0) ? $c_sql : "")."
  		".(($QFILTER['countryid'] > 0) ? " AND CM.cm_countryid=".(int)$QFILTER['countryid'] : "")."
  	  ".(($QFILTER['location'] != "") ? " AND LOC.lc_location='".$QFILTER['location']."' AND LOC.lc_lid=S.id" : "")."  			
  		". (($QFILTER['r_from'] != "") ? " AND S.rl_approve_date>='".$from_date."' AND S.rl_approve_date<='".$to_date."'" : "")."
  		";
	
	$tabs = " FROM ".TBL_CMS_WLULINKS." S, ".TBL_CMS_WLU_LINKMATRIX." LC, ".TBL_CMS_WLU_CATS." C , ".TBL_CMS_WLU_COUNTRY_TO_CAT." CM " 
	#	. (($QFILTER['countryid'] > 0) ? ", ".TBL_CMS_WLU_COUNTRY_TO_CAT." CM" : '') 
		. (($QFILTER['location'] != "") ? ", ".TBL_CMS_WLU_LINKLOC." LOC" : '');
	
	$std_where = " LC.lm_link_id=S.id 
			AND LC.lm_cat_id=C.id 
			AND CM.cm_cid=C.id";
		#	. (($QFILTER['countryid'] > 0) ? " AND CM.cm_cid=C.id " : "")
		#	. (($QFILTER['countryid'] == 0) ? $c_sql : "")
		#	. (($QFILTER['location'] != "") ? " AND LOC.lc_location='".$QFILTER['location']."' AND LOC.lc_lid=S.id" : "")
		#	. (($QFILTER['r_from'] != "") ? " AND S.rl_approve_date>='".$from_date."' AND S.rl_approve_date<='".$to_date."'" : "");

	$sql="SELECT S.*, S.id AS LID,C.id AS CID,C.ytc_name,C.ytc_path ".$tabs."  
	WHERE " . $std_where. $sql_filter." 
	GROUP BY S.id
	ORDER BY S.".$col." ".$direc."
  LIMIT ".$start.", ".$limit;
  $result = $this->db->query($sql ); 	
  #echo $sql;
  while($row = $this->db->fetch_array_names($result)){
  	$row['icons'][] = genEditImgTagADMIN($row['id'],"","edit_link");
  	$row['icons'][] = genDelImgTagADMINConfirmAJAX($row['id']);
  	$row['icons'][] = genApproveImgTagAJAX($row['id'],$row['rl_approval']);
  	$row['rl_approve_date_ger'] = date('d.m.Y', $row['rl_approve_date']);
  	$row['cat_path'] = explode('/', $row['ytc_path']);
  	$row['cat_path_0'] = $row['cat_path'][1];
  	$row['cat_path_1'] = $row['cat_path'][2];
  	$row['cat_path_2'] = $row['cat_path'][3];  	
  	if ($row['rl_bild']!="") $row['picture_thumb'] = PATH_CMS . 'admin/' . CACHE . $this->GRAPHIC_FUNC->makeThumb('../'.RLICO_PATH . $row['rl_bild'],100,100,'admin/' . CACHE,TRUE,'resize');
  	$row['locations'] = $this->get_locations_by_link($row['LID']);
  	$row['locations_count'] = count($row['locations']);
  	$row['ccodes_count'] = count($this->RELLINK['ccodes']);
  	$row['locations'] = implode(', ', $row['locations']);
  	if ($QFILTER['countryid'] > 0) {
  		$COUNTRY=$this->db->query_first("SELECT L.* FROM  ".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_LAND." L , ".TBL_CMS_WLU_LINKMATRIX." LC
  					WHERE CM.cm_countryid=".$QFILTER['countryid']." 
  					AND LC.lm_cat_id=CM.cm_cid
  					AND L.id=CM.cm_countryid 
  					AND LC.lm_link_id=".$row['LID']);
			$row['land'] = $COUNTRY['land'];
			$row['country_count'] = 1;
  	} else {
  		$countries=array();
  		$r=$this->db->query("SELECT L.* FROM  ".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_LAND." L , ".TBL_CMS_WLU_LINKMATRIX." LC
  					WHERE LC.lm_cat_id=CM.cm_cid
  					AND L.id=CM.cm_countryid 
  					AND LC.lm_link_id=".$row['LID']);
  					 while($rc = $this->db->fetch_array_names($r)){
  					  $countries[]=$rc['land'];
  					 }
			sort($countries);  					 
			$row['land'] = implode(', ',$countries);
			$row['country_count'] = count($countries);
  	}
  	if ($this->RELLINK['total_country_count']==$row['country_count']) $row['land'] = 'all countries';
  	$this->link_list[] = $row;
  }

 $this->smarty->assign('linkliste', $this->link_list); 
 $this->smarty->assign('QFILTER', $QFILTER); 
 $this->smarty->assign('qfilter_query',http_build_query(array('QFILTER' => $QFILTER)));
 $direc 		= ($_GET['direc']=='ASC') ? 'DESC' : 'ASC';
 $this->smarty->assign('FILTER', array('direc' => $direc)); 
 $counts['link_count_all_countries'] = getCount(TBL_CMS_WLULINKS,'id',"1");
 $result=$this->db->query("SELECT S.id AS FC " . $tabs . " WHERE " . $std_where	. $sql_filter." GROUP BY S.id");
 if ($result) $R['FC']=$this->db->num_rows($result);
			else $R['FC']=0;
 if (is_array($this->EMPLOYEE['responsible_countries_ids']) && count($this->EMPLOYEE['responsible_countries_ids']) > 0) {
		$c_sql=" AND CM.cm_countryid IN (".implode(',',$this->EMPLOYEE['responsible_countries_ids']).") ";
		$sql="SELECT S.id 
			FROM ".TBL_CMS_WLULINKS." S, ".TBL_CMS_WLU_LINKMATRIX." LC, ".TBL_CMS_WLU_CATS." C,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM  
			WHERE LC.lm_link_id=S.id 
			AND CM.cm_cid=C.id
			AND LC.lm_cat_id=C.id " . $c_sql ." GROUP BY S.id";
		#	echo $sql;
		$result=$this->db->query($sql);
		if ($result) $RC['FC']=$this->db->num_rows($result);
			else $RC['FC']=0;
	}	 else $RC['FC']=$counts['link_count_all_countries'];
 $counts['link_filtered_count'] = (int)$R['FC'];
 $counts['link_responsible_country_count'] = (int)$RC['FC'];
 $this->RELLINK['counts'] = $counts;
 $this->genPaging($this->RELLINK['link_filtered_count'], $start);
}

function set_link_opt_fe(&$row) {
 $row['print_link'] = str_replace(array('http://'),'',$row['rl_url']);
 $row['parsed_url'] = parse_url($row['rl_url']);
 $row['print_url']  = str_replace('www.','',$row['parsed_url']['host']);
 $row['valid_url']	= $this->isValidURL($row['rl_url']);
 $row['rl_approve_date_ger'] = date('d.m.Y', $row['rl_approve_date']);
 $row['picture'] = PICS_SCR_ROOT . $row['bild'];
 $thumb = $this->GRAPHIC_FUNC->makeThumb('./'.RLICO_PATH . $row['rl_bild'],$this->gbl_config['wlu_links_pic_width'],$this->gbl_config['wlu_links_pic_height'], CACHE,TRUE,'resize');
 $row['picture_thumb'] = (($thumb!="") ? PATH_CMS . CACHE . $thumb : "");
 $row['selected_locations']=array();
 $row['counted_link'] = PATH_CMS . 'run.html?cmd=redirect_related_link&id='.base64_encode($row['id']);
}

function add_to_linklist($sql, $prio) {
 $result = $this->db->query($sql);
	while($row = $this->db->fetch_array_names($result)){
		$this->set_link_opt_fe($row);
		$this->link_list[$prio][$row['LID']] = $row;
	} 
}

function get_level1_cat($cid, &$level1) {
 $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS. " WHERE id=" . $cid);
 if ($C['ytc_parent'] > 0) {
 	 $this->get_level1_cat($C['ytc_parent'],$level1);
 }
}


function load_prio2_links($cid,$relevant_country_ids, $destination,$myLocation,$relevant_country_codes,$relevant_countryregion_ids,$relevant_countryregion_codes) {
if (is_array($relevant_country_codes)) foreach ($relevant_country_codes as $key => $code) $relevant_locations[]="'".$code."'";

if ($destination['COUNTRYID'] > 0 && count($relevant_locations) > 0)	{
// Zenario: 1-2-1
if ($cid > 0)	{
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND LC.lm_cat_id=".(int)$cid ."
  AND CM.cm_countryid=".(int)$destination['COUNTRYID'] ."
	AND LOC.lc_location IN (".implode(',',$relevant_locations).")
	GROUP BY L.id
	ORDER BY RAND()";
#	echo $sql;
 $this->add_to_linklist($sql,'prio2');
}	

// Zenario: 1-1-2
 $this->get_level1_cat($cid, $level1);
 $child_cids = $this->build_flatarr_of_children($level1,'LC.lm_cat_id');
 if ($child_cids['sql_cid_filter']!="") {
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND CM.cm_countryid=".(int)$destination['COUNTRYID'] ."
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
  AND (".$child_cids['sql_cid_filter'].")
	GROUP BY L.id
	ORDER BY RAND()";
#	echo $sql;
 $this->add_to_linklist($sql,'prio2');
	}

// Zenario: 2-1-1
 $child_cids = $this->build_flatarr_of_children($cid,'LC.lm_cat_id');
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND CM.cm_countryid IN (". implode(',',$relevant_countryregion_ids) .")
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
  AND LC.lm_cat_id=".(int)$cid ."
	GROUP BY L.id
	ORDER BY RAND()";
#	echo $sql;
 $this->add_to_linklist($sql,'prio2'); 

// Zenario: 1-1-3
 $child_cids = $this->build_flatarr_of_children($cid,'LC.lm_cat_id');
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND CM.cm_countryid=".(int)$destination['COUNTRYID'] ."
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
	GROUP BY L.id
	ORDER BY RAND()";
#	echo $sql;
 $this->add_to_linklist($sql,'prio2');  
}

if ($destination['COUNTRYID']==0)	{
// Zenario: 0-1-1
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND LC.lm_cat_id=".(int)$cid ."
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
	GROUP BY L.id
	ORDER BY RAND()";
	$this->add_to_linklist($sql,'prio2');
// Zenario: 0-2-1
 if (count($relevant_locations) > 0) {
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
	AND LOC.lc_location IN (".implode(',',$relevant_locations).")
  AND LC.lm_cat_id=".(int)$cid ."
	GROUP BY L.id
	ORDER BY RAND()";
	$this->add_to_linklist($sql,'prio2');	
	}
// Zenario: 0-1-2
 if ($child_cids['sql_cid_filter']!="") {
 $this->get_level1_cat($cid, $level1);
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
  AND (".$child_cids['sql_cid_filter'].")
	GROUP BY L.id
	ORDER BY RAND()";
	$this->add_to_linklist($sql,'prio2');		
	}
// Zenario: 0-1-3
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
	AND LOC.lc_location='".$myLocation['ip_ctry']."'  
	GROUP BY L.id
	ORDER BY RAND()";
	$this->add_to_linklist($sql,'prio2');		
}

}

function load_prio1_links($cid,$destination,$myLocation) {
// Zenario: commercial links first
if ($cid > 0)	{
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
 	AND L.rl_commercial=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND LC.lm_cat_id=".(int)$cid ."
	GROUP BY L.id
	ORDER BY RAND()";
 $this->add_to_linklist($sql,'prio1');
}
	
// Zenario: 1-1-1
if ($cid > 0 && $destination['COUNTRYID'] > 0)	{
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND LC.lm_cat_id=".(int)$cid ."
  AND CM.cm_countryid=".(int)$destination['COUNTRYID'] ."
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
	GROUP BY L.id
	ORDER BY RAND()";
#	echo $sql;
 $this->add_to_linklist($sql,'prio1');
}
// Zenario: 0-1-1
if ($destination['COUNTRYID'] == 0)	{
 $sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC  
 WHERE L.rl_approval=1
  AND LC.lm_link_id=L.id
  AND LOC.lc_lid=L.id
 	AND CM.cm_cid=LC.lm_cat_id 
  AND LC.lm_cat_id=".(int)$cid ."
	AND LOC.lc_location='".$myLocation['ip_ctry']."'
	GROUP BY L.id
	ORDER BY RAND()";
	$this->add_to_linklist($sql,'prio1');
}


}

function load_prio3_links() {
	$exclude_ids=array();
	foreach ($this->link_list['prio1'] as $lid => $link) {
		$exclude_ids[]=$lid;
	}
	foreach ($this->link_list['prio2'] as $lid => $link) {
		$exclude_ids[]=$lid;
	}
	$sql="SELECT L.*,L.id AS LID FROM ".TBL_CMS_WLULINKS." L, ".TBL_CMS_WLU_LINKMATRIX." LC,".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_WLU_LINKLOC." LOC
	WHERE L.rl_approval=1
	AND LC.lm_link_id=L.id
	AND LOC.lc_lid=L.id
	AND CM.cm_cid=LC.lm_cat_id
	".((count($exclude_ids) > 0) ? " AND L.id NOT IN (".implode(',',$exclude_ids).") " : "")."
	GROUP BY L.id
	ORDER BY RAND()
	LIMIT " . (int)$this->gbl_config['wlu_total_rl_count'];
	$this->add_to_linklist($sql,'prio3');
}


function load_links_fe($cid,$destination, $relevant_country_ids,$relevant_country_codes,$relevant_countryregion_ids,$relevant_countryregion_codes) {
	$I = new wlu_iptocountry_class();
	$myLocation=$I->get_my_country();
	unset($I);
	$this->link_list = array();
	$this->link_list['prio1']=array();
	$this->link_list['prio2']=array();
	$this->link_list['prio3']=array();
	$this->load_prio1_links($cid,$destination,$myLocation);
	$this->load_prio2_links($cid,$relevant_country_ids,$destination,$myLocation,$relevant_country_codes,$relevant_countryregion_ids,$relevant_countryregion_codes);
	$this->load_prio3_links();

	if (count($this->link_list['prio1']) > 0) {
		foreach ($this->link_list['prio1'] as $lid => $link) {
			unset($this->link_list['prio2'][$lid]);
			unset($this->link_list['prio3'][$lid]);
		}
	}
	if (count($this->link_list['prio2']) > 0) {
		foreach ($this->link_list['prio2'] as $lid => $link) {
			unset($this->link_list['prio3'][$lid]);
		}
	}

	$this->link_list['prio1']=$this->get_part_of_array($this->link_list['prio1'],0,2);
	$prio2_count = 4 - count($this->link_list['prio1']);
	$this->link_list['prio2']=$this->get_part_of_array($this->link_list['prio2'],0,$prio2_count);


	if (count($this->link_list['prio2']) > 0) {
		foreach ($this->link_list['prio2'] as $key => $link) {
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_views=rl_views+1 WHERE id=" . $link['LID']);
		}
	}
	if (count($this->link_list['prio1']) > 0) {
		foreach ($this->link_list['prio1'] as $key => $link) {
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_views=rl_views+1 WHERE id=" . $link['LID']);
		}
	}

	if (count($this->link_list['prio3']) > 0) {
		$k=0;
		foreach ($this->link_list['prio3'] as $key => $link) {
			$k++;
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_views=rl_views+1 WHERE id=" . $link['LID']);
			if ($k==3) break;
		}
	}

	#	$prio3_count = 7 - count($this->link_list['prio1']) - count($this->link_list['prio2']);
	#	$this->link_list['prio3']=$this->get_part_of_array($this->link_list['prio3'],0,$prio3_count);
	#echo count($this->link_list['prio3']);
}

function set_link_opt(&$row) {
 $row['print_link'] = str_replace(array('http://'),'',$row['rl_url']);
 $row['parsed_url'] = parse_url($row['rl_url']);
 $row['print_url']  = str_replace('www.','',$row['parsed_url']['host']);
 $row['rl_approve_date_ger'] = date('d.m.Y', $row['rl_approve_date']);
 $row['picture'] = PICS_SCR_ROOT . $row['bild'];
 $row['picture_thumb'] = PATH_CMS . 'admin/' . CACHE . $this->GRAPHIC_FUNC->makeThumb('../'.RLICO_PATH . $row['rl_bild'],100,100,'admin/' . CACHE,TRUE,'resize');
 $row['RLFCK'] = getFCK('RL[rl_sp_comment]', $row['rl_sp_comment'],100,'Basic');
 $row['selected_locations']=array();
 
}

function cmd_edit_link() {
	$this->RELLINK['rl'] = $this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE id=".(int)$_GET['id']." LIMIT 1");
	$this->set_link_opt($this->RELLINK['rl']);
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_WLU_LINKLOC." WHERE lc_lid=".(int)$_GET['id']);
	while($row = $this->db->fetch_array_names($result)){
		$this->RELLINK['rl']['selected_locations'][] = $row['lc_location'];
	}
	
	$RH = $this->validate_url_status($this->RELLINK['rl']['rl_url']);
	$this->RELLINK['rl']['page_ok'] 	= ($RH['http_code']==200);
  $this->RELLINK['rl']['page_info'] = $RH;
  unset($RH);
  
	$countries=array();
	$r=$this->db->query("SELECT L.* FROM  ".TBL_CMS_WLU_COUNTRY_TO_CAT." CM, ".TBL_CMS_LAND." L , ".TBL_CMS_WLU_LINKMATRIX." LC
	WHERE LC.lm_cat_id=CM.cm_cid
	AND L.id=CM.cm_countryid
	AND LC.lm_link_id=".(int)$this->RELLINK['rl']['id']);
	while($rc = $this->db->fetch_array_names($r)){
		$countries[]=$rc['land'];
	}
	sort($countries);
	$this->RELLINK['rl']['land'] = implode(', ',$countries);
	$this->RELLINK['rl']['country_count'] = count($countries);
}

function load_locations() {
 $I = new wlu_iptocountry_class();
 $I->load_country_table();
 $this->RELLINK['ccodes'] = $I->ccodes;
 unset($I);
}

function cmd_show_meta_import() {
	if (count($this->TCR->POST['metaids']) > 0) {
		foreach($this->TCR->POST['metaids'] as $key => $wert) {
			$RL = $this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE id=".(int)$wert." LIMIT 1");
			$metas=getUrlData($RL['rl_url']);
			if ($metas['title']=="SITE NOT FOUND") $this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_title='SITE NOT FOUND' WHERE id=".$wert." LIMIT 1");
			$RL['metas'] = (array)$metas;
			$this->RELLINK['meta_rl'][] = $RL;
		}
	}
}

function parse_to_smarty() {
	$this->smarty->assign('RELLINK', $this->RELLINK);
}

function cmd_save_link() {
  $id=$this->save_link($this->TCR->POST['RL'],$this->TCR->POST['id'],$_FILES,$this->TCR->POST['LOCATIONS']);
	$this->TCR->reset_cmd('edit_link');
	$this->TCR->add_url_tag('id', $id);
	$this->TCR->add_msg('{LBL_SAVED}');	  
}

function cmd_delete_link() {
	$this->delete_link($this->TCR->GET['id']);
	$this->TCR->add_msg('{LBL_DELETED}');	 
}

function cmd_axdelete_item() {
	$parts=explode('-',$this->TCR->GET['id']);
	$this->delete_link((int)$parts[1]);
	die;
}

function cmd_axapprove_item() {
	$parts=explode('-',$this->TCR->GET['id']);
	$id=(int)$parts[1];
	$this->approve_link($this->TCR->GET['value'], $id);
	die;
}

function cmd_axapprovegroup() {
	$parts=explode('-',$this->TCR->GET['id']);
	$id=(int)$parts[1];
	$this->approve_group($this->TCR->GET['value'], $id);
	die;
}



function cmd_axdelete_icon() {
 $parts=explode('-',$this->TCR->GET['id']);
 $id = (int)$parts[1];
 $linklist_obj = $this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE id=".$id." LIMIT 1"); 
 delete_file(CMS_ROOT . RLICO_PATH . $linklist_obj['rl_bild']);
 $this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_bild='' WHERE id=".$id);
 die;
}

function cmd_axdelete_flash() {
 $parts=explode('-',$this->TCR->GET['id']);
 $id = (int)$parts[1];
 $linklist_obj = $this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE id=".$id." LIMIT 1"); 
 delete_file(CMS_ROOT . RLICO_PATH . $linklist_obj['rl_flash']);
 $this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_flash='' WHERE id=".$id);
 die;
}


function save_link($FORM,$id,$FILES,$LOCATIONS=array()) {
	$FORM['rl_url'] = (!strstr($FORM['rl_url'],'http://')) ? 'http://' . $FORM['rl_url'] : $FORM['rl_url'];
	if (substr($FORM['rl_url'], -1, 1)=='/') $FORM['rl_url'] = substr($FORM['rl_url'], 0, strlen($FORM['rl_url'])-1);
	if ($id==0) {
		$FORM['rl_mid_name'] = mysql_real_escape_string($_SESSION['mitarbeiter_name']);
		$FORM['rl_mid'] = $_SESSION['admin_obj']['id'];
		$FORM['rl_approval'] = 1;
		$id=insertTable(TBL_CMS_WLULINKS, $FORM);
		$this->VPLOG->vp_addlog('add RL link ['.$id.']: '.$FORM['rl_title'], 'RL_LINK_ADD');
	} else {
	 updateTable(TBL_CMS_WLULINKS,'id',$id,$FORM);
	 $this->VPLOG->vp_addlog('update RL link ['.$id.']: '.$FORM['rl_title'], 'RL_LINK_UPDATE');
	}
	if (!is_dir(CMS_ROOT . RLICO_PATH))  mkdir(CMS_ROOT . RLICO_PATH, 0775);
	$this->set_link_to_cat($id,$FORM['rl_cat_id']);
	// ICON
	if ($FILES['aicon']['name']!="") {
		if (validateUploadFile($FILES['aicon']))	 {
		$RetVal = explode ('.', $FILES['aicon']['name']);
		$file_extention = strtolower($RetVal[count($RetVal)-1]);
		if ($file_extention=='jpeg') $file_extention='jpg';
		$new_file_name = CMS_ROOT . RLICO_PATH . 'related_link_icon_'.(int)$id . '.' . $file_extention;
		move_uploaded_file($FILES['aicon']['tmp_name'], $new_file_name);
		clean_cache_like($new_file_name);
		chmod($new_file_name, 0755);
		$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_bild='".basename($new_file_name)."' WHERE id=".(int)$id." LIMIT 1");
	}
	}
	// FLASH
	if ($FILES['flashfile']['name']!="") {
			$RetVal = explode ('.', $FILES['flashfile']['name']);
			$file_extention = strtolower($RetVal[count($RetVal)-1]);
			if ($file_extention=='swf')	 {
			$new_file_name = CMS_ROOT . RLICO_PATH . 'related_link_swf_'.(int)$id . '.' . $file_extention;
			move_uploaded_file($FILES['flashfile']['tmp_name'], $new_file_name);
			clean_cache_like($new_file_name);
			chmod($new_file_name, 0755);
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_flash='".basename($new_file_name)."' WHERE id=".(int)$id." LIMIT 1");
		}
	}		
	
	if (is_array($LOCATIONS)) {
	 $this->db->query("DELETE FROM ".TBL_CMS_WLU_LINKLOC." WHERE lc_lid=".$id);
	 foreach ($LOCATIONS as $key => $value) {
	  $this->db->query("INSERT INTO ".TBL_CMS_WLU_LINKLOC." (lc_location,lc_lid) VALUES ('".$key."', ".$id.")");
	 }
	}	
	return $id;
}

function load_video_cats() {
$menutree = new nestedArrClass(); 
$menutree->init(
	array(
		'label_column' 	=> 'ytc_name',
		'label_parent' 	=> 'ytc_parent',
		'label_id' 			=> 'id',
		'sign'					=> ' -> '
	)
);
$menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS. " ORDER BY ytc_parent,ytc_name", 0, 0, -1); 
$this->RELLINK['cat_selectbox'] =  $menutree->outputtree_select();
unset($menutree);
}

function init() {
	$this->load_video_cats();
	$this->load_locations();  
}

function cmd_sync_geoips() {
	$G = new wlu_iptocountry_class();
	$G->sync();
	unset($G);
	$this->TCR->add_msg('{LBL_SAVED}');
	$this->TCR->set_just_turn_back(true);
}

function set_report_filter() {
 $this->RELLINK['reports']['filter'] = $this->TCR->REQUEST['QFILTER'];
 $FirstDay = mktime(0, 0, 0, date('m'), 1, date('Y'));
 $lastDay = idate('d', mktime(0, 0, 0, (date('m') + 1), 0, date('Y')));
 if ($this->RELLINK['reports']['filter']['r_from']=="" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
  $this->RELLINK['reports']['filter']['r_from']=date('d.m.Y', $FirstDay);
 }
 if ($this->RELLINK['reports']['filter']['r_to']=="" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
  $this->RELLINK['reports']['filter']['r_to']=$lastDay.date('.m.Y');
 }
 
  if ($this->RELLINK['reports']['filter']['qr_from']=="" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
  $this->RELLINK['reports']['filter']['qr_from']=date('d.m.Y', $FirstDay);
 }
  if ($this->RELLINK['reports']['filter']['qr_to']=="" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
  $this->RELLINK['reports']['filter']['qr_to']=$lastDay.date('.m.Y');
 }
 
 $E = new wlu_employee_class();
 $E->load_employees();
 $this->RELLINK['employees'] = $E->employees;
 unset($E); 
 $this->RELLINK['reports']['csv_exists'] = file_exists(CMS_ROOT . 'admin/cache/'.$this->xls_file_name);
}


function cmd_rp_rloverview() {
	$this->load_links($this->TCR->REQUEST['QFILTER'], $this->TCR->REQUEST['start'], $this->TCR->REQUEST['col'], $this->TCR->REQUEST['direc'],100);
	if ($this->TCR->REQUEST['BUTTON']=='XLS') {
		$this->cmd_create_xls();
		return;
	}
}



function create_xls($start=-1) {
	$trenner = "\t";
	$start = (int)$start;

	$fields = array(
	array('label' => 'Linkname','sql' => 'rl_title'),
	array('label' => 'URL','sql' => 'rl_url'),
	array('label' => 'Destination','sql' => 'land'),
	array('label' => 'Location','sql' => 'locations'),
	array('label' => 'Category','sql' => 'ytc_name'),	
	array('label' => 'Category 1','sql' => 'cat_path_0'),
	array('label' => 'Category 2','sql' => 'cat_path_1'),
	array('label' => 'Category 3','sql' => 'cat_path_2'),	
	array('label' => 'Text','sql' => 'rl_sp_comment'),
	array('label' => 'Approved Date','sql' => 'rl_approve_date_ger'),
	array('label' => 'Author','sql' => 'rl_mid_name')
	);

	$fname = CMS_ROOT . 'admin/cache/'.$this->xls_file_name;
	if ($start <= 0) {
		if (file_exists($fname)) @unlink($fname);
	}
	$fp = fopen($fname, 'a');
	if ($start <= 0) {
		foreach ($fields as $ar) $f[]=$ar['label'];
		fputcsv($fp, $f,$trenner,'"');
	}

 foreach ($this->link_list as $key => $row) {
 		$f=array();
 		foreach ($fields as $ar) $f[$ar['sql']]=$this->csv_formated_iso($row[$ar['sql']]);
		fputcsv($fp, $f,$trenner,'"');
		$pcount++;
	}
	fclose($fp);
	return $pcount;
}

function cmd_create_xls() {
	global $content, $db_zugriff, $smarty,$crj_obj;
 if ($_REQUEST['start']==0)	{
 	$_SESSION['STATUSBAR']['starttime']=time();
 	$_SESSION['STATUSBAR']['rounds']=0;
}
 $_SESSION['STATUSBAR']['rounds']++;	
 $QFILTER = $this->TCR->REQUEST['QFILTER'];
 $this->load_links($this->TCR->REQUEST['QFILTER'], $this->TCR->REQUEST['start'], $this->TCR->REQUEST['col'], $this->TCR->REQUEST['direc'],100);
 $pcount=$this->create_xls((int)$_REQUEST['start']);
 if ($pcount > 0) {
 	 	$_REQUEST['start']+=100;
 	 	header("Refresh: 1;  URL= ".$_SERVER['PHP_SELF']."?".http_build_query($_REQUEST)); 
		$STATUSBAR = array(
			'procent'			=> 100/$this->RELLINK['counts']['link_filtered_count'] * ($_REQUEST['start'] - 100 + $pcount),
			'done'				=> $_REQUEST['start'] - 100 + $pcount,
			'total'				=> $this->RELLINK['counts']['link_filtered_count'],
			'timenow'			=> time(),
			'rounds'			=> $_SESSION['STATUSBAR']['rounds'],
			'timediff'		=> time() - $_SESSION['STATUSBAR']['starttime'],
			'timediffmin'	=> round((time() - $_SESSION['STATUSBAR']['starttime']) / 60,2),
			'starttime'		=> $_SESSION['STATUSBAR']['starttime'],
			'totaltime'		=> round(((((time() - $_SESSION['STATUSBAR']['starttime'])) / $_SESSION['STATUSBAR']['rounds']) * ($this->RELLINK['counts']['link_filtered_count']/100)) / 60,2),
			'resttime'		=> round((((((time() - $_SESSION['STATUSBAR']['starttime'])) / $_SESSION['STATUSBAR']['rounds']) * ($this->RELLINK['counts']['link_filtered_count']/100)) - (time() - $_SESSION['STATUSBAR']['starttime'])) / 60,2)			
		);
		$this->smarty->assign('STATUSBAR', $STATUSBAR);
		$content.= '<% include file="statusbar.tpl" %>';		
 		include("footer.php"); 	 	
 	} else {
 		header("location: ".$_SERVER['PHP_SELF']."?setcmd=rp_rloverview&epage=".$_GET['epage']."&section=report&msg=".base64_encode("{LBL_SAVED}"));
	}
 exit; 
}

function cmd_get_xls_file() {
	echo_excel_header($this->TCR->GET['fname']);
	echo file_get_contents(CMS_ROOT . 'admin/cache/'.$this->TCR->GET['fname'].'.xls');
	exit;
}

function cmd_rp_validate() {
	global $content, $db_zugriff, $smarty,$crj_obj;
	$start = (int)$this->TCR->REQUEST['start'];
	if ($start==0)	{
		$_SESSION['STATUSBAR']['starttime']=time();
		$_SESSION['STATUSBAR']['rounds']=0;
		$_SESSION['STATUSBAR']['foundokitems']=0;
		$_SESSION['STATUSBAR']['founditems']=0;
	}
	$_SESSION['STATUSBAR']['rounds']++;
	$items_per_cycle=10;
	$QFILTER = $this->TCR->POST['QFILTER'];

	$result = $this->db->query("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE 1 "
	. (($QFILTER['type']=='all_valid') ? " AND rl_approval=1" : "") 
	. (($QFILTER['type']=='all_invalid') ? " AND rl_approval=0" : "") .
	" ORDER BY id
	LIMIT ".$start.",".$items_per_cycle);
	while($row = $this->db->fetch_array_names($result)){
		$k++;
	#	echo $row['rl_url'].'<br>';
		$RH = $this->validate_url_status($row['rl_url']);
		$page_ok 	= ($RH['http_code']==200 || $RH['http_code']==302);
		if ($page_ok==false) {
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_approval=0");
			$_SESSION['STATUSBAR']['founditems']++;
		} else {
			$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_approval=1");
			$_SESSION['STATUSBAR']['foundokitems']++;
		}
	}
	$total_count = $this->db->num_rows($result);
	$total_count = ($total_count==0) ? 0.000001 : (int)$total_count;
	if ($k >= 1) {
		$_REQUEST['start']+=$items_per_cycle;
		header("Refresh: 1;  URL= ".$_SERVER['PHP_SELF']."?".http_build_query(array('QFILTER' => $QFILTER)).http_build_query($_REQUEST));
		$STATUSBAR = array(
		'procent'			=> 100/$total_count * ($_REQUEST['start'] - $items_per_cycle + $pcount),
		'done'				=> $_REQUEST['start'] - $items_per_cycle + $pcount,
		'total'				=> $this->RELLINK['counts']['link_filtered_count'],
		'timenow'			=> time(),
		'rounds'			=> $_SESSION['STATUSBAR']['rounds'],
		'timediff'		=> time() - $_SESSION['STATUSBAR']['starttime'],
		'timediffmin'	=> round((time() - $_SESSION['STATUSBAR']['starttime']) / 60,2),
		'starttime'		=> $_SESSION['STATUSBAR']['starttime'],
		'totaltime'		=> round(((((time() - $_SESSION['STATUSBAR']['starttime'])) / $_SESSION['STATUSBAR']['rounds']) * ($this->RELLINK['counts']['link_filtered_count']/100)) / 60,2),
		'resttime'		=> round((((((time() - $_SESSION['STATUSBAR']['starttime'])) / $_SESSION['STATUSBAR']['rounds']) * ($this->RELLINK['counts']['link_filtered_count']/100)) - (time() - $_SESSION['STATUSBAR']['starttime'])) / 60,2)
		);
		$this->smarty->assign('STATUSBAR', $STATUSBAR);
		$content.= '<% include file="statusbar.tpl" %>';
		include("footer.php");
		} else {
			header("location: ".$_SERVER['PHP_SELF']."?epage=".$_GET['epage']."&section=validation&msg=".base64_encode("{LBL_DONE} ".$_SESSION['STATUSBAR']['founditems']." disapproved, ".$_SESSION['STATUSBAR']['foundokitems']." approved"));
		}
		exit;
	}

}
?>
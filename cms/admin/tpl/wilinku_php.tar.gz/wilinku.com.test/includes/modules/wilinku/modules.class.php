<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2009     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}

class modules_class extends tc_class {

function __construct() {
	parent::tc_class();
}

function global_script_loader($file) {
 $dh  = opendir(MODULE_ROOT);
	while (false !== ($module_loader_dir = readdir($dh))) {
		if ($module_loader_dir!='.' && $module_loader_dir!='..' && $module_loader_dir!='' && is_dir(MODULE_ROOT.$module_loader_dir)) {
			// Loading Script
			$fname=MODULE_ROOT . $module_loader_dir . '/'.$file.'.inc.php';
			if (file_exists($fname)) {
				include($fname);
			}
		}
	}
}

}

?>
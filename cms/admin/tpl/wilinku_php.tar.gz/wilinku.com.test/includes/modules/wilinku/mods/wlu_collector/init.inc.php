<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
if (IN_SIDE != 1) {
    header('location:' . PATH_CMS . 'index.html');
    exit;
}

$module_id = 'wlu_collector';

$TREE_TYPE['ytcat_tree'] = array('tree_name' => 'Video Punch Categories', 'id' => 'ytcat_tree', 'init' => WLU_MOD_ROOT . $module_id . '/tree.init.inc', 'tpl' =>
    'wlu_yttree.tpl', 'php' => WLU_MOD_ROOT . $module_id . '/wlu_collector.inc', 'class_name' => 'wlu_collector_class', #PHP Master Class Name of Modul
    'use_own_entry_point' => true);

$MODULE[$module_id] = array('module_name' => 'WiLinkU Video Punch', 'intern_aktion' => '', 'id' => $module_id, 'php' => WLU_MOD_ROOT . $module_id .
    '/wlu_collector.inc', 'hasperm' => true, 'epage' => array('wlu_vcollector.inc'), #admin. PHP Scripts
    'epage_dir' => WLU_MOD_ROOT, 'is_content_page' => false, 'class_name' => 'wlu_collector_class', #PHP Master Class Name of Modul
    );


include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_vpconstants.inc.php');

#*********************************
# VIDEO PUNCH
#*********************************
include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_colmaster.class.php');
include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_adhocvideo.class.php');
include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_vsearch.class.php');
include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_yt.class.php');
include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_vimeo.class.php');
include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_query.class.php');
include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_comments.class.php');
include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_relatedlinks/wlu_links.class.php');

if (ISADMIN == 1) {
    include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_collector.class.php');
    #include(WLU_MOD_ROOT . $MODULE[$module_id ]['id'] . '/wlu_vplog.class.php');
    $WLU_COLLECTOR_OBJ = new wlu_collector_class();
}
else {
    include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_fe_videopunch.class.php');
    $VIDEOPUNCH = new wlu_videopunch_class();
    $VIDEOPUNCH->init();    
    if ($_GET['page'] == START_PAGE || $_GET['page'] == 0) {
        $VIDEOPUNCH->load_start_page_settings();        
        $VIDEOPUNCH->VP['vp_active'] = false;
        $VIDEOPUNCH->parse_to_smarty();
    }
}

?>
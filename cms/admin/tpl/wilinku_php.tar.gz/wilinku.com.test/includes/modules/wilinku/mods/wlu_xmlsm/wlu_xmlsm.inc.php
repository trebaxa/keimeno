<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2010    									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

if (IN_SIDE != 1) {
    header('location:' . PATH_CMS . 'index.html');
    exit;
}

$WLUFBWP->TCR->interpreterfe();
?>
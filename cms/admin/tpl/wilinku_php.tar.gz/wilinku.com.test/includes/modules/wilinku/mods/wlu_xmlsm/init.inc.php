<?PHP

$module_id = 'wlu_xmlsm';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU XML Sitemap',
		'intern_aktion' 	=> '',
		'id' 				=> $module_id,
		'php' 				=> MODULE_DIR . $module_id . '/wlu_xmlsm.inc',
		'hasperm' 			=> false,
		'epage' 			=> array('wlu_xmlsm.inc'),
		'epage_dir'			=> WLU_MOD_ROOT,
		'is_content_page'	=> true
		);

include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_xmlsm.class.php');
include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/wlu_sitemapini.class.php');
DEFINE('TBL_CMS_WLUXMLSM', TBL_CMS_PREFIX.'wlu_sitemaps');
$WLUXMLSM = new wlu_xmlsm_class();
?>
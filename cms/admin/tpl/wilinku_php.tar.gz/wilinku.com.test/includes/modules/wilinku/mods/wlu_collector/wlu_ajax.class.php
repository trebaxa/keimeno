<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_ajax_class extends wlu_videopunch_class {

    function __construct() {
        parent::__construct();
        $this->TCR = new tc_request_class($this);
    }

    function cmd_axloadregions() {
        $this->regions = array();
        $sql = "SELECT *, CO.id AS CONID, R.id AS REGIONID FROM " . TBL_CMS_LANDCONTINET . " CO, " . TBL_CMS_LANDREGIONS . " R
	WHERE R.lr_continet_id=CO.id
	AND CO.id=" . (int)$this->TCR->REQUEST['conid'] . "
	ORDER BY R.lr_name";
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            if ($row['lr_video_count'] > 0)
                $this->regions[] = $row;
        }
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('
	<select size="10" id="regionselection" onClick="load_countries(this.options[this.selectedIndex].value);">
	<% foreach from=$VP.regions item=region %>
	<option value="<% $region.REGIONID %>"><% $region.lr_name  %></option>
	<%/foreach%>
	</select>	
	 <% if (count($VP.regions)==1) %>
  <script>
  var sobj = document.getElementById(\'regionselection\');
  load_countries(sobj.options[0].value);
 </script>
 <%/if%>
	');
    }

    function cmd_axloadcountries() {
        foreach ($this->countries as $key => $value) {
            if ($this->TCR->REQUEST['regionid'] == $value['REGIONID']) {
                $this->add_video_counts($value);
                if ($value['video_count'] > 0) {
                    $countries[] = $value;
                }
            }
        }
        $this->countries = $countries; #array();
        /*	$sql = "SELECT *,C.id COUNTRYID, R.id AS REGIONID FROM ".TBL_CMS_LAND." C, ".TBL_CMS_LANDREGIONS." R
        WHERE C.region_id=R.id	AND R.id=".(int)$this->TCR->REQUEST['regionid'];
        $result = $this->db->query($sql);
        while($row = $this->db->fetch_array_names($result)) {
        $this->countries[]=$row;
        }		
        */
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('
	<select size="10" id="countrylist_select">
	<% foreach from=$VP.countries item=country %>
	<option value="<% $country.COUNTRYID %>"><% $country.land  %></option>
	<%/foreach%>
	</select>');
    }


    function cmd_axloadcatree() { //CAN BE DELETED
        $_SESSION['WLU']['selected']['level1'] = (int)$this->TCR->REQUEST['level1'];
        $this->load_vptree_by_parent((int)$this->TCR->REQUEST['level1']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wluvptree_10051.tpl" %>');

    }

    function cmd_axloadvideos() {
        $this->load_videos($this->TCR->REQUEST['cid'], (int)$this->TCR->REQUEST['start']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wluvpliste_10052.tpl" %>');
    }

    function cmd_axload_most_viewed() {
        $this->load_videos_ordered('yt_views', 5, $this->VP['sp_videos']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wlu_most_viewed_startpage_10061.tpl" %>');
    }

    function cmd_axload_latest() {
        $this->load_videos_ordered('yt_apptime', 5, $this->VP['sp_videos']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wlu_most_viewed_startpage_10061.tpl" %>');
    }

    function cmd_axload_most_comments() {
        $this->load_videos_ordered('yt_comment_count', 5, $this->VP['sp_videos']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wlu_most_viewed_startpage_10061.tpl" %>');
    }


    function cmd_load_right_column_videolist() {
        ECHORESULTCOMPILEDFE('<% include file="wlu_vp_right_column_10071.tpl" %>');
    }

    function cmd_axload_samepick_videos() {
        #$this->load_videos($this->TCR->REQUEST['cid'], 0, $this->gbl_config['wlu_samepick_count']);
        $this->VP['video_list'] = $this->load_samepic_videos($this->TCR->REQUEST['cid']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wlu_vp_detail_site_-_related_videos_-_video_item_10076.tpl" %>');
    }

    function cmd_axload_realted_videos() {
        $V = $this->load_single_video($this->TCR->REQUEST['vid'], $this->selected['countryid'], $this->selected['cid']);
        $this->load_related_videos($V);
        $this->VP['video_list'] = $this->VP['related_videos'];
        unset($this->VP['related_videos']);
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wlu_vp_detail_site_-_related_videos_-_video_item_10076.tpl" %>');
    }

    function cmd_axget_playlist() {
        if ($this->TCR->REQUEST['samepick'] == 1) {
            // SAME PICK PLAYLIST
            $this->load_videos($this->TCR->GET['cid'], 0);
        }
        else {
            // RELATED PLAYLIST
            $V = $this->load_single_video($this->TCR->GET['vid']);
            $this->load_related_videos($V);
            $this->VP['video_list'] = $this->VP['related_videos'];
        }
        include_once ('wlu_jwxml.class.php');
        $JW_XML = new wlu_jwxmlplaylist_class();
        ECHO $JW_XML->create_playlist($this->VP['video_list']);
        unset($JW_XML);
        die;
    }

    function cmd_axsetautoplay() {
        $vid = strval(trim($this->TCR->REQUEST['vid']));
        $V = $this->load_single_video($vid);
        $V['samepick'] = (int)$this->TCR->REQUEST['samepick'];
        $this->add_related_cats_to_video($V);
        // validate SESSION category
        if (!in_array($_SESSION['WLU']['selected']['cid'], $V['related_cids'])) {
            $_SESSION['WLU']['selected']['cid'] = $this->selected['cid'] = (int)$V['CID'];
        }
        $V['CID'] = $_SESSION['WLU']['selected']['cid'];
        $this->set_level1_by_video($V);
        $this->VP['video'] = $V;

        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wluvpjwplayerplugin_10055.tpl" %>');
    }

    function parse_to_smarty() {
        parent::parse_to_smarty();
        $this->VP = array_merge((array )$this->VP, array('continents' => $this->continents, 'regions' => $this->regions, 'countries' => $this->countries, ));
        $this->smarty->assign('VP', $this->VP);
    }


    function cmd_axloadtree() {
        $item_count = 10;
        $parent = (int)$this->TCR->GET['cid'];
        $start = (int)$_SESSION['WLU']['treestart_next'];
        $start = ($start == 0) ? $item_count : $start;
        $start = 10;
        $stop = $start + $item_count;

        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'approval_col' => 'ytc_approval', 'visible_col' =>
            'ytc_visible', ));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_name", $parent, 0, -1);
        $this->remove_countries_by_list(&$menutree, $this->allowed_countries);
        $menutree->build_flat_obj_arr($menutree->menu_array, $flat_menu_arr);
        $new_arr = array();
        $counter = 0;
        $this->set_menu_opt($menutree->menu_array, $new_arr, $flat_menu_arr, $counter);
        $this->merge_subcounts($new_arr, $tree_with_sub_counts, $flat_menu_arr);
        $this->remove_by_range($tree_with_sub_counts, $vptree, $start, $stop);
        #echo $start.'='.$stop;
        #echoarr($vptree);
        $this->VP['vptree'] = $tree_with_sub_counts;
        unset($menutree);
        $_SESSION['WLU']['treestart_next'] += $item_count;
        $_SESSION['WLU']['treestart_previous'] -= $item_count;
        $this->parse_to_smarty();
        ECHORESULTCOMPILEDFE('<% include file="wluvptree_10051.tpl" %>');
    }

   

}

<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}

class wlu_company_class extends wilinku_class {
	var $redirect_page = 'wlu_company.inc';
	var $COMPANY 		= array();
	
function __construct() {
	parent::__construct();
}

function interpreter($method) {
	if (method_exists($this, $method)) {
		return $this->$method();
	}
}

function load_companies() {
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_WLU_COMPANIES." WHERE 1 ORDER BY co_name");
	while($row = $this->db->fetch_array_names($result)){
		$row['icons'][] = genEditImgTagADMIN($row['id']);
		$row['icons'][] = genDelImgTagADMINConfirm($row['id'], 'delete_company', '{LBLA_CONFIRM}');
	#	$row['icons'][] = '<a title="{LBL_EMPLOYEES}" href="'.$_SERVER['PHP_SELF'].'?epage='.$_GET['epage'].'&aktion=listemp&id='.$row['id'].'"><img src="./images/employee.png" border="0"></a>';
		$row['icons'][] = '<a href="'.$_SERVER['PHP_SELF'].'?epage='.$_GET['epage'].'&aktion=countryrelated&id='.$row['id'].'"><img src="./images/countryrelated.png" border="0"></a>';
		$row['empcount'] 	= getCount(TBL_CMS_ADMINS,'id',"mi_company_id=" . $row['id']);#getCount(TBL_CMS_ADMINMATRIX, 'id',"em_relid=".$row['id']." AND em_type='COM'");
		#$row['empmatrix'] = $this->load_employee_company_matrix($row['id']);
		$row['empmatrix'] = $this->loaded_company['employee_matrix'] = $this->load_employee_ids($row['id']); # 1 to 1 connection: 1 employee to 1 company (NO MATRIX)
		$row['employees']=array();
		/*
		$sql="";
		if (is_array($row['empmatrix'])) {
			foreach ($row['empmatrix'] as $emp_id) {
				$sql.=(($sql!="") ? " OR " : '') . " M.id=" . (int)$emp_id;
			}
		}
	
		if ($sql!="") { 
			$result2 = $this->db->query("SELECT * FROM ".TBL_CMS_ADMINS." M
			LEFT JOIN ".TBL_CMS_ADMINGROUPS." G ON (G.id=M.gid) 
  		WHERE (".$sql.")
  		GROUP BY M.id 
  	  ORDER BY M.mitarbeiter_name");
			while($rowe = $this->db->fetch_array_names($result2)){
				$row['employees'][] = $rowe;
			}
		}
		*/
		$result2 = $this->db->query("SELECT * FROM ".TBL_CMS_ADMINS." M
			LEFT JOIN ".TBL_CMS_ADMINGROUPS." G ON (G.id=M.gid) 
  		WHERE M.mi_company_id=".$row['id']."
  		GROUP BY M.id 
  	  ORDER BY M.mitarbeiter_name");
			while($rowe = $this->db->fetch_array_names($result2)){
				$row['employees'][] = $rowe;
			}		
		$this->companies[]=$row;
	}
	$this->COMPANY['companies']	= $this->companies;

}

function load_company_country_matrix($em_compid) {
	$this->country_id_matrix=array();
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_ADMINMATRIX." WHERE em_type='COMCOU' AND em_compid=".(int)$em_compid);
	while($row = $this->db->fetch_array_names($result)){
		$this->country_id_matrix[$row['em_relid']]=$row['em_relid'];
	}
	return $this->country_id_matrix;
}

function save_company_matrix() {
	$this->db->query("DELETE FROM ".TBL_CMS_ADMINMATRIX." WHERE em_type='COM' AND em_relid=" . (int)$_POST['id']);
	foreach ($_POST['employee_ids'] as $key => $id) {
		$EM = array(
			'em_mid'   			=> (int)$id,
			'em_relid'  		=> (int)$_POST['id'],
			'em_type'   		=> 'COM'
		);
		insertTable(TBL_CMS_ADMINMATRIX, $EM);
	}
	return array(
		'status' 		=> true,
		'msge' 			=> '',
		'msg' 			=> '{LBL_SAVED}',
		'redirect' 	=> $_SERVER['PHP_SELF'] . '?id='.$_POST['id'].'&epage='.$this->redirect_page.'&aktion=emp'
	);
}

function load_employee_company_matrix($company_id) {
	$this->employee_ids_matrix = array();
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_ADMINMATRIX." WHERE em_type='COM' AND em_relid=".(int)$company_id);
	while($row = $this->db->fetch_array_names($result)){
		$this->employee_ids_matrix[]=$row['em_mid'];
	}
	return $this->employee_ids_matrix;
}

function load_employee_ids($id) {
	$ids=array();
	$result = $this->db->query("SELECT * FROM ". TBL_CMS_ADMINS ." WHERE mi_company_id=".(int)$id);
	while($row = $this->db->fetch_array_names($result)){
		$ids[] = $row['id'];
	}
	return $ids;
}

function load_all_countries_by_company($company_id) {
$this->countries=array();	
	$result = $this->db->query("SELECT *,C.id COUNTRYID FROM ".TBL_CMS_ADMINMATRIX." M
		, ".TBL_CMS_LAND." C
		, ".TBL_CMS_LANDCONTINET." CO 
		, ".TBL_CMS_LANDREGIONS." R
		WHERE M.em_type='COMCOU' AND M.em_compid=".(int)$company_id . " 
		AND M.em_relid=C.id
		AND R.lr_continet_id=CO.id
		AND C.region_id=R.id
		");
	while($row = $this->db->fetch_array_names($result)){
		$row['country_rel'] = 'C';
		$this->countries[$row['lr_continet_id']][$row['region_id']][$row['em_relid']]=$row;
		
	}
	foreach ($this->countries as $continetid => $regions) {
		$r=$this->get_first_element($regions);
		$c=$this->get_first_element($r);
		$this->countries[$continetid]['lc_name'] = $c['lc_name'];
		foreach ($regions as $regionid => $country) {
			$c=$this->get_first_element($country);
			$this->countries[$continetid][$regionid]['lr_name'] = $c['lr_name'];
		}
	}
	return $this->countries;
}

function load_company() {
	$this->load_company_by_id($_GET['id']);
}

function load_company_by_id($id) {
	$id = (int)$id;
	$this->loaded_company = $this->db->query_first("SELECT * FROM ". TBL_CMS_WLU_COMPANIES ." WHERE id=".$id." LIMIT 1");
  #$this->loaded_company['employee_matrix'] = $this->load_employee_company_matrix($id);
  $this->loaded_company['employee_matrix'] = $this->load_employee_ids($id); # 1 to 1 connection: 1 employee to 1 company (NO MATRIX)
  $this->loaded_company['country_matrix'] = $this->load_company_country_matrix($id);
  $this->loaded_company['countries'] = $this->load_all_countries_by_company($id);
  $this->COMPANY['loaded_company']	= $this->loaded_company;	
}

function add_country_matrix() {
	$this->db->query("DELETE FROM ".TBL_CMS_ADMINMATRIX." WHERE em_type='COMCOU' AND em_compid=" . (int)$_POST['company_id']);
	if (is_array($_POST['country_ids'])) {
	foreach ($_POST['country_ids'] as $key => $id) {
		$EM = array(
			'em_compid'  	=> (int)$_POST['company_id'],
			'em_relid'  	=> $id,
			'em_type'   	=> 'COMCOU'
		);
		insertTable(TBL_CMS_ADMINMATRIX, $EM);
	}
	}
	$E = new wlu_employee_class();
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_ADMINS." WHERE mi_company_id=" . (int)$_POST['company_id']);
	while($row = $this->db->fetch_array_names($result)){
		$E->set_country_responsibilities($row['id'],'C');
	}
	unset($E);

	
	return array(
		'status' 		=> true,
		'msge' 			=> '',
		'msg' 			=> '{LBL_SAVED}',
		'redirect' 	=> $_SERVER['PHP_SELF'] . '?continentid='.$_POST['continentid'].'&regionid='.$_POST['regionid'].'&epage='.$this->redirect_page.'&aktion=countryrelated&id='.$_POST['company_id']
	);
}

function delete_company() {
 if (
 				getCount(TBL_CMS_ADMINMATRIX,'id',"em_type='COMCOU' AND em_compid=" . (int)$_GET['id']) > 0
 			#	|| getCount(TBL_CMS_ADMINMATRIX,'id',"em_type='COM' AND em_relid=" . (int)$_GET['id']) > 0
 				|| getCount(TBL_CMS_ADMINS,'id',"mi_company_id=" . (int)$_GET['id']) > 0
 			
 			)	{
 		return array(
		'status' 	=> true,
		'msge' 		=> '{LBL_COMPANY} {LBL_INUSE}',
		'msg' 		=> '',
		'redirect' 	=> $_SERVER['PHP_SELF'] . '?epage='.$this->redirect_page
		);
 }
 
 $this->db->query("DELETE FROM ".TBL_CMS_WLU_COMPANIES." WHERE id=".(int)$_GET['id']." LIMIT 1"); 		
 $this->db->query("DELETE FROM ".TBL_CMS_ADMINMATRIX." WHERE em_type='COMCOU' AND em_compid=".(int)$_GET['id']); 
 $this->db->query("DELETE FROM ".TBL_CMS_ADMINMATRIX." WHERE em_type='COM' AND em_relid=".(int)$_GET['id']); 
		return array(
		'status' 	=> true,
		'msge' 		=> '',
		'msg' 		=> '{LBL_DELETED}',
		'redirect' 	=> $_SERVER['PHP_SELF'] . '?epage='.$this->redirect_page
		); 

}

function save_company() {
	$id = (int)$_POST['id'];
	foreach( $_POST['FORM'] as $key => $wert) {
		if (strlen($wert)==0) {
			$this->add_err('{LBL_PLEASEFILLOUT}...');
			break;
		}
	}
	if ($this->err_count() > 0) {
		return array(
		'status' 		=> true,
		'msg' 			=> '',
		'msge' 			=> 'X',
		'redirect' 	=> '',
		'aktion'		=> 'edit'
		);
	}
	if ($id <= 0) {
		$_POST['FORM']['co_ident'] = strtoupper($_POST['FORM']['co_ident']);
		$id=insertTable(TBL_CMS_WLU_COMPANIES, $_POST['FORM']);
		} else {
			updateTable(TBL_CMS_WLU_COMPANIES,'id',$id,$_POST['FORM']);
		}
		return array(
		'status' 		=> true,
		'msge' 			=> '',
		'msg' 			=> '{LBL_SAVED}',
		'redirect' 	=> $_SERVER['PHP_SELF'] . '?epage='.$this->redirect_page
		);
}

function parse_to_smarty() {
	
 $this->smarty->assign('COMPANY', $this->COMPANY);
}

} //CLASS

?>
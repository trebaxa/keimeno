<?PHP
if (mod_installed('mod_wilinku')) {
$module_id = 'wilinku';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU Main Module',
		'intern_aktion' 	=> '',
		'id' 							=> $module_id,
		'php' 						=> MODULE_DIR . $module_id . '/wilinku.inc',
		'hasperm' 				=> false,
		'epage' 					=> array('wilinku.inc'), #admin. PHP Scripts
		'epage_dir'				=> MODULE_ROOT,
		'is_content_page'	=> TRUE,
		'class_name'			=> 'wilinku_class', #PHP Master Class Name of Modul
		);


DEFINE('WLU_ROOT', MODULE_ROOT . $module_id . '/');
DEFINE('WLU_MOD_ROOT', WLU_ROOT . 'mods/');


//DEFINE('TBL_CMS_WLU_YTCATCOUNTRY', TBL_CMS_PREFIX.'wlu_cat_country'); 
DEFINE('TBL_CMS_WLU_YTCATVISIBLE', TBL_CMS_PREFIX.'wlu_cat_visible'); 
DEFINE('TBL_CMS_WLU_IPTOCOUNTRY', TBL_CMS_PREFIX.'wlu_iptocountry'); 
DEFINE('TBL_CMS_WLU_IPTOCOUNTRYV6', TBL_CMS_PREFIX.'wlu_iptocountryv6'); 
DEFINE('TBL_CMS_WLU_VIDEO_TO_COUNTRY', TBL_CMS_PREFIX . 'wlu_vcmatrix');

#*********************************
# INIT MASTER CLASS
#********************************* 
include CMS_ROOT . 'includes/modules/aws/tpyo-amazon-s3-php-class/S3.php';
include(WLU_MOD_ROOT . 'wlu_collector/wlu_vplog.class.php'); 	
include(MODULE_ROOT . $MODULE[$module_id]['id'] . '/wilinku.class.php'); 	
include(MODULE_ROOT . $MODULE[$module_id]['id'] . '/wlu_ip2country.class.php'); 	
include(MODULE_ROOT . $MODULE[$module_id]['id'] . '/wlu_aws.class.php'); 

$IP2COUNTRY = new wlu_iptocountry_class();

$WLU_OBJ = new wilinku_class(); 
$WLU_OBJ->user_object = $user_object;
$WLU_OBJ->is_welinku_active((int)$_GET['page']);
$WLU_OBJ->parse_to_smarty();


#*********************************
# LOAD CLASSES
#*********************************
if (NO_MODULES!=1) {
	$dh_mods  = opendir(WLU_MOD_ROOT);
	while (false !== ($sub_mod_dir = readdir($dh_mods))) {
		if ($sub_mod_dir!='.' && $sub_mod_dir!='..' && is_dir(WLU_MOD_ROOT . $sub_mod_dir)) {
			include(WLU_MOD_ROOT . $sub_mod_dir . '/init.inc.php');

			// Loading Admin Language Packs
			if (ISADMIN==1) {
				$lng_xml_pack_sub = WLU_MOD_ROOT . $sub_mod_dir . '/admin/language_'.$LANGS[$GBL_LANGID]['local'].'.xml';
				if (file_exists($lng_xml_pack_sub)) {
					$xml = simplexml_load_file($lng_xml_pack_sub);
					if ($xml) {
						foreach ($xml->replacements as $joker){
							$TCMASTER->ADMIN_MOD_TRANS[md5($joker->replacement)] = array(
	    					'joker' => $joker->replacement,
	    					'value' => $joker->value
	    				);
						}
					}
				}
				$TCMASTER->ADMIN_MOD_TRANSPAGES[$module_id] = array(
	    					'path' 				=> 'wilinku/mods/' . $sub_mod_dir . '/admin/',
	    					'mod_id' 			=> $module_id,
	    					'mod_name' 		=> $MODULE[$module_id]['module_name'],
	    					'mod_allowed' => ($gbl_config[$MODULE[$module_id]['mod_ident']]==1 || $MODULE[$module_id]['mod_ident']=="")	    		
	    				);
				
			}

		}
	}
	closedir($dh_mods);
}
}		
$module_id = 'wilinku';
?>
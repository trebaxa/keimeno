<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

$_GET['id'] = (int)$_REQUEST['id'];
$_GET['starttree'] = (int)$_REQUEST['starttree'];
$_GET['section'] = $_REQUEST['section'];
if (!empty($_GET['section']))
    $_SESSION['section'] = $_GET['section'];
if (empty($_GET['section']))
    $_GET['section'] = $_SESSION['section'];

if ($_GET['reset'] == 1) {
    unset($_SESSION['stocktype']);
}

if (!empty($_REQUEST['stocktype']))
    $_SESSION['stocktype'] = $_REQUEST['stocktype'];


include (CMS_ROOT . 'admin/inc/module.class.php');
$MODULE_OBJ = new module_class(MODULE_ROOT . 'wilinku/');
$MODULE_OBJ->TCR->interpreter();

$CM = new country_class();
$WLU_COLLECTOR_OBJ->EMPLOYEE = $EMPLOYEE->employee_obj;
$WLU_COLLECTOR_OBJ->VPLOG->EMPLOYEE = $EMPLOYEE->employee_obj;
$WLU_COLLECTOR_OBJ->ADHOCV->EMPLOYEE = $EMPLOYEE->employee_obj;
$WLU_COLLECTOR_OBJ->YTV->EMPLOYEE = $EMPLOYEE->employee_obj;
$WLU_COLLECTOR_OBJ->VI->EMPLOYEE = $EMPLOYEE->employee_obj;

$VPLOG = new wlu_vplog_class();
$VPLOG->EMPLOYEE = $EMPLOYEE->employee_obj;

$WLU_COLLECTOR_OBJ->TCR->interpreter();
$WLU_COLLECTOR_OBJ->VI->TCR->interpreter();
$WLU_COLLECTOR_OBJ->ADHOCV->TCR->interpreter();
$WLU_COLLECTOR_OBJ->VPLOG->TCR->interpreter();
$WLU_COLLECTOR_OBJ->YTV->TCR->interpreter();

if ($_POST['aktion'] == "a_save_config") {
    $CONFIG_OBJ->save($_POST['FORM']);
    HEADER('location:' . $_SERVER['PHP_SELF'] . '?epage=' . $_GET['epage'] . '&section=' . $_REQUEST['section'] . '&aktion=conf&configcid=' . $_POST['configcid'] .
        '&msg=' . base64_encode('{LBL_SAVED}'));
    exit;
}

if ($_REQUEST['aktion'] == 'start_request') {
    if ($_REQUEST['YTOPTIONS']['searchTerm'] == "") {
        header('location:' . $_SERVER['PHP_SELF'] . '?epage=' . $_REQUEST['epage'] . '&section=' . $_REQUEST['section'] . '&msge=' . base64_encode('{LA_PARAMENTERMISSING}'));
        exit;
    }
}

$menu = array( #"Video Sync" => "section=s_sync",
    "{LA_VIDEOPUNCHCATEGORIES}" => "section=cats&aktion=showall", "{LA_ADHOCVIDEO}" => "section=adhocvideo&aktion=start", "{LA_NEWQUERYCREATOR}" =>
    "section=addquery&reset=1", "{LA_QUERYRUNNER}" => "section=qrun&aktion=list", "{LA_VIDEOMAN}" => "section=videoman&aktion=list", "{LA_VPLOG}" => "section=vplog", );
if ($EMPLOYEE->employee_obj['PERM']->perm['wlu_vp_isvideomaster'] == 1) {
    $menu["{LA_MODCONFIGURATION}"] = "aktion=conf";
    $menu["{LA_REPORTS}"] = "section=reports";
}
buildTopMenu($menu);

validateModul('mod_wilinku');

if ($_GET['aktion'] == "countryrelated") {
    $WLU_COLLECTOR_OBJ->load_videomixer_countries($EMPLOYEE->employee_obj['responsible_countries_ids']);
    $WLU_COLLECTOR_OBJ->load_cat($_GET['id']);
}

if ($_GET['section'] == 'adhocvideo') {
    $WLU_COLLECTOR_OBJ->load_iso_table();
    #	$WLU_COLLECTOR_OBJ->load_adhoc_video($_REQUEST['videoid']);
    $WLU_COLLECTOR_OBJ->add_tree_selectboxes($WLU_COLLECTOR_OBJ->COLOBJ['adhocvideo']['assigned_cat_ids'], 'adhocvideo', (int)$_REQUEST['countryid']);
    $WLU_COLLECTOR_OBJ->init_aws();

}

if ($_GET['section'] == 'cats') {
    if ($_GET['aktion'] == 'showall' || $_GET['aktion'] == '') {
        $EMPLOYEE->load_employees();
        $EMPLOYEE->parse_to_smarty();
        $WLU_COLLECTOR_OBJ->buildATree(0, $_GET['starttree'], $_GET['employeeid'], $_GET['countryid']);
        $WLU_COLLECTOR_OBJ->load_cat_table($_GET['starttree']);
    }
    if ($_GET['aktion'] == 'catedit') {
        $WLU_COLLECTOR_OBJ->load_cat($_GET['id']);
        $WLU_COLLECTOR_OBJ->build_tree_selectbox($WLU_COLLECTOR_OBJ->CATOBJ['ytc_parent'], $WLU_COLLECTOR_OBJ->CATOBJ['id']);
        if ($WLU_COLLECTOR_OBJ->COLOBJ['fault_form'] == TRUE) {
            $WLU_COLLECTOR_OBJ->COLOBJ['CATOBJ'] = array_merge($_POST['FORM'], $WLU_COLLECTOR_OBJ->COLOBJ['CATOBJ']);
        }
    }
    if ($_GET['cmd'] == 'catadd') {
        $WLU_COLLECTOR_OBJ->load_cat(0);
        $WLU_COLLECTOR_OBJ->build_tree_selectbox(0, 0);
        if ($WLU_COLLECTOR_OBJ->COLOBJ['fault_form'] == TRUE) {
            $WLU_COLLECTOR_OBJ->COLOBJ['CATOBJ'] = $_POST['FORM'];
            $WLU_COLLECTOR_OBJ->COLOBJ['CATOBJ']['country_matrix'] = array();
        }
    }

}

if ($_GET['section'] == 'qrun') {
    if ($_GET['aktion'] == 'list') {
        $WLU_COLLECTOR_OBJ->load_all_queries();
        $WLU_COLLECTOR_OBJ->build_tree_selectbox_filtered($_REQUEST['QFILTER']['cid'], 0);
        $WLU_COLLECTOR_OBJ->load_video_srcs();
    }
    if ($_GET['aktion'] == 'showresult') {
        $WLU_COLLECTOR_OBJ->load_result($_GET['id'], $_GET['start']);
        $WLU_COLLECTOR_OBJ->load_query($_GET['id']);
    }
}

if ($_GET['section'] == 'videoman') {
    $WLU_COLLECTOR_OBJ->build_tree_selectbox_filtered($_REQUEST['QFILTER']['cid'], 0);
    $WLU_COLLECTOR_OBJ->load_video_srcs();
    $WLU_COLLECTOR_OBJ->load_all_queries();
    $WLU_COLLECTOR_OBJ->load_videos_by_cat($_REQUEST['QFILTER']['cid'], $_REQUEST['start']);
}

if ($_GET['section'] == 'reports') {
    $WLU_COLLECTOR_OBJ->set_report_filter();
}

if ($_GET['section'] == 's_sync' && $_REQUEST['aktion'] == "") {
    $WLU_COLLECTOR_OBJ->load_all_ytcats();
}

if ($_GET['section'] == 'addquery') {
    $WLU_COLLECTOR_OBJ->add_tree_selectboxes($WLU_COLLECTOR_OBJ->COLOBJ['query']['assigned_cat_ids'], 'query', (int)$_GET['countryid']);
    $WLU_COLLECTOR_OBJ->load_all_ytcats();
    $WLU_COLLECTOR_OBJ->load_iso_table();
    if ($_REQUEST['aktion'] == "yt_query_edit") {
        if ($WLU_COLLECTOR_OBJ->COLOBJ['fault_form'] == TRUE) {
            $WLU_COLLECTOR_OBJ->COLOBJ['query'] = array_merge($WLU_COLLECTOR_OBJ->COLOBJ['query'], $_POST['FORM']);
            $WLU_COLLECTOR_OBJ->COLOBJ['query']['qobj'] = $_POST['YTOPTIONS'];
            $WLU_COLLECTOR_OBJ->add_tree_selectboxes($_POST['CIDS'], 'query', (int)$_POST['countryid']);
        }
        else {
        }
    }
}

if ($_GET['section'] == 'vplog') {
    $VPLOG->vp_load_table();
    $VPLOG->parse_to_smarty();
}

#*********************************
# SHOW CONFIG
#*********************************
if ($_GET['aktion'] == 'conf') {
    $nav_menu = array('VPFE' => array('ident' => 0, 'label' => 'Frontend'), 'VPBE' => array('ident' => 1, 'label' => 'Backend'), 'VPGE' => array('ident' => 2,
        'label' => 'General'), );

    $CONF = array(
    'nav_menu' => $nav_menu,
     'nav_menu_count' => count($nav_menu), 
     'conf_table_ge' => $CONFIG_OBJ->buildTable(39, 39),
     'conf_table_be' => $CONFIG_OBJ->buildTable(37, 37),
     'conf_table_fe' => $CONFIG_OBJ->buildTable(40, 40), 
     'vi_authlink' => $WLU_COLLECTOR_OBJ->VI->build_auth_link());
    $smarty->assign('CONF', $CONF);
}
#echoarr($EMPLOYEE->employee_obj['responsible_countries']);
$content .= '<% include file="wlu_collector.tpl" %>';
$WLU_COLLECTOR_OBJ->COLOBJ['stocktype'] = $_SESSION['stocktype'];
$WLU_COLLECTOR_OBJ->parse_to_smarty();

?>
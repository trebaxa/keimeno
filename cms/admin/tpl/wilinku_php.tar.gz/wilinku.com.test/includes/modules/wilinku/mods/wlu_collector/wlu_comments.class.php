<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_comments_class extends wlu_colmaster_class {
	
function __construct() {
	parent::__construct();
	$this->TCR = new tc_request_class($this);
}

function set_comment_opt($arr, &$new_arr, &$counts, &$counter) {
	foreach ($arr as $key => $row) {
		$counter++;
		$row['posteddate'] = date('d.m.Y', $row['c_createtime']);
		$row['counter'] = $counter;
		$this->modify_date($row);
		$counts++;
		if (ISADMIN==1) {
			$row['icons'][] 	 = genDelImgTagADMINConfirm($row['id'],'delete_comment','{LBLA_CONFIRM}');
		}
		$new_arr[$key] 	= $row;
		if (count($row['children']) > 0) {
			$this->set_comment_opt($row['children'],$new_arr[$key]['children'],$counts, $counter);
		}
	}
}

function update_comment_count($vid) {
	$result = $this->db->query_first("SELECT COUNT(*) AS CCOUNT FROM " . TBL_CMS_WLU_COMMENTS." WHERE c_vid='".$vid."'");
	$this->db->query("UPDATE ".TBL_CMS_WLU_APPROVED_VIDEOS." SET yt_comment_count=".(int)$result['CCOUNT']." WHERE yt_videoid='".$vid."'");
}

function cmd_delete_comment() {
  $C = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COMMENTS." WHERE id=".(int)$this->TCR->REQUEST['id']);	
	$this->db->query("DELETE FROM " . TBL_CMS_WLU_COMMENTS." WHERE id=" . (int)$this->TCR->REQUEST['id']);
	$this->update_comment_count($C['c_vid']);
	$this->TCR->set_just_turn_back(true);
	$this->TCR->add_msg('{LBL_DELETED}');	
}

function modify_date(&$row){
  if ( (time() - $row['c_createtime']) <= 15 * 60) { // 5min old
 		$row['date_index'] = '15m';
 	} else if ( (time() - $row['c_createtime']) <= 2 * 60 * 60) { // 2hours old
 		$row['date_index'] = '2h';
 	} else if ( (time() - $row['c_createtime']) <= 2 * 24 * 60 * 60) { // 24h old
 		$row['date_index'] = '2d';
 	} else {
 		$row['date_index'] = 'A';
 	} 	
}



function load_comments($vid=0, $V=array()) {
	if ($V['VID']=="") {
		$V=$this->load_single_video($vid);
		$vid=$V['VID'];
	}
	$result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COMMENTS." WHERE c_vid='".$vid."'");
	while($row = $this->db->fetch_array_names($result)) {
		$row['posteddate'] = date('d.m.Y', $row['c_createtime']);
		
		#echoarr($row);
		$V['comments'][] = $row;
	}
	$menutree = new nestedArrClass();
	$menutree->init(
	array(
	'label_column' 			=> 'c_name',
	'label_parent' 			=> 'c_parent',
	'label_id' 					=> 'id',
	)
	);
	$menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_COMMENTS. " WHERE c_vid='".$vid."' ORDER BY c_createtime", 0, 0, -1);
	$comments=$V['comments']=array();
	$comments = array_reverse($menutree->menu_array, true);
	$counter=0;
	$this->set_comment_opt($comments, $V['comments'], $counts, $counter);
	unset($comments);
	$V['comments_count'] = (int)$counts;
#echoarr($V['comments']);
	$this->VPC['video'] = $V;
	return $V;
}

function cmd_edit_comments() {
 $this->VPC['video'] = $this->load_comments($this->TCR->REQUEST['vid']);
}

function parse_to_smarty() {
	$this->smarty->assign('VPC', $this->VPC);
}

}
?>
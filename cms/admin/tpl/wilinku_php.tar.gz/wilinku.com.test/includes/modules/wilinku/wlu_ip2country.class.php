<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011    									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

#http://software77.net/geo-ip/

class wlu_iptocountry_class extends tc_class {
	
function __construct() {
	parent::__construct();
}

function uncompress($srcName, $dstName) {
    $sfp = gzopen($srcName, "rb");
    $fp = fopen($dstName, "w");

    while ($string = gzread($sfp, 4096)) {
        fwrite($fp, $string, strlen($string));
    }
    gzclose($sfp);
    fclose($fp);
}

function load_country_table() {
	$dir = realpath(dirname(__FILE__));
	$handle = fopen ($dir.'/libs/country_codes.csv',"r");
	while ( ($data = fgetcsv ($handle, 1000, ",")) !== FALSE ){
		$this->ccodes[$data[1]]=array(
		'country' 	=> ucfirst(strtolower($data[0])),
		'code' 			=> $data[1],
		'code2' 		=> $data[2],
		'registry' 	=> $data[3]
		);
	}
	fclose ($handle);
	$this->ccodes = sortDbResult($this->ccodes, 'country', SORT_ASC, SORT_STRING);
}

function geoip() {
# IP FROM & : Numerical representation of IP address.
# IP TO       Example: (from Right to Left)
#             1.2.3.4 = 4 + (3 * 256) + (2 * 256 * 256) + (1 * 256 * 256 * 256)
#             is 4 + 768 + 13,1072 + 16,777,216 = 16,909,060	
 $myIP = $_SERVER['REMOTE_ADDR'];
 list($p1,$p2,$p3,$p4) = explode('.',$myIP);
 return $p4 + ($p3 * 256) + ($p2 * 256 * 256) + ($p1 * 256 * 256 * 256);
}

function get_my_country() {	
	$myGeoIP = $this->geoip();
	$ip_range=$this->db->query_first("SELECT * FROM ".TBL_CMS_WLU_IPTOCOUNTRY." WHERE ip_from<=".$myGeoIP." AND ip_to>=".$myGeoIP);
	return $ip_range;
}

function sync() {
	$this->load_country_table();
	$dir = realpath(dirname(__FILE__));
	$t = $dir.'/IpToCountry.csv.gz';
	if (!file_exists($t)) {
		system("wget software77.net/geo-ip/?DL=1 -O ".$t);
	}
	$target = substr($t,0,strlen($t)-3);
	$this->uncompress($t, $target);
	$this->db->query("DELETE FROM ".TBL_CMS_WLU_IPTOCOUNTRY." WHERE 1");
	$line_count=0;
	$handle = fopen ($target,"r");
	while ( ($data = fgetcsv ($handle, 1000, ",")) !== FALSE ){
		$line_count++;
	}
	fclose ($handle);		
	$handle = fopen ($target,"r");
	$k=0;
	$gbl_sql=$sql="";
	while ( ($data = fgetcsv ($handle, 1000, ",")) !== FALSE ){
		$num = count ($data);
		if ($num > 6 && !strstr($data[0],'#')) {
			foreach ($data as $key => $v){
				$data[$key] = trim(mysql_real_escape_string($data[$key]));
			}
				$add = array(
					'ip_from' 		=> $data[0],
					'ip_to' 			=> $data[1],
					'ip_registry' => $data[2],
					'ip_assigned' => $data[3],
					'ip_ctry' 		=> $data[4],
					'ip_cntry' 		=> $data[5],
					'ip_country'	=> $data[6]
				);
			$gbl_sql.=($gbl_sql!="") ? ',' : '';
			$sql="";
			$fields="";
			$lcounter++;
			foreach ($add as $key => $value) {
			 $sql.=($sql!="") ? ',' : '';
			 $sql.="'".$value."'";			 
			 $fields.=($fields!="") ? ",".$key  : $key;
			}
			$gbl_sql.="(".$sql.")";
			$k++;
			if ($k==30 || $lcounter>=($line_count-1)) {
				$k=0;
				$sqlsend="INSERT INTO ".TBL_CMS_WLU_IPTOCOUNTRY." (".$fields.") VALUES ".$gbl_sql;			
				$this->db->query($sqlsend);
				$gbl_sql="";
				$sql="";
			}
		}
	}
	fclose ($handle);
	
	#wget software77.net/geo-ip/?DL=7 -O /path/IpToCountry.6R.csv.gz
	$gbl_sql=$sql="";
	$t = $dir.'/IpToCountry.6R.csv.gz';
	if (!file_exists($t)) {
		system("wget software77.net/geo-ip/?DL=7 -O ".$t);
	}
	$target = substr($t,0,strlen($t)-3);
	$this->uncompress($t, $target);
	$this->db->query("DELETE FROM ".TBL_CMS_WLU_IPTOCOUNTRYV6." WHERE 1");
	
	$line_count=0;
	$handle = fopen ($target,"r");
	while ( ($data = fgetcsv ($handle, 1000, ",")) !== FALSE ){
		$line_count++;
	}
	fclose ($handle);	
	$handle = fopen ($target,"r");
	$k=0;
	while ( ($data = fgetcsv ($handle, 1000, ",")) !== FALSE ){
		$num = count ($data);
		if ($num > 3 && !strstr($data[0],'#')) {
			foreach ($data as $key => $v){
				$data[$key] = trim(mysql_real_escape_string($data[$key]));
			}
			list($from,$to) = explode('-',$data[0]);
				$add = array(
					'ip_from' 		=> $from,
					'ip_to' 			=> $to,
					'ip_ctry' 		=> $data[1],
					'ip_registry' => $data[2],
					'ip_assigned' => $data[3],
					'ip_cntry'		=> mysql_real_escape_string($this->ccodes[$data['code']]['code2']),
					'ip_country'	=> mysql_real_escape_string($this->ccodes[$data['code']]['country']),
				);
			$gbl_sql.=($gbl_sql!="") ? ',' : '';
			$sql="";
			$fields="";
			$lcounter++;
			foreach ($add as $key => $value) {
			 $sql.=($sql!="") ? ',' : '';
			 $sql.="'".$value."'";			 
			 $fields.=($fields!="") ? ",".$key  : $key;
			}
			$gbl_sql.="(".$sql.")";
			$k++;
			if ($k==30 || $lcounter>=($line_count-1)) {
				$k=0;
				$sqlsend="INSERT INTO ".TBL_CMS_WLU_IPTOCOUNTRYV6." (".$fields.") VALUES ".$gbl_sql;			
				$this->db->query($sqlsend);
			#		die($sqlsend);
				$gbl_sql="";
				$sql="";
			}
		}
	}
	fclose ($handle);	
	#@unlink($target);
}


	
}

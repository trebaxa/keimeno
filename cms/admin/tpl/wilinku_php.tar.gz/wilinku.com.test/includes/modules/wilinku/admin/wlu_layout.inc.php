<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2009     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

include(CMS_ROOT .  'admin/inc/module.class.php'); 	
$MODULE_OBJ = new module_class(MODULE_ROOT . 'wilinku/');
$MODULE_OBJ->TCR->interpreter();

$menu = array(
	"Style&Files" 	=> "section=modstylefiles&epage=".$_GET['epage'],
	);
buildTopMenu($menu);

$content.='<% include file="modstylefiles.tpl" %>';
?>
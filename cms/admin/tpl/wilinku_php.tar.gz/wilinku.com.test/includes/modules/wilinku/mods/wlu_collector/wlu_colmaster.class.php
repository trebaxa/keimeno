<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_colmaster_class extends wilinku_class {

    var $fix_stocks = array('YT' => 'YouTube', 'VI' => 'Vimeo');

    function __construct() {
        parent::__construct();
    }

    function loadcrctab() {
        $this->crc_tab = array();
        $sql = "SELECT *,C.id COUNTRYID, CO.id AS CONID, R.id AS REGIONID FROM
	" . TBL_CMS_LAND . " C
	, " . TBL_CMS_LANDCONTINET . " CO
	, " . TBL_CMS_LANDREGIONS . " R
	WHERE R.lr_continet_id=CO.id
	AND C.region_id=R.id
	";
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->crc_tab[$row['lr_continet_id']][$row['region_id']][$row['COUNTRYID']] = $row;
            $this->continents[$row['lr_continet_id']] = $row;
            $this->regions[$row['region_id']] = $row;
            $this->countries[$row['COUNTRYID']] = $row;
        }
    }

    function get_region_of_country($cid) {
        foreach ($this->countries as $countryid => $c) {
            if ($cid == $countryid)
                return $c['REGIONID'];
        }
    }

    function get_continent_of_country($cid) {
        foreach ($this->countries as $countryid => $c) {
            if ($cid == $c['COUNTRYID'])
                return $c['CONID'];
        }
    }

    function delete_video($id) {
        $V = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE  yt_videoid='" . $id . "'");
        delete_file(CMS_ROOT . VIDEOTHUMB_PATH . $V['yt_preview']);
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VP . " WHERE yt_videoid='" . $id . "'");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE yt_videoid='" . $id . "'");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " WHERE vq_videoid='" . $id . "'");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " WHERE vc_videoid='" . $id . "'");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_videoid='" . $id . "'");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VSREL . " WHERE sr_videoid='" . $id . "'");
    }

    function update_cat_count_by_vmatrix($cid) {
        $VC = $this->db->query_first("SELECT COUNT(vcm_videoid) AS VCOUNT FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_cid=" . $cid);
        $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocount=" . (int)$VC['VCOUNT'] . " WHERE id=" . $cid);
    }

    function count_it($arr, &$count) {
        foreach ($arr as $key => $CAT) {
            $VC = $this->db->query_first("SELECT COUNT(vcm_videoid) AS VCOUNT FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_cid=" . $CAT['id']);
            $count += $VC['VCOUNT']; # $CAT['ytc_videocount'];
            $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocount=" . (int)$VC['VCOUNT'] . " WHERE id=" . $CAT['id']);
            if (is_array($CAT['children'])) {
                $this->count_it($CAT['children'], $count);
            }
        }
    }

    function update_total_count($C, &$count) {
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        // get tree without excluding $C['id']
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", $C['id'], 0, -1);
        // adding now $C['id']
        $C['children'] = $menutree->menu_array;
        $menutree->menu_array = array($C);
        $count = 0;
        $this->count_it($menutree->menu_array, $count);
    }


    function update_location_counts() {
        // Update Video - Region Count ALLE
        if (is_array($this->regions)) {
            foreach ($this->regions as $key => $region) {
                # foreach ($this->crc_tab[$region['CONID']][$region['REGIONID']] as $ckey => $country) {
                #     $count = getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, "vc_videoid", "vc_countryid=" . $country['COUNTRYID']);
                #     $region_counts[$region['REGIONID']] += $count;
                #     $this->db->query("UPDATE " . TBL_CMS_LANDREGIONS . " SET lr_video_count=" . (int)$region_counts[$region['REGIONID']] . " WHERE id=" . $region['REGIONID']);
                # }
                $count = getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, "vc_videoid", "vc_regionid=" . $region['REGIONID']);
                $this->db->query("UPDATE " . TBL_CMS_LANDREGIONS . " SET lr_video_count=" . (int)$count . " WHERE id=" . $region['REGIONID']);
            }

            // Update Video - Continent Count ALLE
            foreach ($this->continents as $key => $continent) {
                #$VC = $this->db->query_first("SELECT SUM(lr_video_count) AS VCOUNT FROM " . TBL_CMS_LANDREGIONS . " WHERE lr_continet_id=" . $continent['CONID']);
                #$this->db->query("UPDATE " . TBL_CMS_LANDCONTINET . " SET lc_video_count=" . (int)$VC['VCOUNT'] . " WHERE id=" . $continent['CONID']);
                $count = getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, "vc_videoid", "vc_contid=" . $continent['CONID']);
                $this->db->query("UPDATE " . TBL_CMS_LANDCONTINET . " SET lc_video_count=" . (int)$count . " WHERE id=" . $continent['CONID']);
            }
        }
    }

    function update_all_cat_counts() {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_CATS . "");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->update_total_video_count($row['id']);
        }
    }

    function update_cat_counts_by_video($videoid) {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_videoid='" . $videoid . "'");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->update_total_video_count($row['vcm_cid']);
        }
    }

    function move_to_exception($video_id, $FORM = array()) {
        $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_blocked=1 
 " . (($FORM['yt_mixer_comment'] != "") ? ",yt_mixer_comment='" . strip_tags($FORM['yt_mixer_comment']) . "'" : "") . "
 WHERE yt_videoid='" . $video_id . "'");
        $SW = new wlu_vsearch_class();
        $SW->clean_index_by_videoid($video_id);
        unset($SW);
    }

    function remove_to_exception($video_id, $FORM = array()) {
        $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_blocked=0 
 " . (($FORM['yt_mixer_comment'] != "") ? ",yt_mixer_comment='" . strip_tags($FORM['yt_mixer_comment']) . "'" : "") . "
 WHERE yt_videoid='" . $video_id . "'");
    }

    function get_comment_count($vid) {
        $result = $this->db->query_first("SELECT COUNT(*) AS CCOUNT FROM " . TBL_CMS_WLU_COMMENTS . " WHERE c_vid='" . $vid . "'");
        return (int)$result['CCOUNT'];
    }


    function set_video_options(&$row) {
        $row['yt_lastupdate_date'] = myDate('d.m.Y', $row['yt_lastupdate']);
        $row['yt_uploaddate'] = myDate('d.m.Y', $row['yt_upload_date']);
        $row['yt_apptime_datetime'] = date('d.m.Y', $row['yt_apptime']);
        $row['author'] = ($row['yt_author_realname'] == "") ? $row['yt_author_username'] : $row['yt_author_realname'];
        $row['vtags'] = str_replace(';', ', ', $row['yt_videotags']);
        $row['pathes'] = array();
        $row['yt_vtitlealpha'] = $this->format_file_name($row['yt_videotitle']);
        $row['yt_videoduration_min'] = printMenge($row['yt_videoduration'] / 60);
        if ($row['yt_preview'] != "") {
            $G = new graphic_class();
            $fname = CMS_ROOT . VIDEOTHUMB_PATH . $row['yt_preview'];
            $img_name = $G->makeThumb($fname, $this->gbl_config['wlu_thumbwidth_fe'], $this->gbl_config['wlu_thumbheight_fe'], './' . CACHE, TRUE, 'crop');
            unset($G);
            $row['localthumb'] = PATH_CMS . CACHE . basename($img_name);
            # echo $row['localthumb'];
        }
        else {
            $row['localthumb'] = $this->gen_thumbnail($row['yt_thumbnailurl'], $row['yt_videoid']);
        }
        if ($row['yt_stock'] == 'WU') {
            // Private URL
            $S3AWSID = $this->gbl_config['wlu_aws_key'];
            $S3AWSSECRET = $this->gbl_config['wlu_aws_secretkey'];
            $s3 = new S3("$S3AWSID", "$S3AWSSECRET");
            $expireinterval = 3600;
            $gracetime = $expireinterval + 10;
            $timestamp = time();
            $timestamp -= ($timestamp % $expireinterval);
            $timestamp += $expireinterval + $gracetime;
            $timestamp = $timestamp - time();
            $row['file_hosturl_protected'] = $s3->getAuthenticatedURL($row['yt_aws_bucket'], $row['yt_aws_file'], $timestamp, true, false);
            /* $parsedurl = parse_url($row['file_hosturl_protected']);
            $get_keys = explode('&', $parsedurl['query']);
            foreach ($get_keys as $key => $v) {
            list($gkey, $gvalue) = explode('=', $v);
            $get_slashes .= '/' . $gvalue;
            }
            $row['file_mr_link'] = 'http://www.wlu.wilinku.com/awsvideo' . urldecode($get_slashes) . '/' . $parsedurl['path'];
            */
            // http://videos-central-america.wilinku.com/honduras/David%20Playing%20Guitar.m4v?AWSAccessKeyId=AKIAI5ZG3YRYUWINZLXQ&Expires=1316421080&Signature=byTmuKfoS0fIxSMHow%2BvYmk%2FGnQ%3D
            unset($s3);
        }
    }

    function clear_stock() {
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VP . " WHERE 1");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE 1");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " WHERE 1");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " WHERE 1");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE 1");
        $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocount=0 WHERE 1");
    }


    function gen_thumbnail($url, $id) {
        if ($url != "" && $this->isValidURL($url) && in_array(strtolower($this->get_ext(basename($url))), array('jpg', 'png', 'gif'))) {
            $fname = CMS_ROOT . CACHE . 'vp_' . $id . '_' . basename($url);
            if (!file_exists($fname)) {
                #$img_binary = file_get_contents($url);
                $img_binary = $this->get_remote_file($url);
                file_put_contents($fname, $img_binary);
            }
            $G = new graphic_class();
            $img_name = $G->makeThumb($fname, $this->gbl_config['wlu_thumbwidth_fe'], $this->gbl_config['wlu_thumbheight_fe'], './' . CACHE, TRUE, 'crop');
            unset($G);
            return PATH_CMS . CACHE . basename($img_name);
        }
        else {

            $G = new graphic_class();
            $fname = CMS_ROOT . 'includes/modules/wilinku/template/img/no_picture.gif';
            $img_name = $G->makeThumb($fname, $this->gbl_config['wlu_thumbwidth_fe'], $this->gbl_config['wlu_thumbheight_fe'], './' . CACHE, TRUE, 'crop');
            unset($G);
            return PATH_CMS . CACHE . basename($img_name);
        }
    }

    function create_path_with_links($cid, &$bread_crumb, $countryid, $countryname) {
        $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$cid);
        $bread_crumb[] = array('title' => $C['ytc_name'], 'id' => $C['id'], 'ytc_parent' => $C['ytc_parent'], 'link' => $this->gen_vpcat_link($C, $countryname));
        if ($C['ytc_parent'] > 0) {
            $this->create_path_with_links($C['ytc_parent'], $bread_crumb, $countryid, $countryname);
        }
    }

    function gen_vpcat_link($CAT, $countryname) {
        #return '/videos/' . urlencode(strtolower($countryname)) . '/' . (int)$CAT['id'] . '/' . urlencode($this->formatFileName($CAT['ytc_path'])).'.html';
        $CAT['ytc_path'] = substr($CAT['ytc_path'], 1, strlen($CAT['ytc_path']));
        $CAT['ytc_path'] = str_replace('/', ',', $CAT['ytc_path']);
        $CAT['ytc_path'] = str_replace(' ', '_', $CAT['ytc_path']);
        return '/videos/' . urlencode($this->formatFileName($countryname)) . '/' . (int)$CAT['id'] . '/' . ($CAT['ytc_path'] . '.html');
    }

    function gen_level1_link($CAT, $countryname) {
        return '/videos-' . urlencode($this->formatFileName($countryname)) . '/' . (int)$CAT['id'] . '/' . urlencode($this->formatFileName($CAT['ytc_name'])) . '.html';

    }

    function gen_setcountry_link($countryid, $countryname) {
        return '/videos.' . urlencode($this->formatFileName($countryname)) . '-' . (int)$countryid;
    }

    function gen_setregion_link($regionid, $regionname) {
        return '/regionvideos/' . (int)$regionid . '/' . urlencode($this->formatFileName($regionname));
    }

    function gen_setcontinent_link($conid, $continentname) {
        return '/continentvideos/' . (int)$conid . '/' . urlencode($this->formatFileName($continentname));
    }

    function gen_videodeatil_link($row, $countryname) {
        return '/video/' . urlencode($this->formatFileName($countryname)) . '/' . $row['VID'] . '/' . urlencode($this->formatFileName($row['yt_videotitle'])) . '.html';
    }

    function load_single_video($vid, $countryid = 0, $cid = 0) {
        $vid = strval(trim($vid));
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID, VC.vc_countryid AS COUNTRYID
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
            TBL_CMS_WLU_VCATMATRIX . " VCAT
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_videoid='" . $vid . "'
	AND VC.vc_countryid=L.id
	AND V.yt_blocked=0
	AND C.id=VCAT.vcm_cid
	" . (($cid == 0) ? " AND VCAT.vcm_prio=1 " : "") . "
	AND C.ytc_approval=1
	AND V.yt_videoid=VCAT.vcm_videoid	" . (($countryid != ALLCOUNTRYID && $countryid != 0) ? " AND VC.vc_countryid=" . (int)$countryid : "") 
    . (($cid > 0) ? " AND C.id=" . (int)$cid : "");
   # echo $sql;
        $V = $this->db->query_first($sql);
        return $V;
    }

    function load_iso_table() {
        $handle = fopen(CMS_ROOT . 'admin/tpl/lngpacks/lng_iso_639-1.csv', "r");
        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            $this->iso_list[strtoupper($data[1])] = array('lname' => $data[0], 'localid' => strtoupper($data[1]));
        }
        fclose($handle);
        $this->iso_list = sortDbResult($this->iso_list, 'lname', SORT_ASC, SORT_STRING);
        return $this->iso_list;
    }


    function remove_countries_by_list(&$menutree, $country_ids) {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE 1");
        while ($row = $this->db->fetch_array_names($result)) {
            $countries_to_cat[$row['cm_cid']][$row['cm_countryid']] = $row['cm_countryid'];
        }
        $nested_array = array();
        $this->remove_cats_by_country($menutree->menu_array, $menutree, $nested_array, $country_ids, $countries_to_cat);
        $menutree->menu_array = $nested_array;
    }

    function remove_cats_by_country($arr, &$menutree, &$new_arr, &$responsible_country_ids, &$countries_to_cat) {
        foreach ($arr as $key => $cat) {
            $schnittmenge = array();
            if (is_array($countries_to_cat[$cat['id']]))
                $schnittmenge = array_intersect($countries_to_cat[$cat['id']], $responsible_country_ids);
            if ((count($schnittmenge) > 0) || $cat['ytc_isindi'] == 0) {
                $new_arr[$key] = $cat;
                unset($new_arr[$key]['children']);
                if (is_array($cat['children'])) {
                    $this->remove_cats_by_country($cat['children'], $menutree, $new_arr[$key]['children'], $responsible_country_ids, $countries_to_cat);
                }
            }
            else {
                unset($menutree->menu_flat_array[$cat['id']]);
            }
        }
    }

    function set_menu_opt($arr, &$new_arr, &$flat_menu_arr, &$counter, $countryname) {
        foreach ($arr as $key => $cat) {
            $counter++;
            $cat['counter'] = $counter;
            $cat['link'] = $this->gen_vpcat_link($cat, $countryname);
            #'/index.php?page=10003&cid='.$cat['id'].'&countryid=' .$this->selected['countryid'].'&cmd=loadvideos' ;
            if ($cat['ytc_parent'] == 0)
                $cat['level1_link'] = $this->gen_level1_link($cat, $countryname);
            $cat['video_count_by_location'] = $this->get_videocount_by_location($cat['id']);
            $PC = $flat_menu_arr[$cat['id']];
            do {
                if ($PC['id'] > 0) {
                    $flat_menu_arr[$PC['id']]['video_subcount_by_location'] += $cat['video_count_by_location'];
                    $PC = $flat_menu_arr[$PC['ytc_parent']];
                }
            } while ($PC['id'] > 0);
            $new_arr[$key] = $cat;
            if (count($cat['children']) > 0) {
                $this->set_menu_opt($cat['children'], $new_arr[$key]['children'], $flat_menu_arr, $counter, $countryname);
            }
        }
    }

    function merge_subcounts($arr, &$new_arr, &$flat_menu_arr) {
        foreach ($arr as $key => $cat) {
            $cat['video_subcount_by_location'] = (int)$flat_menu_arr[$cat['id']]['video_subcount_by_location'];
            $new_arr[$key] = $cat;
            if (count($cat['children']) > 0) {
                $this->merge_subcounts($cat['children'], $new_arr[$key]['children'], $flat_menu_arr);
            }
        }
    }


    function remove_by_range($arr, &$new_arr, $start, $stop) {
        foreach ($arr as $key => $cat) {
            #	echo ($cat['counter'].' '.$start.' ' . $stop . '<br>');
            $cat['dohide'] = true;
            if ($cat['counter'] >= $start && $cat['counter'] <= $stop) {
                $cat['dohide'] = false;
                $new_arr[$key] = $cat;
                unset($new_arr[$key]['children']);
            }


            if (is_array($cat['children'])) {
                $this->remove_by_range($cat['children'], $new_arr[$key]['children'], $start, $stop);
            }
            #	if (is_array($cat['children']) && $new_arr[$key]['id'] == 0) {
            #			$this->remove_by_range($cat['children'], $new_arr[$key]['c'] ,$start,$stop, $key);
            #	}
            #	if (count($new_arr[$key]['children'])==0) unset($new_arr[$key]['children']);
            #	if (count($new_arr[$key])==0) unset($new_arr[$key]);
            if (count($new_arr[$key]['children']) > 0 && $new_arr[$key]['id'] == 0) {
                #die('x');
                #$new_arr[$parent] = $new_arr[$key];
            }
        }
    }

    function update_approvedvideo_count($cid) {
        $sql = "SELECT COUNT( yt_videoid ) AS WC 
FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " A," . TBL_CMS_WLU_VCATMATRIX . " M 
WHERE ( A.yt_blocked=0 AND A.yt_videoid = M.vcm_videoid AND M.vcm_cid=" . $cid . ")";
        $C = $this->db->query_first($sql);
        $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocountapp=" . (int)$C['WC'] . " WHERE id=" . (int)$cid);
        return (int)$C['WC'];
    }

    function count_it_approved($arr, &$count) {
        foreach ($arr as $key => $CAT) {
            $count += $this->update_approvedvideo_count($CAT['id']);
            if (is_array($CAT['children'])) {
                $this->count_it_approved($CAT['children'], $count);
            }
        }
    }

    function update_total_approved_count($C, &$count) {
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        // get tree without excluding $C['id']
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", $C['id'], 0, -1);
        // adding now $C['id']
        $C['children'] = $menutree->menu_array;
        $menutree->menu_array = array($C);
        $count = 0;
        $this->count_it_approved($menutree->menu_array, $count);
    }


    function update_total_video_count($cid, $location_counts = TRUE) { // MAY NOT USED ANYMORE
        $count = 0;
        $cid = (int)$cid;
        $this->loadcrctab();
        // Update Video - Cat Count
        $this->update_cat_count_by_vmatrix($cid);
        $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $cid);
        while ($C['id'] > 0) {
            $this->update_total_count($C, $count);
            $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocounttotal=" . (int)$count . " WHERE id=" . $C['id']);
            $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $C['ytc_parent']);
        }
        if ($location_counts === TRUE) {
            $this->update_location_counts();
        }
    }

    function update_count_approved_videos($cid, $location_counts = TRUE) {
        $cid = (int)$cid;
        $this->loadcrctab();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $cid);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->update_approvedvideo_count($row['id']);
            $C = $row;
            while ($C['id'] > 0) {
                $count = 0;
                $this->update_total_approved_count($C, $count);
                $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocountapptotal=" . (int)$count . " WHERE id=" . $C['id']);
                $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $C['ytc_parent']);
            }
        }
        if ($location_counts === TRUE) {
            $this->update_location_counts();
        }
    }

}

<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}

$module_id = 'wlu_mapping';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU Mappings',
		'intern_aktion' 	=> '',
		'id' 							=> $module_id,
		'php' 						=> '',
		'hasperm' 				=> true,
		'epage' 					=> array('wlu_mapping.inc'), #admin. PHP Scripts
		'epage_dir'				=> WLU_MOD_ROOT,
		'is_content_page'	=> false,
		'class_name'			=> '', #PHP Master Class Name of Modul
		);

include(CMS_ROOT . 'includes/modules/wilinku/mods/wlu_mapping/wlu_mapping.class.php');

$WLU_MAPPING = new wlu_mapping_class(); 
?>
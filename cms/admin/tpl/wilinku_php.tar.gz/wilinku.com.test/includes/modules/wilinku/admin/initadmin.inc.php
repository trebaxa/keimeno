<?PHP
if (mod_installed('mod_wilinku')) {
	$EMPLOYEE = new wlu_employee_class();
	$EMPLOYEE->load_employee((int)$_SESSION['mitarbeiter']);
	$PERM = $EMPLOYEE->employee_obj['PERM'];
	
	$dh_mods  = opendir(WLU_MOD_ROOT);
	while (false !== ($sub_mod_dir = readdir($dh_mods))) {
		if ($sub_mod_dir!='.' && $sub_mod_dir!='..' && is_dir(WLU_MOD_ROOT . $sub_mod_dir)) {
			$f = WLU_MOD_ROOT . $sub_mod_dir . '/admin/initadmin.inc.php';
			if (file_exists($f)) include($f);
		}
	}
}
?>
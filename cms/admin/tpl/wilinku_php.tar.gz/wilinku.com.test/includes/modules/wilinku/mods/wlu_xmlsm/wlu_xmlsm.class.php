<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011    									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

if (IN_SIDE != 1) {
    header('location:' . PATH_CMS . 'index.html');
    exit;
}


class wlu_xmlsm_class extends modules_class {

    var $XMLSM = array();

    function __construct() {
        parent::__construct();
        $this->TCR = new tc_request_class($this);
        if (ISADMIN == 1)
            $this->init();
    }

    function init() {
        $this->MAP_INI = new wlu_site_mapini_class(TBL_CMS_WLUXMLSM, TBL_CMS_LANG);
        $this->XMLSM['MAPINI'] = $this->MAP_INI->MAP->configTable();
    }

    function cmd_delsitemap() {
        $this->MAP_INI->MAP->delXMLFile($this->TCR->GET['file']);
        $this->TCR->set_just_turn_back(true);
        $this->TCR->reset_cmd('');
        $this->TCR->add_msg('{LBL_DELETED}');
    }

    function cmd_a_savesmconf() {
        $this->MAP_INI->MAP->saveSMConf($this->TCR->POST['FORM']);
        $this->TCR->set_just_turn_back(true);
        $this->TCR->reset_cmd('');
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function cmd_a_smapprove() {
        $this->db->query("UPDATE " . TBL_CMS_WLUXMLSM . " SET sm_active='" . intval($this->TCR->GET['value']) . "' WHERE id=" . $this->TCR->GET['id'] . " LIMIT 1");
        $this->TCR->set_just_turn_back(true);
        $this->TCR->reset_cmd('');
        $this->TCR->add_msg('{LBL_SAVED}');
    }


    function cmd_a_googlemaps() {
        global $DBOUT;
        $DBOUT->msave($this->TCR->POST['FORM'], TBL_CMS_WLUXMLSM);
        $result_lang = $this->db->query_first("SELECT * FROM " . TBL_CMS_LANG . " WHERE id=" . $this->TCR->POST['sm_lang'] . " AND approval=1 ORDER BY post_lang");
        if ($this->TCR->POST['sm_lang'] > 0)
            $MAP_INI = new wlu_site_mapini_class('../wlu_video_punch_sitemap_' . $result_lang['local'] . '.xml', TBL_CMS_WLUXMLSM, TBL_CMS_LANG);
        else
            $MAP_INI = new wlu_site_mapini_class('../wlu_video_punch_sitemap.xml', TBL_CMS_WLUXMLSM, TBL_CMS_LANG);
        $this->MAP_INI->buildUrlTable($this->TCR->POST['sm_lang']);
        $this->TCR->set_just_turn_back(true);
        $this->TCR->reset_cmd('');
        $this->TCR->add_msg('{LBL_SAVED}');
    }
    function cmd_sendsmxml() {
        $this->MAP_INI->MAP->sendXMLFile($this->TCR->GET['id'], $this->TCR->GET['fname']);
    }
    function parse_to_smarty() {
        $this->smarty->assign('XMLSM', $this->XMLSM);
    }
}

?>
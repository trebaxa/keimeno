<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011    									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

if (IN_SIDE != 1) {
    header('location:' . PATH_CMS . 'index.html');
    exit;
}


class wlu_fbwp_class extends modules_class {

    var $FBWP = array();

    function __construct() {
        parent::__construct();
        $this->TCR = new tc_request_class($this);
        if (ISADMIN == 1)
            $this->init();
    }

    function init() {
        $this->FBWP['WP'] = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLUFBWPCONTENT . " WHERE id=1");
    }

    function cmd_savewp() {
        updateTable(TBL_CMS_WLUFBWPCONTENT, 'id', 1, $this->TCR->POST['FORM']);
        $this->hard_exit();
    }

    function load_fb() {
        if ($this->gbl_config['wlu_fbwp_appid']=="" || $this->gbl_config['wlu_fbwp_pageid']=="") {
            echo ('Invalid application id or pageid');
            return;
        }
        $appID = $this->gbl_config['wlu_fbwp_appid'];
        $pageID = $this->gbl_config['wlu_fbwp_pageid']; // profileid
        // Create our Application instance (replace this with your appId and secret).
        $facebook = new Facebook(array('appId' => $this->gbl_config['wlu_fbwp_appid'], 'secret' => $this->gbl_config['wlu_fbwp_appsecret']));
        // Get User ID
        $userid = $facebook->getUser();
        // We may or may not have this data based on whether the user is logged in.
        // If we have a $userid id here, it means we know the user is logged into
        // Facebook, but we don't know if the access token is valid. An access
        // token is invalid if the user logged out of Facebook.

        if ($userid) {
            try {
                // Proceed knowing you have a logged in user who's authenticated.
                $userid_profile = $facebook->api('/me');
            }
            catch (FacebookApiException $e) {
                error_log($e);
                $userid = null;
            }
        }
        $this->FBWP['WPU']['userid']=$userid;
        // Login or logout url will be needed depending on current user state.
        $this->FBWP['WPU']['loginUrl'] = $facebook->getLoginUrl();
        $this->FBWP['WPU']['logoutUrl'] = $facebook->getLogoutUrl();
        // This call will always work since we are fetching public data.
        //$naitik = $facebook->api('/naitik');
        $is_fan = $facebook->api(array("method" => "fql.query", "query" => "SELECT uid FROM page_fan WHERE uid=$userid AND page_id=$pageID"));
        $this->FBWP['WPU']['is_fan'] = count($is_fan) > 0;
    }

    function parse_to_smarty() {
        $this->FBWP['editarea']['syntax'] = 'html';
        $this->smarty->assign('FBWP', $this->FBWP);
    }
}

?>
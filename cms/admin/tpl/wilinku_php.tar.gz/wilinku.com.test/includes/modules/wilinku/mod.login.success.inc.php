<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

#include (CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/init.inc.php');

$WLUVP = new wlu_videopunch_class();
global $e_object;
if ($e_object['land_destination'] > 0)
    $WLUVP->set_country($e_object['land_destination']);
unset($WLUVP);

?>
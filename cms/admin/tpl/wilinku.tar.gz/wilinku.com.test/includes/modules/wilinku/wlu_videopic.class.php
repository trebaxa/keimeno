<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

/**
 * wlu_videopic_class
 * 
 * @package Wilinku
 * @author Trebaxa GmbH & Co. KG
 * @copyright 2011
 * @version $Id$
 * @access public
 */
class wlu_videopic_class extends tc_class {

    /**
     * wlu_videopic_class::__construct()
     * 
     * @return
     */
    function __construct() {
        parent::__construct();
    }

    /**
     * wlu_videopic_class::dowload_file()
     * 
     * @param mixed $url
     * @return
     */
    function dowload_file($url) {
        if (strpos($url, '?') > 0) {
            list($video_link, $rest) = explode('?', $url);
            $videoname = basename($video_link);
        } else {
            $videoname = basename($url);
        }
        $fname = '../../../cache/video_' . md5($videoname) . $this->get_ext($videoname);
        if (file_exists($fname)) return $fname;
        $fp = fopen($fname, 'w+'); //This is the file where we save the information
        $ch = curl_init($url); //Here is the file we are downloading
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);
        return $fname;
    }


    /**
     * wlu_videopic_class::gen_thumbnail_from_video()
     * 
     * @param mixed $url
     * @return
     */
    function gen_thumbnail_from_video($url) {
        #$fname = $this->dowload_file($url, $videoname);
        $ffmpeg = CMS_ROOT . "includes/modules/wilinku/ffmpeg/ffmpeg";
        $tmp = CMS_ROOT . "cache";
        $options = "-an -y -f mjpeg -ss 2 -s 160x92 -vframes 1 ";
        $thumbpath = 'video_grabber_' . md5($url) . ".jpg";
        $cmd = $ffmpeg . " -i " . $url . " " . $options . " ../cache/" . $thumbpath;
        exec($cmd, $results);
        return $thumbpath;
    }

}

?>
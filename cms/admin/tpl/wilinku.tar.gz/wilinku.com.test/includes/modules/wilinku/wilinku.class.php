<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

if (IN_SIDE != 1) {
    header('location:' . PATH_CMS . 'index.html');
    exit;
}

class wilinku_class extends modules_class {
    var $countries = array();
    var $WELI = array();
    var $max_per_page = 50;
    var $lang_id = 1;
    var $user_object = array();

    function __construct() {
        global $GBL_LANGID;
        parent::__construct();
        $this->TCR = new tc_request_class($this);
        $this->VPLOG = new wlu_vplog_class();
        $this->lang_id = $GBL_LANGID;
    }

    function load_countries() {
        $this->countries = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE 1 ORDER BY land");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->countries[] = $row;
        }
    }

    function get_first_element($arr) {
        foreach ($arr as $key => $value) {
            return $value;
        }
    }

    function is_welinku_active($page) {
        $welinku_mods = array('wlu_collector', 'wilinku');
        $R = $this->db->query_first("SELECT * FROM " . TBL_CMS_TEMPLATES . " WHERE id=" . (int)$page);
        $this->WELI['weli_active'] = in_array($R['modident'], $welinku_mods);
    }

    function gen_paging_link_admin($start, $toadd = '') {
        return $this->modify_url($_SERVER['PHP_SELF'] . '?start=' . $start, $this->parse_query($toadd));
    }

    function parse_to_smarty() {
        $this->smarty->assign('WELI', $this->WELI);
    }

    function genPaging($total, $ovStart, $sorting = array()) {
        if (is_array($_REQUEST['QFILTER'])) {
            foreach ($_REQUEST['QFILTER'] as $key => $value) {
                $add .= '&QFILTER[' . $key . ']=' . $value;
            }
        }
        if (is_array($sorting)) {
            foreach ($sorting as $key => $value) {
                $add .= '&' . $key . '=' . urlencode($value);
            }
        }

        $toadd = $_SERVER['PHP_SELF'] . '?epage=' . $_REQUEST['epage'] . $add . '&id=' . $_REQUEST['id'] . '&cid=' . $_REQUEST['cid'] . '&section=' . $_REQUEST['section'] .
            '&aktion=' . $_REQUEST['aktion'];
        $start = (isset($ovStart)) ? abs((int)$ovStart) : 0;
        $total_pages = ceil($total / $this->max_per_page);
        $akt_page = round($start / $this->max_per_page) + 1;
        if ($total_pages > 0)
            $akt_pages = $akt_page . '/' . $total_pages;
        $start = ($start > $total) ? $total - $this->max_per_page : $start;
        $next_pages_arr = $back_pages_arr = array();
        if ($start > 0)
            $newStartBack = ($start - $this->max_per_page < 0) ? 0 : ($start - $this->max_per_page);
        if ($start > 0) {
            for ($i = $this->pro_num_prepages - 1; $i >= 0; $i--) {
                if ($newStartBack - ($i * $this->max_per_page) >= 0) {
                    $back_pages_arr[] = array('link' => $_SERVER['PHP_SELF'] . '?start=' . ($newStartBack - ($i * $this->max_per_page)), 'linkadmin' => $this->
                        gen_paging_link_admin(($newStartBack - ($i * $this->max_per_page)), $toadd), 'index' => ($akt_page - $i - 1));
                }
            }
        }
        if ($start + $this->max_per_page < $total) {
            $newStart = $start + $this->max_per_page;
            for ($i = 0; $i < $this->pro_num_prepages; $i++) {
                if ($newStart + ($i * $this->max_per_page) < $total) {
                    $next_pages_arr[] = array('link' => '', 'linkadmin' => $this->gen_paging_link_admin(($newStart + ($i * $this->max_per_page)), $toadd), 'index' => ($akt_page + $i +
                        1));
                }
            }
        }
        #	die;
        $_paging['start'] = $start;
        $_paging['total_pages'] = $total_pages;
        $_paging['startback'] = $newStartBack;
        $_paging['newstart'] = $newStart;
        $_paging['base_link_admin'] = $this->modify_url($_SERVER['PHP_SELF'] . '?epage=' . $_GET['epage'], $this->parse_query($toadd));
        $_paging['back_pages'] = $back_pages_arr;
        $_paging['akt_page'] = $akt_page;
        $_paging['next_pages'] = $next_pages_arr;
        $_paging['backlink'] = $this->gen_paging_link_admin($newStartBack, $toadd);
        $_paging['nextlink'] = $this->gen_paging_link_admin($newStart, $toadd);
        $_paging['count_total'] = $total;
        $this->smarty->assign('paging', $_paging);
        return $_paging;
    }

    function getHttpCode($url) {
        $userAgent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)';
        $url = trim($url);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLINFO_NAMELOOKUP_TIME, 6);
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);

        curl_exec($ch);
        $info = curl_getinfo($ch);
        #	echoarr($info);die;
        curl_close($ch);
        return $info['http_code'];
    }

    function get_remote_file($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLINFO_NAMELOOKUP_TIME, 6);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.5) Gecko/20041107 Firefox/1.0');
        $content = curl_exec($ch);
        curl_close($ch);
        return $content;
    }

    function validate_url_status($url) {
        #	$url = 'http://www.sherrysheyla.tk';
        $userAgent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)';
        $url = trim($url);
        if (!strstr($url, '/www.')) {
            # $url=str_replace('http://','http://www.',$url);
        }
        #echo $url;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLINFO_NAMELOOKUP_TIME, 6);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        curl_exec($ch);
        $info = curl_getinfo($ch);
        #echoarr($info);die;
        curl_close($ch);
        return $info;
    }

    function build_flatarr_of_children($cid, $label_id = 'C.id') {
        $cid = (int)$cid;
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", $cid, 0, -1);
        $menutree->build_flat_obj_arr($menutree->menu_array, $child_ids);
        if (is_array($child_ids))
            foreach ($child_ids as $child)
                $ids[] = $child['id'];
        $ids[] = $cid;
        $ids = array_unique($ids);
        $cids_str = implode(',', $ids);
        if ($cids_str[0] == ',')
            $cids_str = substr(1, $cids_str);
        $sql_cid_filter = " " . $label_id . " IN (" . $cids_str . ") ";
        unset($menutree);
        return array('cat_ids' => $child_ids, 'sql_cid_filter' => $sql_cid_filter);
    }

    function isValidURL($url = NULL) {
        if ($url == NULL)
            return false;

        $protocol = '(http://|https://)';
        $allowed = '([a-z0-9]([-a-z0-9]*[a-z0-9]+)?)';

        $regex = "^" . $protocol . // must include the protocol
            '(' . $allowed . '{1,63}\.)+' . // 1 or several sub domains with a max of 63 chars
            '[a-z]' . '{2,6}'; // followed by a TLD
        if (eregi($regex, $url) == true)
            return true;
        else
            return false;
    }

    function build_land_select_fe($selected_id) {
        $land_trans = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE id<>371 AND id<>370 AND visible=1 AND region_id<>8 ORDER BY land");
        while ($row = $this->db->fetch_array_names($result)) {
            $translation = explode(";", $row['transland']);
            $trans_arr = array();
            foreach ($translation as $value) {
                list($langid, $langvalue) = explode("|", $value);
                $trans_arr[$langid] = $langvalue;
            }
            $land_trans[$row['id']] = array('id' => $row['id'], 'label' => ((trim($trans_arr[$this->lang_id]) == "") ? $row['land'] : $trans_arr[$this->lang_id]),
                'selected' => (($selected_id == $row['id']) ? ' selected' : ''));
        }

        if (count($land_trans) > 0) {

            $sort_arr = array();
            foreach ($land_trans AS $uniqid => $row) {
                foreach ($row AS $sortkey => $value) {
                    $sort_arr[$sortkey][$uniqid] = $value;
                }
            }
            if (is_array($sort_arr['label']) && count($sort_arr['label']) > 0) {
                array_multisort($sort_arr['label'], SORT_ASC, SORT_REGULAR, $land_trans);
            }
            foreach ($land_trans as $lid => $lval) {
                $lang_opt .= '<option value="' . $lval['id'] . '"' . $lval['selected'] . '>' . $lval['label'] . '</option>';
            }
        }
        return $lang_opt;
    }

    function build_land_select_by_video_count_fe($selected_id) {
        $land_trans = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " L 
        LEFT JOIN " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC ON (VC.vc_countryid=L.id)
        WHERE id<>371 AND id<>370 AND visible=1 AND region_id<>8 
        GROUP BY L.id
        HAVING COUNT(VC.vc_countryid)>0
                ORDER BY land
        ");
        while ($row = $this->db->fetch_array_names($result)) {
            $translation = explode(";", $row['transland']);
            $trans_arr = array();
            foreach ($translation as $value) {
                list($langid, $langvalue) = explode("|", $value);
                $trans_arr[$langid] = $langvalue;
            }
            $land_trans[$row['id']] = array('id' => $row['id'], 'label' => ((trim($trans_arr[$this->lang_id]) == "") ? $row['land'] : $trans_arr[$this->lang_id]),
                'selected' => (($selected_id == $row['id']) ? ' selected' : ''));
        }

        if (count($land_trans) > 0) {

            $sort_arr = array();
            foreach ($land_trans AS $uniqid => $row) {
                foreach ($row AS $sortkey => $value) {
                    $sort_arr[$sortkey][$uniqid] = $value;
                }
            }
            if (is_array($sort_arr['label']) && count($sort_arr['label']) > 0) {
                array_multisort($sort_arr['label'], SORT_ASC, SORT_REGULAR, $land_trans);
            }
            foreach ($land_trans as $lid => $lval) {
                $lang_opt .= '<option value="' . $lval['id'] . '"' . $lval['selected'] . '>' . $lval['label'] . '</option>';
            }
        }
        return $lang_opt;
    }

    function gen_preferrred_lang($lang_id) {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_LANG . " WHERE approval=1 ORDER BY post_lang");
        while ($row = $this->db->fetch_array_names($result)) {
            $lang_opt .= '<option value="' . $row['id'] . '"' . (($nag_id == $row['id']) ? 'selected' : '') . '>' . $row['post_lang'] . '</option>';
        }
        return $lang_opt;
    }

    function cmd_init_register() {
        $this->WELI['registerform'] = $FORM = (array )$this->TCR->POST['FORM'];
        if (CU_LOGGEDIN) {
            $cuob = $this->db->query_first("SELECT * FROM " . TBL_CMS_CUST . " WHERE kid='" . $this->user_object['kid'] . "' LIMIT 1");
            if (is_array($FORM))
                $FORM = array_merge($cuob, $FORM);
            else
                $FORM = $cuob;
            unset($FORM['passwort']);
        }
        $this->WELI['lang_opt'] = $this->build_land_select_fe($FORM['land']);
        $this->WELI['land_destination'] = $this->build_land_select_by_video_count_fe($FORM['land_destination']);
        $this->WELI['preferred_lang'] = $this->gen_preferrred_lang($FORM['preferred_lang']);
        $this->smarty->assign('kregform', $FORM);
    }

    function cmd_register() {
        global $SMILE;
        $this->cmd_init_register();
        $this->WELI['registerform'] = $FORM = $this->TCR->POST['FORM'];
        $FORM_NOTEMPTY = $this->TCR->POST['FORM_NOTEMPTY'];
        $passwort_confirm = $this->TCR->POST['FORM']['passwort_confirm'];
        $securecode = $this->TCR->POST['FORM']['securecode'];
        unset($FORM['passwort_confirm']);
        unset($FORM["securecode"]);
        $k_obj = $this->db->query_first("SELECT * FROM " . TBL_CMS_CUST . " WHERE email='" . $FORM['email'] . "'");

        # Schon vorhanden?
        if (!CU_LOGGEDIN) {
            if ($k_obj['kid'] > 0 && validate_email_input($FORM['email'])) {
                $this->addSmartyErr($err_arr, 'email', '{ERR_EMAIL_VORHANDEN}');
            }
        }
        # gueltige EMail?
        if (!validate_email_input($FORM['email'])) {
            $this->addSmartyErr($err_arr, 'email', '{ERR_EMAIL}');
        }
        # Password confirm
        if (($FORM['passwort'] == "" || strlen($FORM['passwort']) < 4) && !CU_LOGGEDIN) {
            $this->addSmartyErr($err_arr, 'passwort', '{ERR_PASSWORD}');
        }
        if ($passwort_confirm != $this->TCR->POST['FORM']['passwort'] && $FORM['passwort'] != "") {
            $this->addSmartyErr($err_arr, 'passwort_confirm', '{ERR_PASSWORDCONFIRM}');
        }
        #capcha
        if (!CU_LOGGEDIN) {
            if (isset($_SESSION['captcha_spam']) AND $securecode == $_SESSION['captcha_spam']) {
                unset($_SESSION['captcha_spam']);
            }
            else
                $this->addSmartyErr($err_arr, 'securecode', '{ERR_SECODE}');
        }
        # generaller check
        foreach ($FORM as $key => $wert) {
            if (validate_subject($wert) == false) {
                $this->add_err('{ERR_INPUT}');
                break;
            }
        }
        # sex
        if (!empty($FORM['geschlecht'])) {
            $FORM['anrede'] = getCustomerSalutation($FORM['geschlecht']);
            $FORM['geschlecht'] = getCustomerSex($FORM['geschlecht']);
        }
        # mindory fields
        if (count($FORM_NOTEMPTY) > 0) {
            foreach ($FORM_NOTEMPTY as $key => $value) {
                if ($value == '') {
                    $this->addSmartyErr($err_arr, $key, '{LBL_MISSING}');
                }
                $FORM[$key] = $value;
            }
        }
        if (count($err_arr) == 0 && $this->no_errors() == TRUE) {
            $FORM['monat'] = date("m");
            $FORM['jahr'] = date("Y");
            $FORM['tag'] = date("d");
            $FORM['datum'] = date('Y-m-d');
            $FORM['is_cms'] = 1;
            if (CU_LOGGEDIN) {
                if ($FORM['passwort'] != "")
                    $FORM['passwort'] = md5($FORM['passwort']);
                updateTable(TBL_CMS_CUST, 'kid', $this->user_object['kid'], $FORM);
                HEADER('location:' . SSL_PATH_SYSTEM . $_SERVER['PHP_SELF'] . '?cmd=init_register&page=' . $this->TCR->POST['page'] . '&section=saved');
                exit;
            }
            else {
                $kid = insertTable(TBL_CMS_CUST, $FORM);
                $k_obj = $this->db->query_first("SELECT * FROM " . TBL_CMS_CUST . " WHERE kid='" . $kid . "'");
                sendMailTo(replacer(getEmailTemplate(990), $k_obj['kid'], -1)); // Template "Registrierung"
                $k_obj['passwort'] = md5($k_obj['passwort']);
                $k_obj['sessionid'] = session_id();
                // unique customer id
                $LL=$this->db->query_first("SELECT * FROM ".TBL_CMS_LAND." WHERE id=".$FORM['land_destination']);
                $LS=$this->db->query_first("SELECT * FROM ".TBL_CMS_LANG." WHERE id=".$FORM['preferred_lang']);
                $k_obj['wlu_userid'] = strtoupper($LL['country_code_2']).'-'.strtoupper($LS['local']).'-'.$kid;
                if ($this->gbl_config['mem_needactivate'] == 1) {
                    unset($_SESSION['kid']);
                    unset($_SESSION['password']);
                    $k_obj['sperren'] = 1;
                }
                else {
                    $_SESSION['kid'] = $k_obj['kid'];
                    $_SESSION['password'] = $k_obj['passwort'];
                }
                if ($this->gbl_config['login_mode'] != 'USERNAME') {
                    list($pre, $domain) = explode('@', $k_obj['email']);
                    $k_obj['username'] = $pre . genSid(3);
                }
                updateTable(TBL_CMS_CUST, 'kid', $k_obj['kid'], $k_obj);
                $user_obj = new member_class();
                $user_obj->setKid($kid);
                # $user_obj->setMemGroups($_POST['GROUPS'], $_POST['MEMBERGROUPSCOL'], false, true);
                $user_obj->addMemberToGroup(1100);
                $_SESSION['LOGCLASS']->addLog('INSERT', 'new registration ' . $k_obj['nachname'] . ', ' . $k_obj['kid']);

                // Admin. Email aufbauen
                $admin_email_text = "{LBL_NEWREGISTRATION} ({FM_NAME}): " . $FORM['vorname'] . " " . $FORM['nachname'] . "\n\n";
                $unset_arr = array('passwort', 'land', 'mailactive', 'monat', 'jahr', 'tag', 'is_cms', 'datum', 'birthday');
                foreach ($unset_arr as $key)
                    unset($FORM[$key]);
                #ksort($FORM);
                foreach ($FORM as $key_arr => $value_arr) {
                    $admin_email_text .= "\t" . strtoupper($key_arr) . ": " . trim(strip_tags($value_arr)) . "\n";
                }
                sendAdminMail('{LBL_NEWREGISTRATION} ' . $FORM['vorname'] . ' ' . $FORM['nachname'], $admin_email_text);

                # HEADER('location:' . SSL_PATH_SYSTEM . PATH_CMS . 'index.php?tl=-1&page=7&section=kregdone');
                HEADER('location:' . SSL_PATH_SYSTEM . $_SERVER['PHP_SELF'] . '?cmd=init_register&tl=-1&page=' . $this->TCR->POST['page'] . '&section=kregdone');
                exit;
            }
        }
        else {
            $this->smarty->assign('kregform_err', $err_arr);
            $this->smarty->assign('kregform', $FORM);
            #$this->smarty->assign('global_err', $err_gbl_arr);
            $this->smarty->assign('global_err', $this->GBLPAGE['err']);
            return;
        }
    }


} //CLASS


?>
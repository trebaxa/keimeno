<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2009     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
$WLU_MAPPING->EMPLOYEE 			= $EMPLOYEE->employee_obj;
$WLU_MAPPING->TCR->interpreter();
$WLU_MAPPING->parse_to_smarty();

$menu = array(
	"Articles" 	=> "section=articles",
	#"Links" 		=> "section=links&cmd=init_links"
	);
buildTopMenu($menu);

$content.='<% include file="wlu_mapping.tpl" %>';
?>
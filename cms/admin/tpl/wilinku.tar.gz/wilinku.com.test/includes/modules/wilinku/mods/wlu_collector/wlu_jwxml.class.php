<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_jwxmlplaylist_class extends wlu_colmaster_class {

function xml_format($txt) {
 return str_replace(array('?','=','&'),array('%3F','%3D','%26'),$txt);
}


//       <jwplayer:duration>'.$video['yt_videoduration'].'</jwplayer:duration>

function create_playlist_($videos) {
	if (is_array($videos) && count($videos) > 0) {
	 	$xml='<rss version="2.0" xmlns:jwplayer="http://developer.longtailvideo.com/">
  <channel>
    <title>your playlist</title>
    ';
	 	foreach ($videos as $vid => $video) {
	 			 		$parts = explode('&',$video['yt_watchpageurl']);
	 		$video['yt_watchpageurl'] = $parts[0];
	 		$xml.='
	 	<item>
      <title>'.$this->xml_format($video['yt_videotitle']).'</title>
      <jwplayer:file>'.$this->xml_format($video['yt_watchpageurl']).'</jwplayer:file>

      <jwplayer:image>http://www.'.FM_DOMAIN.$this->xml_format($video['localthumb']).'</jwplayer:image>
    </item>
    ';
    break;
	 	}
	 	$xml.='  </channel>
</rss>';
	}
file_put_contents(CMS_ROOT . 'your_playlist.xml',$xml);	
echo $xml;die;
return $xml;
}

function create_playlist($videos) {
	if (is_array($videos) && count($videos) > 0) {
	 	$xml="<?xml version='1.0' encoding='UTF-8'?>
<playlist version='1' xmlns='http://xspf.org/ns/0/'>
  <trackList>
    ";
	 	foreach ($videos as $vid => $video) {
	 		$parts = explode('&',$video['yt_watchpageurl']);
	 		$video['yt_watchpageurl'] = $parts[0];
	 		$xml.='
	 	<track>
      <location>'.($video['yt_watchpageurl']).'</location>
			<title>'.$video['yt_videotitle'].'</title>
      <image>http://www.'.FM_DOMAIN.($video['localthumb']).'</image>
    </track>
    ';

	 	}
	 	$xml.='  </trackList>
</playlist>';
	}
#file_put_contents(CMS_ROOT . 'your_playlist.xml',$xml);	
#echo $xml;die;
return $xml;
}
	
}
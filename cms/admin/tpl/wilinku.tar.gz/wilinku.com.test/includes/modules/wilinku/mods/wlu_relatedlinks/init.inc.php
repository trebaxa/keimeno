<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}

$module_id = 'wlu_relatedlinks';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU Related Links',
		'intern_aktion' 	=> '',
		'id' 							=> $module_id,
		'php' 						=> WLU_MOD_ROOT . $module_id . '/wlu_links.inc',
		'hasperm' 				=> false,
		'epage' 					=> array('wlu_links.inc'), #admin. PHP Scripts
		'epage_dir'				=> WLU_MOD_ROOT,
		'is_content_page'	=> false,
		'class_name'			=> 'wlu_relatedlinks_class', #PHP Master Class Name of Modul
		);


DEFINE('ICON_FIELD', 'wlu_fileico');
DEFINE('ICON_PREFIX', 'WLULINKS_ICO');
DEFINE('TBL_CMS_WLULINKS', TBL_CMS_PREFIX.'wlu_links');
DEFINE('TBL_CMS_WLULINKS_CATS', TBL_CMS_PREFIX.'wlu_links_cats');
DEFINE('TBL_CMS_WLU_LINKLOC', TBL_CMS_PREFIX.'wlu_linkloc'); 

DEFINE('RLICO_PATH', 'file_data/related_links/');

if(!class_exists('wlu_relatedlinks_class')) {
	include(WLU_MOD_ROOT . $MODULE[$module_id ]['id'] . '/wlu_links.class.php'); 	
}

$RL_OBJ = new wlu_relatedlinks_class();
?>
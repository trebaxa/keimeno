<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
if (IN_SIDE!=1) {header('location:'.PATH_CMS.'index.html'); exit;}

$module_id = 'wlu_employees';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU Employees',
		'intern_aktion' 	=> '',
		'id' 							=> $module_id,
		'php' 						=> '',
		'hasperm' 				=> true,
		'epage' 					=> array('wlu_employee.inc'), #admin. PHP Scripts
		'epage_dir'				=> WLU_MOD_ROOT,
		'is_content_page'	=> false,
		'class_name'			=> 'wlu_employee_class', #PHP Master Class Name of Modul
		);

if (ISADMIN==1) {
	include(WLU_MOD_ROOT . $MODULE[$module_id ]['id'] . '/wlu_employee.class.php'); 	
}
?>
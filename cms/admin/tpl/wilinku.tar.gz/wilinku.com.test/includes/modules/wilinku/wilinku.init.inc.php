<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2009     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our hompage at www.trebaxa.com									  *
#************************************************************

// wird autom. in der INIT geladen : $GAL_OBJ->load_tree();

?>
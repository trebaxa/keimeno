<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_gblajax_class extends wilinku_class {
	
function __construct() {
	parent::__construct();
}


function cmd_search() {
	$start = (int)$this->TCR->GET['start'];
	$VP = new wlu_videopunch_class();
	$videos = $VP->search_by_tag($this->TCR->REQUEST['tag'], $start, $this->gbl_config['wlu_videosperpage']);
	//sorting
	$direc 		= ($this->TCR->REQUEST['direc']=='ASC') ? 'SORT_ASC' : 'SORT_DESC';
	$sorttype = ($this->TCR->REQUEST['sorttype']=='NUM') ? 'SORT_NUMERIC' : 'SORT_STRING';
	if (count($videos) > 0) $videos 	= sortDbResult($videos, strval('yt_lastupdate'), constant($direc), constant($sorttype));
	$this->smarty->assign('FILTER', array('direc' => $direc));
	$this->smarty->assign('qfilter_query',http_build_query(array('QFILTER' => $QFILTER)));
	$this->VP['video_list'] 				= $videos;
	//PAGING
	$add="";
	if ( is_array($this->TCR->REQUEST['QFILTER'])) {
		foreach ($this->TCR->REQUEST['QFILTER'] as $key => $value) {
			$add.='&QFILTER['.$key.']='.$value;
		}
	}
	$link	= $_SERVER['PHP_SELF'] . '?page='.$this->TCR->REQUEST['page'].$add.'&cmd=search&tag='.urlencode($this->TCR->REQUEST['tag']);
	$VP->genPaging($this->VP['video_totalcount'], $start, $link, (int)$this->gbl_config['wlu_videosperpage']);
	$this->parse_to_smarty();
	#echoarr($this->VP['video_list']);
	#echoarr($this->TCR);
	ECHORESULTCOMPILEDFE('
	<style type="text/css">
@import "<% $PATH_CMS %>includes/modules/wilinku/template/main_style.css";
@import "<% $PATH_CMS %>includes/modules/wilinku/template/vp_style.css";
</style>

<% include file="wluvpliste_10052.tpl" %> 
<script>
 $("#videotable").width(900);
</script>');
}

function parse_to_smarty() {
 $this->smarty->assign('VP', $this->VP);
}

function cmd_redirect_related_link() {
	$id=(int)base64_decode($this->TCR->GET['id']);	
	if ($_SESSION['WLU']['related_links'][$id]==0) {
		$R=$this->db->query_first("SELECT * FROM ".TBL_CMS_WLULINKS." WHERE id=".$id);
		$this->db->query("UPDATE ".TBL_CMS_WLULINKS." SET rl_clicked=rl_clicked+1 WHERE id=" . $id);
	}
	$_SESSION['WLU']['related_links'][$id]++;
	header('location: ' . $R['rl_url']);
	exit;
}

}
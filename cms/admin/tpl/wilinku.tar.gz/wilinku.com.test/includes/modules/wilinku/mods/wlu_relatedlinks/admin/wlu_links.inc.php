<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
$RL_OBJ->EMPLOYEE 					= $EMPLOYEE->employee_obj;
$RL_OBJ->TCR->interpreter();

if ($_POST['aktion']=="a_save_config") {
  $CONFIG_OBJ->save($_POST['FORM']);
  HEADER('location:'.$_SERVER['PHP_SELF'].'?epage='.$_GET['epage'].'&aktion=conf&configcid='.$_POST['configcid'].'&msg='.base64_encode('{LBL_SAVED}'));
  exit;
}

$menu = array(
	"{LBLA_SHOWALL}"=>"",
	"Report"=>"section=report",
	"Validation"=>"section=validation",
	);
if ($EMPLOYEE->employee_obj['PERM']->perm['wlu_vp_isvideomaster']==1 )	{
	$menu["{LA_MODCONFIGURATION}"]="aktion=conf";
}	
buildTopMenu($menu);

$RL_OBJ->init();
	 
if ($_REQUEST['cmd']=='' && $_GET['section']=='') {
	$QFILTER=array();
	$RL_OBJ->load_links($QFILTER, 0, '', '');
}

if ($_REQUEST['section']=='report') {
	$RL_OBJ->set_report_filter();		
}

if ($_GET['aktion']=='conf') {
	$content.='<h1>{LA_MODCONFIGURATION}</h1>'.$CONFIG_OBJ->buildTable(39,39);
}
$content.='<% include file="wlu_linklist.tpl" %>';
$RL_OBJ->parse_to_smarty();
?>
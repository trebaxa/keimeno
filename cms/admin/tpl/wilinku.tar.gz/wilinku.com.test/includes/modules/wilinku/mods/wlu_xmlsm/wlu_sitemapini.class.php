<?php

class wlu_site_mapini_class extends tc_class {

    var $urls = array();
    var $MAP = NULL;

    function __construct($smTable, $langTable) {
        parent::__construct();
        $this->MAP = new SiteMap($smTable, $langTable, TBL_CMS_SMDEFS, $this->db, CMS_ROOT);
        $this->MAP->set_sitemap_name('wlu_video_punch_sitemap');
        $this->MAP->host = 'http://www.' . FM_DOMAIN . PATH_CMS;
    }

    function buildUrlTable($langid) {
        $C = new wlu_colmaster_class();
        $this->alllang = $langid == -1;
        $result_sm = $this->db->query("SELECT * FROM " . TBL_CMS_WLUXMLSM . " WHERE sm_active=1");
        while ($row_sm = $this->db->fetch_array_names($result_sm)) {

            if ($row_sm['sm_ident'] == 'VIDEOS') {  
                $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID
	FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L, " .
                    TBL_CMS_WLU_VCATMATRIX . " VCAT,
	" . TBL_CMS_LANDCONTINET . " CON, " . TBL_CMS_LANDREGIONS . " R
	WHERE  VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND L.region_id=R.id
	AND CON.id=R.lr_continet_id
	AND V.yt_blocked=0
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	GROUP BY V.yt_videoid
	ORDER BY V.yt_videoid ASC
	";
                $result = $this->db->query($sql);
                while ($row = $this->db->fetch_array_names($result)) {
                    $url['url'] = 'http://www.' . FM_DOMAIN . $C->gen_videodeatil_link($row, 'all');
                    $url['frecvent'] = $row_sm['sm_changefreq'];
                    $url['priority'] = $row_sm['sm_priority'];
                    $urls[] = $url;
                }
            }

            unset($C);
            $result_lang = $this->db->query("SELECT id,post_lang,language FROM " . TBL_CMS_LANG . " WHERE " . (($this->alllang === true) ? '' : " id=" . $langid . " AND ") .
                " approval=1 ORDER BY post_lang");
            while ($rowl = $this->db->fetch_array_names($result_lang)) {


            } // WHILE LANG
        }
        $this->urls = $urls;
        foreach ($this->urls as $key => $uobj) {
            $this->MAP->addPage($uobj['url'], $uobj['frecvent'], $uobj['priority']);
        }
        $this->MAP->create();
    }


}

?>
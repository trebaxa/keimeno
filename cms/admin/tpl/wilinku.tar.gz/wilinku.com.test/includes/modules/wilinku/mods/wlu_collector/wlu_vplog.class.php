<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************


class wlu_vplog_class extends tc_class {

var $EMPLOYEE = NULL;	
var $TYPES = array('INFO','UPDATE','QUERY_RUN','DELETE');

function __construct() {
	parent::__construct();
	$this->TCR 			= new tc_request_class($this);
}



function vp_addlog($comment, $type='INFO') {
 $LOG = array(
 	'vl_time' 				=> time(),
 	'vl_comment' 			=> mysql_real_escape_string($comment),
 	'vl_mid' 					=> $this->EMPLOYEE['MID'],
 	'vl_type' 				=> $type,
 	'vl_employeename' => $this->EMPLOYEE['mitarbeiter_name'] 	 	
 );
 insertTable(TBL_CMS_WLU_VPLOG, $LOG);
}

function set_log_options(&$row) {
	$row['datetime'] = ($row['vl_time'] > 0) ? date('d.m.Y H:i:s', $row['vl_time']) : '-';
}

function vp_load_table() {
	$start = (int)$_GET['start'];
  $FILTER = $_GET['FILTER'];
  if (is_array($FILTER))	{
  	foreach ($FILTER as $key => $value) {
  	 	$sql.= $key.'="'.$value."'";
  	}
  }
	$result = $this->db->query("SELECT * FROM ".TBL_CMS_WLU_VPLOG." WHERE 1 ".$sql." 
	ORDER BY vl_time DESC
	LIMIT ".$start.",1000");
	while($row = $this->db->fetch_array_names($result)){
		$this->set_log_options($row);
		$this->VPLOG['all_logs'][] = $row;
	}
$result = $this->db->query("SELECT DISTINCT vl_employeename,vl_mid FROM ".TBL_CMS_WLU_VPLOG." WHERE 1");	
	while($row = $this->db->fetch_array_names($result)){
		$this->VPLOG['employees'][] = $row;
	}
}

function parse_to_smarty() {
	$this->VPLOG['TYPES'] = $this->TYPES;
 	$this->smarty->assign('VPLOG', $this->VPLOG);
}


}
?>
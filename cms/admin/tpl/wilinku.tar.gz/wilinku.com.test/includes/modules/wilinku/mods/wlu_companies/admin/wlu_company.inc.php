<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

$WLU_COMPANY = new wlu_company_class(); 
$EMPMAN = new wlu_employee_class();
$CM = new country_class();
$INTERPRETER = $WLU_COMPANY;
include(CMS_ROOT .  'admin/inc/interpreter.inc.php'); 

$menu = array(
	"{LBL_ALL_COMPANIES}" => 	"",
	);
buildTopMenu($menu);

validateModul('mod_wilinku');

if ($_GET['aktion']=="countryrelated") {
	$CM->load_regions();
	$CM->load_regions_by_continent($_GET['continentid']);
	$CM->load_countries_by_region($_GET['regionid']);
}

$WLU_COMPANY->load_companies();
$WLU_COMPANY->load_company();
$EMPMAN->load_employees();

$content.='<% include file="wlu_companyies.tpl" %>';
$WLU_COMPANY->parse_to_smarty();
?>
<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

include (CMS_ROOT . 'admin/inc/module.class.php');
$MODULE_OBJ = new module_class(MODULE_ROOT . 'wilinku/mods/wlu_fbwp/');
$MODULE_OBJ->TCR->interpreter();

$WLUFBWP->TCR->interpreter();

if ($_POST['aktion'] == "a_save_config") {
    $CONFIG_OBJ->save($_POST['FORM']);
    $TCMASTER->hard_exit();
}


buildTopMenu(array("FB Welcome Page" => "epage=" . $_GET['epage'], "{LA_MODCONFIGURATION}" => "section=conf&epage=" . $_GET['epage'], "Style&Files" => "section=modstylefiles&epage=" . $_GET['epage']));

if ($_REQUEST['section'] == 'conf') {
    $WLUFBWP->FBWP['CONFTAB'] = $CONFIG_OBJ->buildTable(43, 43);
}

$content .= '<% include file="wlu_fbwp.tpl" %>';
$WLUFBWP->parse_to_smarty();

?>
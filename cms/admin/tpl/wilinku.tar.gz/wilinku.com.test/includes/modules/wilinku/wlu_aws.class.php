<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

include(CMS_ROOT . 'includes/modules/wilinku/wlu_aws.config.php');
if ($gbl_config['wlu_aws_key']!="") include(CMS_ROOT . 'includes/modules/aws/sdk-1.4.2/sdk.class.php');

class wlu_aws_class extends wilinku_class {
	
function __construct() {
	parent::__construct();
	if ($this->gbl_config['wlu_aws_key']!="") $this->s3o = new AmazonS3();
}


function get_bucket_list() {
	$this->S3O['bucket_list'] = $this->s3o->get_bucket_list();	
}

function parse_to_smarty() {
	$this->smarty->assign('AWS3O', $this->S3O);
}

# list only filenames
function aws_file_search_simple($bucket, $word='') {
  $this->S3O['aws_file_list_simple'] = $this->s3o->get_object_list($bucket,array(
    'marker' => $word
		));
}

# list files
function aws_file_search($bucket, $word='') {
	$awsresult = $this->s3o->list_objects($bucket,array(
	'prefix' => $word
	));
	foreach ($awsresult->body->Contents as $key => $file)		{
		$lastmod = strval($file->LastModified);
		$lastmod_date = date('Y-m-d',strtotime($lastmod));
		$lastmod_date_ger = date('d.m.Y',strtotime($lastmod));
		$lastmod_date_short = date('m.Y',strtotime($lastmod));
		$this->S3O['aws_file_list'][] = array(
		'file_name' 		=> strval($file->Key),
		'file_nameb64'	=> base64_encode(strval($file->Key)),
		'file_size' 		=> strval($file->Size),
		'file_owner' 		=> strval($file->Owner->DisplayName),
		'file_etag' 		=> str_replace('"','',strval($file->ETag)),
		'file_lastmod' 	=> strval($file->LastModified),
		'lastmod_date_short' 	=> $lastmod_date_short,
		'lastmod_date' 	=> $lastmod_date,
		'lastmod_date_ger' 	=> $lastmod_date_ger,
		);
	}
}

# get file
function aws_get_file_metadata($bucket, $filename) {
	$file = $this->s3o->get_object_metadata($bucket, $filename);
	$lastmod = strval($file['LastModified']);
	$lastmod_date = date('Y-m-d',strtotime($lastmod));
	$lastmod_date_ger = date('d.m.Y',strtotime($lastmod));
	$lastmod_date_short = date('m.Y',strtotime($lastmod));
	
	$url=$this->get_object_url($bucket, $filename);
	
	$this->S3O['aws_file_metadata'] = array(
	'file_name' 		=> $file['Key'],
	'file_nameb64'	=> base64_encode($file['Key']),
	'file_size' 		=> $file['Size'],
	'file_owner' 		=> $file['Owner']['DisplayName'],
	'file_etag' 		=> str_replace('"','',$file['ETag']),
	'file_lastmod' 	=> $file['LastModified'],
	'file_url'			=> $url,
	#'file_url_protected'	=> $s3->getAuthenticatedURL($bucket.'.media.wilinku.com', $file['Key'], 3600,true,false),

	'lastmod_date_short' 	=> $lastmod_date_short,
	'lastmod_date' 	=> $lastmod_date,
	'lastmod_date_ger' 	=> $lastmod_date_ger,
	);
	unset($s3);
	#echoarr($this->get_object_url($bucket, $filename));
	#echoarr($this->S3O['aws_file_metadata']);
}

function get_object_url( $bucket, $filename, $preauth=0,$opt=null) {
	return $this->s3o->get_object_url($bucket, $filename);
}

}
<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

$VIDEOPUNCH->VP['vp_active']=true;
$VIDEOPUNCH->TCR->interpreterfe();


if ($_REQUEST['cmd']=='') {
	$VIDEOPUNCH->cmd_default();
}

$VIDEOPUNCH->parse_to_smarty();
?>
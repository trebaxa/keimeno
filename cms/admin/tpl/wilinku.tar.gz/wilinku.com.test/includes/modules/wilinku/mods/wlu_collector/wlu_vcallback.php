<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************

DEFINE('IN_SIDE', 1);
DEFINE('NO_MODULES',1);
DEFINE('ISADMIN',1);

include('../../../../session.inc.php');
require_once('wlu_vimeo.inc.php');

// Create the object and enable caching
$vimeo = new phpVimeo($gbl_config['wlu_vm_consumerkey'], $gbl_config['wlu_vm_secret']);
$vimeo->enableCache(phpVimeo::CACHE_FILE, CMS_ROOT . 'cache', 300);

// Clear session
if ($_GET['clear'] == 'all') {
  
    session_destroy();
    session_start();
}

// Set up variables
$state 					= $_SESSION['vimeo_state'];
$request_token 	= $_SESSION['oauth_request_token'];
$access_token 	= $_SESSION['oauth_access_token'];

// Coming back
if ($_REQUEST['oauth_token'] != NULL && $_SESSION['vimeo_state'] === 'start') {
    $_SESSION['vimeo_state'] = $state = 'returned';
}

// If we have an access token, set it
if ($_SESSION['oauth_access_token'] != null) {
    $vimeo->setToken($_SESSION['oauth_access_token'], $_SESSION['oauth_access_token_secret']);
}

switch ($_SESSION['vimeo_state']) {
/*    default:

        // Get a new request token
        $token = $vimeo->getRequestToken('http://cms.trebaxa.com/includes/modules/wilinku/mods/wlu_collector/wlu_vcallback.php');

        // Store it in the session
        $_SESSION['oauth_request_token'] = $token['oauth_token'];
        $_SESSION['oauth_request_token_secret'] = $token['oauth_token_secret'];
        $_SESSION['vimeo_state'] = 'start';

        // Build authorize link
        $authorize_link = $vimeo->getAuthorizeUrl($token['oauth_token'], 'write');
        echo 'B';
        break;
        */

    case 'returned':

        // Store it
        if ($_SESSION['oauth_access_token'] === NULL && $_SESSION['oauth_access_token_secret'] === NULL) {
            // Exchange for an access token
            $vimeo->setToken($_SESSION['oauth_request_token'], $_SESSION['oauth_request_token_secret']);
            $token = $vimeo->getAccessToken($_REQUEST['oauth_verifier']);

            // Store
            $_SESSION['oauth_access_token'] = $token['oauth_token'];
            $_SESSION['oauth_access_token_secret'] = $token['oauth_token_secret'];
            $_SESSION['vimeo_state'] = 'done';
            // Set the token
            $vimeo->setToken($_SESSION['oauth_access_token'], $_SESSION['oauth_access_token_secret']);
        }

        // Do an authenticated call
        try {
           # $videos = $vimeo->call('vimeo.videos.getUploaded');
           # echo 'state: ' . $_SESSION['vimeo_state'];
           	header('Location: /admin/run.php?epage=wlu_vcollector.inc&msg='.base64_encode('Vimeo logged in'));
           	exit;
        }
        catch (VimeoAPIException $e) {
            echo "Encountered an API error -- code {$e->getCode()} - {$e->getMessage()}";
        }

        break;
}

?>


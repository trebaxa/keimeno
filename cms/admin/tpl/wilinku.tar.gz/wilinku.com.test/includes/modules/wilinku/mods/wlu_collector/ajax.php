<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
$sb=trim($_REQUEST['q']) or exit;
if (!isset($_REQUEST['q']) || empty($sb)) exit;

DEFINE('IN_SIDE', 1);
DEFINE('NO_MODULES',1);
$root = str_replace('includes/modules/wilinku/mods/wlu_collector','',dirname(__FILE__) . '/');

include($root.'includes/session.inc.php');
require $root.'class_db_zugriff.php';
require $root.'includes/settings.php';
include(SYSTEM_ROOT . 'includes/config.php');

#*********************************
# SMARTY
#*********************************
include_once($root . 'smarty/Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir 		= SHOP_ROOT . 'smarty/templates/de';
$smarty->compile_dir 			= SHOP_ROOT . 'smarty/templates_c';
$smarty->cache_dir 				= SHOP_ROOT . 'smarty/cache';
$smarty->config_dir 			= SHOP_ROOT . 'smarty/configs';
$smarty->left_delimiter 	= '<%';
$smarty->right_delimiter 	= '%>';
$smarty->caching = false; 

#include(CMS_ROOT . 'includes/modules/modules.class.php');
include(CMS_ROOT . 'includes/modules/wilinku/wilinku.class.php');
include(CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_colmaster.class.php');
include(CMS_ROOT . 'includes/modules/wilinku/mods/wlu_collector/wlu_vsearch.class.php');


$SW = new wlu_vsearch_class();
echo $SW->gen_keyword_list($sb);
unset($SW);

?>
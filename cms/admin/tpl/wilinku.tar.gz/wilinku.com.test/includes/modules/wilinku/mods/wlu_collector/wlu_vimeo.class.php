<?php
#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************
class wlu_vimeo_class extends wlu_colmaster_class {
	

function __construct() {
	parent::__construct();
	require_once('wlu_vimeo.inc.php');
	// Get a new request token
	$this->vimeo = new phpVimeo(trim($this->gbl_config['wlu_vm_consumerkey']), trim($this->gbl_config['wlu_vm_secret']));
  $this->vimeo->enableCache(phpVimeo::CACHE_FILE, CMS_ROOT . 'cache', 300);	
  $this->state 					= $_SESSION['vimeo_state'];
	$this->request_token 	= $_SESSION['oauth_request_token'];
	$this->oauth_access_token 	= $_SESSION['oauth_access_token'];
	$this->oauth_access_token_secret 	= $_SESSION['oauth_access_token_secret'];
	// If we have an access token, set it
	if ($this->oauth_access_token != null) {
    $this->vimeo->setToken($this->oauth_access_token,$this->oauth_access_token_secret);
	}
	$this->TCR 			= new tc_request_class($this);
	$this->QUERY 		= new wlu_query_class();	
}

function parse_to_smarty() {
 $this->VIMEO['loggedin'] = ($this->oauth_access_token != null);
 $this->VIMEO['state'] = $_SESSION['vimeo_state'];
 $this->smarty->assign('VIMEO', $this->VIMEO);
}

function connect() {
	if ($_SESSION['vimeo_state']=='done') {
		return;
	}
	$token = $this->vimeo->getRequestToken('http://www.'.FM_DOMAIN.'/includes/modules/wilinku/mods/wlu_collector/wlu_vcallback.php');
	$_SESSION['oauth_request_token'] = $token['oauth_token'];
	$_SESSION['oauth_request_token_secret'] = $token['oauth_token_secret'];
	$_SESSION['vimeo_state'] = 'start';
}

function reconnect() {
	$this->logout();
	$this->connect();
}

function build_auth_link() {
 $this->connect();
 $this->authorize_link = $this->vimeo->getAuthorizeUrl($_SESSION['oauth_request_token'], 'write');
 return $this->authorize_link;
}

function logout() {
	unset($_SESSION['oauth_request_token']);
	unset($_SESSION['oauth_request_token_secret']);
	unset($_SESSION['vimeo_state']);
	unset($_SESSION['oauth_access_token']);
}

function cmd_vi_logout() {
 $this->logout();	
 $this->TCR->add_msg('Vimeo logged out');				
}

# Get a list of videos uploaded by a user. 
function vi_load_videos_by_user($user_id) {
	$videos = $this->vimeo->call('vimeo.videos.getUploaded', array('user_id' => $user_id));
}

# Get a list of the videos in a channel. 
function vi_load_videos_by_channel($channel_id) {
	$videos = $this->vimeo->call('vimeo.channels.getVideos', array('channel_id' => $channel_id));
}

# Get a list of all public channels.  
function vi_load_all_channel() {
	$this->VIMEO['all_channels'] = $this->vimeo->call('vimeo.channels.getAll', array('sort' => 'alphabetical'));
}

# Get lots of information on a video.   
function vi_load_single_video($video_id) {
	$video_id = str_replace('VI','',$video_id);
	try {
		$ret = $this->vimeo->call('vimeo.videos.getInfo', array('video_id' => $video_id));
	} catch (VimeoAPIException $e) {
	
	}
	return $ret;
}

function validate_video($video_id) {
 $V = $this->vi_load_single_video($video_id);
 return is_array($V->video);
}

#Get a list of videos that have the specified tag. 
function vi_load_videos_by_tag($tag, $page, $per_page, $sort) {
	$videos = $this->vimeo->call('vimeo.videos.getByTag', array(
	'full_response' => 1,
	'tag' 					=> $tag,
	'page' 					=> $page,
	'per_page' 			=> $per_page,
	'sort' 					=> $sort
	));
return $videos;	
}

#Get a list of videos by author 
function vi_load_videos_by_author($author, $page, $per_page, $sort) {
	$videos = $this->vimeo->call('vimeo.videos.getUploaded', array(
	'full_response' => 1,
	'user_id' 			=> $author,
	'page' 					=> $page,
	'per_page' 			=> $per_page,
	'sort' 					=> $sort
	));
return $videos;	
}


#Search for videos. 
function vi_search_videos($searchTerm, $page, $per_page, $sort) {
	$videos = $this->vimeo->call('vimeo.videos.search', array(
	'full_response' => 1,
	'query' 				=> $searchTerm,
	'page' 					=> $page,
	'per_page' 			=> $per_page,
	'sort' 					=> $sort
	));
return $videos;	
}

function search_vimeo_videos($QFILTER, $childs, &$videos, $c_sql) {
	$sqladd = " FROM ".TBL_CMS_WLU_APPROVED_VIDEOS." V, ".TBL_CMS_WLU_CATS." C, ".TBL_CMS_WLU_VCATMATRIX." VCAT,
	 ".TBL_CMS_WLU_VIDEO_TO_COUNTRY." VC, ".TBL_CMS_LAND." L
	WHERE VC.vc_videoid=V.yt_videoid
	AND VC.vc_countryid=L.id
	AND V.yt_stock='VI'
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	".(($childs['sql_cid_filter']!="") ? " AND (".$childs['sql_cid_filter'].")" : '')."
	 " 
	   . ((is_array($QFILTER) && $QFILTER['countryid'] > 0 ) 	? " AND VC.vc_countryid=".$QFILTER['countryid'] : $c_sql)
	   . ((is_array($QFILTER) && $QFILTER['queryid'] > 0 ) 		? " AND Q.id='".$QFILTER['queryid']."'" 				: "")
	   . ((is_array($QFILTER) && $QFILTER['yt_blocked'] > 0 ) ? " AND V.yt_blocked=1" 												: " AND V.yt_blocked=0")
	 ;
$sql="SELECT *,V.yt_videoid AS VID,C.id AS CID " . $sqladd . "
	GROUP BY V.yt_videoid
	ORDER BY V.yt_lastupdate DESC
	LIMIT 100";
	$result =$this->db->query($sql);	
	while($row = $this->db->fetch_array_names($result)) {
		$this->set_video_options($row);
		$row['lastexec_datetime'] = ($row['yp_lastexec'] > 0) ? date('d.m.Y H:i:s', $row['yp_lastexec']) : '-';
		$videos[$row['VID']] = $row;
	}
	$C = $this->db->query("SELECT COUNT(V.yt_videoid) AS VCOUNT " . $sqladd . " GROUP BY V.yt_videoid");
	return (int)$this->db->num_rows($C);
}

function sync($YTOPTIONS, $query) {
	$queryid = $query['QID'];
	$this->connect();
	$queryType 		= isset($YTOPTIONS['queryType']) ? $YTOPTIONS['queryType'] : null;
	$searchTerm 	= $YTOPTIONS['searchTerm'];
	$startIndex 	= ((int)$YTOPTIONS['startIndex']==0) ? 1 : (int)$YTOPTIONS['startIndex'];
	$maxResults 	= (int)$YTOPTIONS['maxResults'];
	if ($startIndex<=1) {
		unset($_SESSION['vp_log'][$queryid]);
		$this->db->query("UPDATE ".TBL_CMS_WLU_VPQUERY." SET yp_execcount=yp_execcount+1 WHERE id=".(int)$queryid);
		$this->db->query("DELETE FROM ".TBL_CMS_WLU_VP." WHERE yt_qid='".(int)$queryid."'");
		$this->db->query("DELETE FROM ".TBL_CMS_WLU_VIDEO_TO_QUERY." WHERE vq_queryid='".(int)$queryid."'");		
	}
	$this->db->query("UPDATE ".TBL_CMS_WLU_VPQUERY." SET yp_new=0 WHERE id=".(int)$queryid);
	$Q=$this->QUERY->load_query((int)$queryid);
	if ($query['vp_vitype']=='TAG') {
		$feed = $this->vi_load_videos_by_tag($searchTerm, $startIndex, $maxResults, $YTOPTIONS['orderby']);
	} else if ($query['vp_vitype']=='AUT') {
		$feed = $this->vi_load_videos_by_author($Q['vp_author'], $startIndex, $maxResults, $YTOPTIONS['orderby']);	
	} else {
		$feed = $this->vi_search_videos($searchTerm, $startIndex, $maxResults, $YTOPTIONS['orderby']);	
	}
	#echoarr($feed);
	$RET['queryresult'] 											= $this->set_video_opt($feed, $query);
	$RET['FORM']['YTOPTIONS'] 								= $_REQUEST['YTOPTIONS'];
	$RET['FORM']['YTOPTIONS']['startIndex'] 	+= $RET['FORM']['YTOPTIONS']['maxResults'];
	$RET['TotalResults'] 											= strval($feed->videos->total);
	$RET['YTOPTIONS']['doneProcent'] 					= round((100/$RET['FORM']['YTOPTIONS']['maxTotalLimit']) * $RET['FORM']['YTOPTIONS']['startIndex'],2);
	$this->move_to_db($RET);
 	$RET['vp_log']['count_added'] 	= (int)$_SESSION['vp_log'][$queryid]['count_added'];
 	$RET['vp_log']['count_skipped'] = (int)$_SESSION['vp_log'][$queryid]['count_skipped'];
	return $RET;
}

function set_video_opt($feed,$query) {
	if (is_array($feed->videos->video)) {
	#	echoarr($feed->videos->video);die;
		foreach ($feed->videos->video as $entry) {
			list($ld,$lt) = explode(' ',strval($entry->modified_date));
			list($upload_date,$ltu) = explode(' ',strval($entry->upload_date));

			// TAGS
			$entry_tags=$tags=$urls=array();
			if (is_array($entry->tags->tag)) {
				foreach ($entry->tags->tag as $tag) {
					$tags[] = $tag->_content;
				}
			}
			if (is_array($entry->urls->url)) {
				foreach ($entry->urls->url as $url) {
					$urls[] = $url->_content;
				}
			}
			if (trim($query['vp_wlutags'])!="" && is_array($tags)) {
				$wlu_tags = explode(',',$query['vp_wlutags']);
				$entry_tags = array_merge($wlu_tags, $tags);
				} else {
					$entry_tags = $tags;
				}
				$id = 'VI'.trim(strval($entry->id));
			
				$res[$id] = array(
				'yt_videoid' 						=> $id,
				'yt_thumbnailurl' 			=> $entry->thumbnails->thumbnail[2]->_content,
				'yt_thumbnailwidth'			=> $entry->thumbnails->thumbnail[2]->width,
				'yt_thumbnailheight'		=> $entry->thumbnails->thumbnail[2]->height,
				'yt_videotitle' 				=> $entry->title,
				'yt_videodescription' 	=> $entry->description,
				'yt_viewcount' 					=> $entry->number_of_plays,				
				'yt_recorded' 					=> $upload_date,
				'yt_videoduration' 			=> $entry->duration,
				'yt_flashplayerurl' 		=> 'http://player.vimeo.com/video/'.trim(strval($entry->id)),
				'yt_watchpageurl'				=> $urls[0],
				'yt_videotags' 					=> (is_array($entry_tags)) ? implode(';', $entry_tags) : '',
				'yt_updated' 						=> strval($entry->modified_date),
				'yt_lastupdate'					=> $ld,
				'yt_upload_date'				=> $upload_date,
				'yt_qid'								=> (int)$query['QID'],
				'yt_author_username'		=> $entry->owner->username,
				'yt_author_realname'		=> $entry->owner->realname
			 );

			}
		}
		return $res;
	}

function move_to_db($RET) {
	if (is_array($RET['queryresult'])) {
		#	echoarr($RET['queryresult']);die;
		foreach ($RET['queryresult'] as $videoid => $video) {
			if (getCount(TBL_CMS_WLU_VP,'yt_videoid',"yt_videoid='".$videoid."'")==0) {
				if (is_array($video)) {
					foreach ($video as $key => $wert) $video[$key] = mysql_real_escape_string($video[$key]);
					insertTable(TBL_CMS_WLU_VP, $video);
					$_SESSION['vp_log'][$video['yt_qid']]['count_added']++;
				}
				} else {
					$_SESSION['vp_log'][$video['yt_qid']]['count_skipped']++;
				}
				// Update Query Matrix
				$_SESSION['vp_log'][$video['yt_qid']]['vq_order']+=10;
				$this->db->query("REPLACE INTO ".TBL_CMS_WLU_VIDEO_TO_QUERY." SET vq_order=".(int)$_SESSION['vp_log'][$video['yt_qid']]['vq_order'].",vq_videoid='".$video['yt_videoid']."',vq_queryid=".$video['yt_qid']);
			}
		}
	}
}
?>
<?PHP

$module_id = 'wlu_fbwp';

$MODULE[$module_id] = array(
		'module_name' 		=> 'WiLinkU FB Welcome Page',
		'intern_aktion' 	=> '',
		'id' 				=> $module_id,
		'php' 				=> MODULE_DIR . $module_id . '/wlu_fbwp.inc',
		'hasperm' 			=> false,
		'epage' 			=> array('wlu_fbwp.inc'),
		'epage_dir'			=> WLU_MOD_ROOT,
		'is_content_page'	=> true
		);

DEFINE('TBL_CMS_WLUFBWPCONTENT', TBL_CMS_PREFIX.'wlu_fbwp');
#include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/facebook-php-sdk/src/facebook.php');
include (WLU_MOD_ROOT . $MODULE[$module_id]['id'] . '/fbwp.class.php');


$WLUFBWP = new wlu_fbwp_class();
?>
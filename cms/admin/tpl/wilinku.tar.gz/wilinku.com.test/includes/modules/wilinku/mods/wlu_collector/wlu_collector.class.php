<?php

#************************************************************
# Scripting by Trebaxa Company(R) 2011     									*
# This script is not freeware																*
# Get in contact with Trebaxa Company : service@trebaxa.com *
# Or visit our homepage at www.trebaxa.com									*
#************************************************************


class wlu_collector_class extends wlu_colmaster_class {

    var $menu_tree = array();
    var $COLOBJ = array();
    var $redirect_page = 'wlu_vcollector.inc';
    var $pro_num_prepages = 3;

    function __construct() {
        parent::__construct();
        #	$this->VPLOG 		= new wlu_vplog_class();
        $this->ADHOCV = new wlu_adhocvideo_class();
        $this->YTV = new wlu_yt_class();
        $this->VI = new wlu_vimeo_class();
        $this->TCR = new tc_request_class($this);
        $this->QUERY = new wlu_query_class();
        $this->COMMENTS = new wlu_comments_class();
        $this->s3 = new wlu_aws_class();
    }


    function load_all_ytcats() {
        $this->YTV->load_all_ytcats();
    }

    function create_path($cid, &$bread_crumb) {
        $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $cid);
        $bread_crumb[] = $C['ytc_name'];
        if ($C['ytc_parent'] > 0) {
            $this->create_path($C['ytc_parent'], $bread_crumb);
        }
    }

    function cat_breadcrumb_update($cid) {
        $cid = (int)$cid;
        $childs = $this->build_flatarr_of_children($cid);
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_CATS . " C WHERE " . $childs['sql_cid_filter']);
        while ($row = $this->db->fetch_array_names($result)) {
            $bread_crumb = array();
            $this->create_path($row['id'], $bread_crumb);
            $bread_crumb = array_reverse($bread_crumb, true);
            $CATUPT = array('ytc_path' => trim(mysql_real_escape_string(implode('/', $bread_crumb))));
            $CATUPT['ytc_path'] = '/' . $CATUPT['ytc_path'];
            updateTable(TBL_CMS_WLU_CATS, 'id', $row['id'], $CATUPT);
        }
    }

    function cmd_cat_savecat() {
        $FORM = $_POST['FORM'];
        $id = (int)$_POST['id'];
        if ($_POST['FORM']['ytc_name'] == "" || (count($_POST['country_ids']) == 0 && $FORM['ytc_isindi'] == 1 && $id > 0)) {
            $this->COLOBJ['fault_form'] = TRUE;
            $this->TCR->reset_cmd($_POST['orgaktion']);
            $this->load_cat($id);
            $this->COLOBJ['CATOBJ'] = array_merge($this->COLOBJ['CATOBJ'], $FORM);
            $this->TCR->set_fault_form(true);
            return;
        }

        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'label_title' => 'ytc_name', 'bread_break_sym' => '/'));
        if ($id > 0) {
            updateTable(TBL_CMS_WLU_CATS, 'id', $id, $FORM);
        }
        else {
            $FORM['ytc_crmid'] = $this->EMPLOYEE['MID'];
            $FORM['ytc_crby'] = mysql_real_escape_string($this->EMPLOYEE['mitarbeiter_name']);
            $id = insertTable(TBL_CMS_WLU_CATS, $FORM);
            $this->VPLOG->vp_addlog('add VP cat [' . $id . ']: ' . $FORM['ytc_name'], 'VP_CAT_ADD');
        }
        // activate  category for all countrys
        if ($FORM['ytc_isindi'] == 1 || count($_POST['country_ids']) > 0) {
            $this->update_country_matrix($_POST['country_ids'], $id);
        }
        else {
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE 1 ORDER BY land");
            while ($row = $this->db->fetch_array_names($result)) {
                $country_ids[$row['id']] = $row['id'];
            }
            $this->update_country_matrix($country_ids, $id);
        }

        // Path Update
        $this->cat_breadcrumb_update($id);

        $this->TCR->reset_cmd('catedit');
        $this->TCR->add_url_tag('section', 'cats');
        $this->TCR->add_url_tag('id', $id);
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function cmd_cat_approve() {
        $this->set_approve($_GET['value'], $_GET['id']);
        $this->VPLOG->vp_addlog('approve VP cat [' . $_GET['id'] . ']: ' . $this->get_cat_name($_GET['id']), 'VP_CAT_APPROVE');
        $this->TCR->reset_cmd('showall');
        $this->TCR->add_url_tag('section', 'cats');
        $this->TCR->add_url_tag('id', $id);
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function set_approve($value, $id) {
        $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_approval='" . (int)$value . "' WHERE id=" . (int)$id . " LIMIT 1");
    }

    function cmd_save_cat_table() {
        $cats = $_POST['CATS'];
        if (is_array($cats)) {
            $cats = sortDbResult($cats, 'ytc_order', SORT_ASC, SORT_NUMERIC);
            $k = 0;
            foreach ($cats as $id => $row) {
                $k += 10;
                $row['ytc_order'] = $k;
                $id = $row['id'];
                unset($row['id']);
                updateTable(TBL_CMS_WLU_CATS, 'id', $id, $row);
            }
        }
        $this->TCR->set_url_tag('starttree');
        $this->TCR->reset_cmd('showall');
        $this->TCR->add_url_tag('section', 'cats');
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function load_query($id) {
        $this->COLOBJ['query'] = $this->QUERY->load_query((int)$id);
        #$this->COLOBJ['query'] = $this->YTV->YT['query'];
    }

    function get_cat_name($id) {
        $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$id);
        return $C['ytc_name'];
    }

    function cmd_cat_delete() {
        $id = (int)$this->TCR->GET['id'];
        $this->load_cat($id);
        $this->TCR->set_just_turn_back(true);
        if ($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 0 && $this->CATOBJ['ytc_crmid'] != $this->EMPLOYEE['MID']) {
            #$this->TCR->add_msge('no permissions');
            $this->add_err('{LBL_NOACCESS}');
            return;
        }
        if (getCount(TBL_CMS_WLU_CATS, 'id', "ytc_parent=" . $id) > 0) {
            $this->TCR->add_msge('Has children');
            return;
        }
        if (getCount(TBL_CMS_WLU_APPROVED_VIDEOS, '*', "yt_cid=" . $id) > 0) {
            $this->TCR->add_msge('Has videos');
            return;
        }
        if (getCount(TBL_CMS_WLU_LINKMATRIX, '*', "lm_cat_id=" . $id) > 0) {
            $this->TCR->add_msge('Has related links');
            return;
        }
        $this->VPLOG->vp_addlog('delete VP cat [' . $id . ']: ' . $this->get_cat_name($id), 'VP_CAT_DELETE');
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $id . " LIMIT 1");
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE cm_cid=" . $id);
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_cid=" . $id);

        $all_queries = $this->load_queries($id);
        foreach ($all_queries as $key => $Q) {
            $this->delete_query($Q['QID']);
        }
        $this->TCR->add_msg('{LBL_DELETED}');
    }

    function load_cat($id) {
        $this->CATOBJ = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . (int)$id);

        $this->CATOBJ['queries'] = $this->load_queries((int)$id);
        $this->CATOBJ['country_matrix'] = $this->load_cat_country_matrix($id);
        $this->CATOBJ['countries'] = $this->load_all_countries_table($id);
        $cname = (is_array($this->country_id_matrix)) ? $this->country_name_index[end($this->country_id_matrix)] : 'SET COUNTRY';
        $this->CATOBJ['country_name'] = ((count($this->country_id_matrix) > 1) ? '{LA_ALLCOUNTRIES}' : $cname);
        $this->CATOBJ['editable_by_country'] = false;
        if (is_array($this->CATOBJ['all_country_ids'])) {
            foreach ($this->CATOBJ['all_country_ids'] as $key => $country_id) {
                if (is_array($this->EMPLOYEE['responsible_countries_ids'])) {
                    if (in_array($country_id, $this->EMPLOYEE['responsible_countries_ids'])) {
                        $this->CATOBJ['editable_by_country'] = true;
                        break;
                    }
                }
            }
        }
        else {
            $this->CATOBJ['editable_by_country'] = (!is_array($this->CATOBJ['all_country_ids']) && $this->CATOBJ['ytc_isindi'] == 1);
        }
        if ($id == 0) {
            $this->CATOBJ['ytc_approval'] = 1;
            $this->CATOBJ['ytc_isindi'] = 1;
        }

        $this->COLOBJ['CATOBJ'] = $this->CATOBJ;
    }


    function load_cat_country_matrix($cid) {
        $this->country_id_matrix = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " M, " . TBL_CMS_LAND . " L 
	WHERE L.id=M.cm_countryid AND M.cm_cid=" . (int)$cid);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->country_id_matrix[$row['cm_countryid']] = $row['cm_countryid'];
            $this->country_name_index[$row['cm_countryid']] = $row['land'];
        }
        return $this->country_id_matrix;
    }


    function load_all_countries_table($id) {
        $this->countries = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " M
		, " . TBL_CMS_LAND . " C
		, " . TBL_CMS_LANDCONTINET . " CO 
		, " . TBL_CMS_LANDREGIONS . " R
		WHERE M.cm_cid=" . (int)$id . " 
		AND M.cm_countryid=C.id
		AND R.lr_continet_id=CO.id
		AND C.region_id=R.id
		ORDER BY CO.lc_name,R.lr_name,C.land
		");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->countries[$row['lr_continet_id']][$row['region_id']][$row['cm_countryid']] = $row;
            $this->CATOBJ['all_country_ids'][] = $row['cm_countryid'];
        }

        foreach ($this->countries as $continetid => $regions) {
            $r = $this->get_first_element($regions);
            $c = $this->get_first_element($r);
            $this->countries[$continetid]['lc_name'] = $c['lc_name'];
            foreach ($regions as $regionid => $country) {
                $c = $this->get_first_element($country);
                $this->countries[$continetid][$regionid]['lr_name'] = $c['lr_name'];
            }
        }
        #echoarr($this->countries);
        return $this->countries;
    }

    function update_country_matrix($country_ids, $cid) {
        $cid = (int)$cid;
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE cm_cid=" . $cid);
        if (is_array($country_ids)) {
            foreach ($country_ids as $key => $id) {
                $EM = array('cm_cid' => (int)$cid, 'cm_countryid' => $id);
                insertTable(TBL_CMS_WLU_COUNTRY_TO_CAT, $EM);
            }
        }
    }

    function cmd_add_country_matrix() {
        $this->update_country_matrix($_POST['country_ids'], $_POST['id']);
        $this->TCR->set_url_tags('continentid', 'regionid', 'id');
        $this->TCR->reset_cmd('countryrelated');
        $this->TCR->add_url_tag('section', 'cats');
        $this->TCR->add_msg('{LBL_SAVED}');
    }


    function build_tree_selectbox_leafsonly($selected_id, $block_id) {
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", 0, 0, -1);
        $this->COLOBJ['cat_selectbox'] = $menutree->output_as_selectbox_leafsonly((int)$selected_id, (int)$block_id);
        unset($menutree);
    }


    function build_tree_selectbox($selected_id, $block_id) {
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", 0, 0, -1);
        $this->COLOBJ['cat_selectbox'] = $menutree->output_as_selectbox((int)$selected_id, (int)$block_id, array('key' => '0', 'value' => '{LA_NOMATTERALL}'));
        unset($menutree);
    }

    function build_tree_selectbox_filtered($selected_id, $block_id) {
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", 0, 0, -1);
        $this->remove_cats_by_country_relationship($menutree);
        $this->COLOBJ['cat_selectbox'] = $menutree->output_as_selectbox((int)$selected_id, (int)$block_id, array('key' => '0', 'value' => '{LA_NOMATTERALL}'));
        unset($menutree);
    }


    function load_tree($selected_id) {
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id'));

        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", 0, 0, -1);
        $cat_tree_arr = ARRAY('cat_selectbox' => $menutree->output_as_selectbox((int)$selected_id), 'cat_selid' => $selected_id, 'cat_count' => getCount(TBL_CMS_WLU_CATS,
            'id', "1"), 'cat_tree' => $menutree->menu_array, 'cat_breadcrumbs' => $menutree->breadcrumb_trail($menutree->menu_array, (int)$selected_id));
        $this->smarty->assign('cat_tree', $cat_tree_arr);
        unset($menutree);
    }


    function remove_other_mixers_cats_by_emp($arr, &$new_arr, $empid) {
        foreach ($arr as $key => $cat) {
            if (($cat['ytc_isindi'] == 1 && $cat['ytc_crmid'] == $empid) || ($cat['ytc_parent'] == 0 && is_array($cat['children']) && count($cat['children']) > 0) || $cat['ytc_isindi'] ==
                0) {
                $new_arr[$key] = $cat;
                unset($new_arr[$key]['children']);
                if (is_array($cat['children'])) {
                    $this->remove_other_mixers_cats_by_emp($cat['children'], $new_arr[$key]['children'], $empid);
                }
            }
        }
    }

    function remove_cats_mixers_country_relationship($arr, &$menutree, &$new_arr, &$responsible_country_ids, &$countries_to_cat) {
        foreach ($arr as $key => $cat) {
            $schnittmenge = array();
            if (is_array($countries_to_cat[$cat['id']]))
                $schnittmenge = array_intersect($countries_to_cat[$cat['id']], $responsible_country_ids);
            if ((count($schnittmenge) > 0) || $cat['ytc_isindi'] == 0) {
                $new_arr[$key] = $cat;
                unset($new_arr[$key]['children']);
                if (is_array($cat['children'])) {
                    $this->remove_cats_mixers_country_relationship($cat['children'], $menutree, $new_arr[$key]['children'], $responsible_country_ids, $countries_to_cat);
                }
            }
            else {
                unset($menutree->menu_flat_array[$cat['id']]);
            }
        }
    }

    function remove_cats_by_country_relationship(&$menutree) {
        if ($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 0) {
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_ADMIN_RESPCOUNTRIES . " WHERE ec_eid=" . $this->EMPLOYEE['MID']);
            while ($row = $this->db->fetch_array_names($result)) {
                $responsible_country_ids[$row['ec_countryid']] = $row['ec_countryid'];
            }
            $this->remove_countries_by_list($menutree, $responsible_country_ids);
        }
    }

    function remove_countries_by_list(&$menutree, $country_ids) {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE 1");
        while ($row = $this->db->fetch_array_names($result)) {
            $countries_to_cat[$row['cm_cid']][$row['cm_countryid']] = $row['cm_countryid'];
        }
        $nested_array = array();
        $this->remove_cats_mixers_country_relationship($menutree->menu_array, $menutree, $nested_array, $country_ids, $countries_to_cat);
        $menutree->menu_array = $nested_array;
    }

    function buildATree($node_id = 0, $startree = 0, $empid = 0, $countryid = 0) {
        $node_id = (int)$node_id;
        $startree = (int)$startree;
        $countryid = (int)$countryid;
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'approval_col' => 'ytc_approval', 'visible_col' =>
            'ytc_visible', 'atree_toadd' => 'section=cats&cmd=showall', 'admin_edit_aktion' => 'catedit'));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_name", 0, 0, -1);
        // remove cats by mixer's view
        $this->remove_cats_by_country_relationship($menutree);
        // remove cats by employee ID
        if ($empid > 0 && $this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 1) {
            $nested_array = array();
            $this->remove_other_mixers_cats_by_emp($menutree->menu_array, $nested_array, (int)$empid);
            $menutree->menu_array = $nested_array;
        }
        // remove cats by country filter
        if ($countryid > 0) {
            $this->remove_countries_by_list($menutree, array($countryid));
        }

        $menutree->atree_toadd = 'section=' . $_REQUEST['section'] . (($empid > 0) ? '&employeeid=' . $empid : '') . (($countryid > 0) ? '&countryid=' . $countryid : '');
        $this->COLOBJ['admin_tree'] = $menutree->output_as_admin_nav($node_id);
    }

    function load_cat_table($starttree) {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE 1");
        while ($row = $this->db->fetch_array_names($result)) {
            $countries_to_cat[$row['cm_cid']][$row['cm_countryid']] = $row['cm_countryid'];
        }
        $cats = array();
        $order = ($this->TCR->GET['order'] != "") ? $this->TCR->GET['order'] : 'name';
        $direc = ($this->TCR->GET['direc'] == "DESC") ? 'DESC' : 'ASC';
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_CATS . " 
		WHERE 
		" . (($this->TCR->REQUEST['wlu_wordfilter'] != "") ? " 
        ytc_name LIKE '%" . $this->TCR->REQUEST['wlu_wordfilter'] . "%'" : "ytc_parent=" . (int)$starttree . "") . " 
		ORDER BY ytc_" . $order . " " . $direc);
        while ($row = $this->db->fetch_array_names($result)) {
            $k++;
            $row['childcount'] = getCount(TBL_CMS_WLU_CATS, 'id', "ytc_parent=" . $row['id']);
            $row['icons'][] = genEditImgTagADMIN($row['id'], '&section=cats', 'catedit');
            $row['icons'][] = ($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 1) ? genApproveImgTagADMIN($row['id'], $row['ytc_approval'], '&starttree=' . $starttree,
                '', 'cat_approve') : '';
            $row['icons'][] = ($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 1 || $row['ytc_crmid'] == $this->EMPLOYEE['MID']) ? genDelImgTagADMINConfirm($row['id'],
                'cat_delete', '{LBLA_CONFIRM}', '&starttree=' . $starttree) : '';
            #$row['icons'][] 		= ($row['ytc_isindi']==1) ? '<a href="'.$_SERVER['PHP_SELF'].'?epage=wlu_vcollector.inc&aktion=countryrelated&id='.$row['id'].'"><img src="./images/countryrelated.png" border="0"></a>' : '';
            $row['morder'] *= 1;
            $cats[] = $row;
        }

        // remove cats by mixer's view
        if ($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 0) {
            foreach ($cats as $key => $cat) {
                $schnittmenge = array();
                if (is_array($countries_to_cat[$cat['id']]))
                    $schnittmenge = array_intersect($countries_to_cat[$cat['id']], $this->EMPLOYEE['responsible_countries_ids']);
                if ((count($schnittmenge) == 0 && $cat['ytc_isindi'] == 1)) {
                    unset($cats[$key]);
                }
            }
        }
        // remove cats by employee ID
        if ($_GET['employeeid'] > 0) {
            foreach ($cats as $key => $row) {
                if ($row['ytc_isindi'] == 1 && $row['ytc_crmid'] != $_GET['employeeid']) {
                    unset($cats[$key]);
                }
            }
        }
        $this->COLOBJ['cat_table'] = $cats;
    }


    function parse_to_smarty() {
        $this->YTV->parse_to_smarty();
        $this->VI->parse_to_smarty();
        $this->COMMENTS->parse_to_smarty();
        $this->ADHOCV->parse_to_smarty();
        $this->COLOBJ['fix_stocks'] = $this->fix_stocks;
        $this->COLOBJ['ALLCOUNTRYID'] = ALLCOUNTRYID;
        $this->smarty->assign('COLOBJ', $this->COLOBJ);
        $this->smarty->assign('QFILTER', $_SESSION['QFILTER']);
        $this->s3->parse_to_smarty();
    }

    function cmd_ax_get_cat_boxes() {
        $id = (int)$_POST['id'];
        $this->load_query($id);
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE 1");
        while ($row = $this->db->fetch_array_names($result)) {
            $country_index[$row['id']] = $row['land'];
        }
        $this->add_tree_selectboxes($this->COLOBJ['query']['assigned_cat_ids'], 'query', (int)$_POST['countryid']);
        $this->smarty->assign('country_index', $country_index);
        $content = '
	<div><input type="hidden" name="FORM[vp_countryid]" value="' . (int)$_POST['countryid'] . '">
	<table border="0" width="100%">
	<% if ($country_index.' . (int)$_POST['countryid'] . '!="") %>
	<tr>
     <td>Assigned country:</td> 
     <td><% $country_index.' . (int)$_POST['countryid'] . ' %></td>
     </tr> 
     <%/if%>
	<% foreach from=$COLOBJ.query.cat_selectboxes key=qc item=catselectbox %>
	<tr>
	<td>{LA_PLEASESELECTCATEGORY} (<%$qc%>):</td>
	<td><select name="CIDS[]">
	<% $catselectbox %>
	</select>
	</td>
	</tr>
	<%/foreach%>
	</table></div>';
        $this->parse_to_smarty();
        ECHORESULTCOMPILED($content);
    }


    function save_query($id, $FORM, $YTOPTIONS, $CIDS) {
        $id = (int)$id;
        $FORM['vp_countryid'] = (int)$FORM['vp_countryid'];
        $FORM['vp_query'] = serialize($YTOPTIONS);
        $new_query = false;
        if ($id > 0) {
            updateTable(TBL_CMS_WLU_VPQUERY, 'id', $id, $FORM);
            $this->VPLOG->vp_addlog('update VP query [' . $id . ']: ' . $FORM['vp_queryname'], 'VP_QUERY_UPDATE');
        }
        else {
            $FORM['vp_create'] = time();
            $FORM['vp_querycreator'] = mysql_real_escape_string($this->EMPLOYEE['mitarbeiter_name']);
            $FORM['vp_qcrid'] = $this->EMPLOYEE['MID'];
            $id = insertTable(TBL_CMS_WLU_VPQUERY, $FORM);
            $this->VPLOG->vp_addlog('add VP query [' . $id . ']: ' . $FORM['vp_queryname'], 'VP_QUERY_ADD');
            $new_query = true;
        }

        $this->db->query("DELETE FROM " . TBL_CMS_WLU_QUERY_TO_CAT . " WHERE qc_qid=" . $id);
        if (is_array($CIDS)) {
            $prio = 0;
            foreach ($CIDS as $key => $cid) {
                $prio++;
                $QC_MATRIX = array('qc_cid' => $cid, 'qc_qid' => $id, 'qc_prio' => $prio);
                if ($cid > 0)
                    replaceTable(TBL_CMS_WLU_QUERY_TO_CAT, $QC_MATRIX);
            }
            // Videos CAT neu zuordnen
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " WHERE vq_queryid=" . $id);
            while ($row = $this->db->fetch_array_names($result)) {
                $this->db->query("DELETE FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_videoid='" . $row['vq_videoid'] . "'");
                $prio = 0;
                foreach ($CIDS as $key => $cid) {
                    $prio++;
                    $VC_MATRIX = array('vcm_videoid' => $row['vq_videoid'], 'vcm_cid' => $cid, 'vcm_prio' => $prio, 'vcm_queryid' => $id);
                    if ($cid > 0) {
                        replaceTable(TBL_CMS_WLU_VCATMATRIX, $VC_MATRIX);
                       # $this->update_count_approved_videos($cid);
                    }
                }
            }

        }

        if ($new_query == true) {
            header('location: ' . $_SERVER['PHP_SELF'] . '?return=1&aktion=query_run&epage=' . $this->TCR->REQUEST['epage'] . '&section=qrun&id=' . $id);
            exit;
        }
        return $id;
    }

    function cmd_yt_save_query() {
        $this->smarty->assign('catsetfault', array_sum($_POST['CIDS']) == 0);

        $this->TCR->add_url_tag('section', 'addquery');
        $this->TCR->reset_cmd('yt_query_edit');
        if ($_POST['FORM']['vp_queryname'] == "" || ($_POST['YTOPTIONS']['searchTerm'] == "" && $_POST['FORM']['vp_author'] == "") || $_POST['FORM']['vp_wlutags'] == "" ||
            array_sum($_POST['CIDS']) == 0) {
            $this->COLOBJ['fault_form'] = TRUE;
            $this->TCR->set_fault_form(true);
            $this->add_err('{LA_MISSINGFIELDS}');
        }
        else {
            $id = $this->save_query($_POST['id'], $_POST['FORM'], $_POST['YTOPTIONS'], $_POST['CIDS']);
            $this->TCR->add_url_tag('id', $id);
            $this->TCR->add_msg('{LBL_SAVED}');
        }
    }

    function load_queries($cid) {
        $cid = (int)$cid;
        $queries = array();
        $sql = "SELECT *,Q.id AS QID FROM " . TBL_CMS_WLU_VPQUERY . " Q, " . TBL_CMS_WLU_QUERY_TO_CAT . " M
		WHERE M.qc_cid=" . $cid . "
		AND M.qc_qid=Q.id	
	ORDER BY vp_queryname";

        $result = $this->db->query($sql);
        #".(($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster']==1) ? "" : " AND vp_qcrid=".$this->EMPLOYEE['MID'])."
        while ($row = $this->db->fetch_array_names($result)) {
            $row['CID'] = $cid;
            $this->QUERY->set_query_options($row);
            $queries[] = $row;
        }
        return $queries;
    }


    function cmd_yt_query_delete() {
        $this->load_query($_GET['id']);
        $this->VPLOG->vp_addlog('query deleted [' . $_GET['id'] . ']: ' . $this->COLOBJ['query']['vp_queryname'], 'DELETE');
        $this->QUERY->delete_query($_GET['id']);
        $this->TCR->reset_cmd('list');
        $this->TCR->add_url_tag('section', 'qrun');
        $this->TCR->add_msg('{LBL_DELETED}');
    }

    function cmd_yt_query_approve() {
        $this->db->query("UPDATE " . TBL_CMS_WLU_VPQUERY . " SET vp_approval='" . (int)$_GET['value'] . "' WHERE id=" . (int)$_GET['id'] . " LIMIT 1");

        $this->TCR->add_url_tag('section', 'addquery');
        $this->TCR->add_url_tag('cid', $_GET['cid']);
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function cmd_reset_video_country_relationship() { // NOT USED ABER WICHTIG!!!!
        $this->loadcrctab();
        $r = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE yt_stock<>'AH' AND yt_stock<>'WU'");
        while ($video = $this->db->fetch_array_names($r)) {
            $this->set_video_country_matrix($video);
        }
        $this->update_location_counts();
        die('X');
    }

    function set_video_country_matrix($video) {
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " WHERE vc_videoid='0' OR vc_videoid='" . $video['yt_videoid'] . "'");
        $result = $this->db->query("SELECT Q.vp_countryid FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " M, " . TBL_CMS_WLU_VPQUERY . " Q
	WHERE M.vq_videoid='" . $video['yt_videoid'] . "'
	AND Q.id=M.vq_queryid
	");
        while ($row = $this->db->fetch_array_names($result)) {
            $VC_MATRIX = array('vc_videoid' => $video['yt_videoid'], 'vc_countryid' => $row['vp_countryid'], 'vc_regionid' => $this->get_region_of_country($row['vp_countryid']),
                'vc_contid' => $this->get_continent_of_country($row['vp_countryid']));
            replaceTable(TBL_CMS_WLU_VIDEO_TO_COUNTRY, $VC_MATRIX);
            $ret[] = $VC_MATRIX;
        }
        return (array )$ret;
    }

    function load_iso_table() {
        $this->COLOBJ['iso_list'] = parent::load_iso_table();
    }

    function cmd_update_all_cat_counts() {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_VPQUERY . "");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->update_cat_count_by_query($row['id']);
        }
        $this->TCR->add_msg('{LBL_DONE}');
        $this->TCR->set_just_turn_back(true);
    }

    function cmd_update_all_cat_counts_approved_videos() {
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_CATS . "");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->update_approvedvideo_count($row['id']);
            $C = $row;
            while ($C['id'] > 0) {
                $count = 0;
                $this->update_total_approved_count($C, $count);
                $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_videocountapptotal=" . (int)$count . " WHERE id=" . $C['id']);
                $C = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE id=" . $C['ytc_parent']);
            }
        }
        $this->TCR->add_msg('{LBL_DONE}');
        $this->TCR->set_just_turn_back(true);
    }


    function cmd_alphasort_cats() {
        $cats = array();
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_CATS . " WHERE ytc_parent=" . (int)$this->TCR->GET['parent'] . " ORDER BY ytc_name");
        while ($row = $this->db->fetch_array_names($result)) {
            $cats[] = $row;
        }
        $k = 0;
        foreach ($cats as $key => $row) {
            $k += 10;
            $this->db->query("UPDATE " . TBL_CMS_WLU_CATS . " SET ytc_order=" . $k . " WHERE id=" . $row['id']);
        }
        $this->TCR->add_msg('{LBL_DONE}');
        $this->TCR->set_just_turn_back(true);
    }


    function update_cat_count_by_query($query_id) {
        $query_id = (int)$query_id;
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_QUERY_TO_CAT . " WHERE qc_qid=" . $query_id);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->update_total_video_count($row['qc_cid']);
        }
    }

    function add_video_to_catmatrix($video_id) {
        $this->db->query("DELETE FROM " . TBL_CMS_WLU_VCATMATRIX . " WHERE vcm_videoid='" . $video_id . "'");
        $sql = "SELECT *, QCM.qc_cid AS CATID FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " M, " . TBL_CMS_WLU_VPQUERY . " Q, " . TBL_CMS_WLU_QUERY_TO_CAT . " QCM
	WHERE M.vq_videoid='" . $video_id . "'
	AND Q.id=M.vq_queryid
	AND QCM.qc_qid=Q.id
	GROUP BY QCM.qc_cid
	";
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $I = array('vcm_videoid' => $video_id, 'vcm_cid' => $row['CATID']);
            if ($row['CATID'] > 0)
                replaceTable(TBL_CMS_WLU_VCATMATRIX, $I);
            $this->update_approvedvideo_count($row['CATID']);
        }
    }

    function approve_videos_by_query($vids, $query_id) {
        $SW = new wlu_vsearch_class();
        $this->loadcrctab();
        if (is_array($vids)) {
            $this->load_query($query_id);
            foreach ($vids as $key => $id) {
                $I = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_VP . " WHERE yt_videoid='" . $id . "' LIMIT 1");
                #	if ($_POST['QF']['method']=='accept_sel') {
                $this->db->query("DELETE FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE yt_videoid='" . $id . "'");
                $I['yt_apptime'] = time();
                $I['yt_valtime'] = time();
                $I['yt_stock'] = $this->COLOBJ['query']['vp_stock'];
                $I['yt_videosrcname'] = $this->fix_stocks[$I['yt_stock']];
                $I['yt_videosrcname'] = $this->fix_stocks[$I['yt_stock']];
                $I['yt_creatorid'] = $this->COLOBJ['query']['vp_qcrid'];
                $I['yt_wlulng'] = $this->COLOBJ['query']['vp_wlulng'];
                $I['yt_creator'] = $this->COLOBJ['query']['vp_querycreator'];
                $I['yt_videotags'] = explode(';', $I['yt_videotags']);
                $I['yt_videotags'] = $this->get_part_of_array($I['yt_videotags'], 1, $this->gbl_config['wlu_vp_tagcut']);
                $I['yt_videotags'] = implode(';', $I['yt_videotags']);
                $I['yt_qid'] = $_POST['id'];
                foreach ($I as $key => $wert)
                    $I[$key] = mysql_real_escape_string($I[$key]);
                insertTable(TBL_CMS_WLU_APPROVED_VIDEOS, $I);
                $this->db->query("UPDATE " . TBL_CMS_WLU_VIDEO_TO_QUERY . " SET yq_approved=1 WHERE vq_queryid=" . $I['yt_qid'] . " AND vq_videoid='" . $id . "'");
                $this->add_video_to_catmatrix($id);
                $country_matrix = $this->set_video_country_matrix($I);
                $this->update_location_counts();
                #	}
                $keywords = explode(';', $I['yt_videotags']);
                $SW->add_words($keywords, $country_matrix, $id);
                $this->VPLOG->vp_addlog('approve VP video [' . $id . ']: ' . $I['yt_videotitle'], 'VP_VIDEO_APPROVE');
            }
            $this->update_cat_count_by_query($query_id);
        }
        unset($SW);
    }

    function cmd_vp_vapprove() {
        $this->approve_videos_by_query($_POST['VIDEOIDS'], $_POST['id']);
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'qrun');
        $this->TCR->reset_cmd('showresult');
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function cmd_vp_clear_stock() {
        $this->clear_stock();
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'videoman');
        $this->TCR->reset_cmd('list');
        $this->TCR->add_msg('{LBL_SAVED}');
    }


    function add_tree_selectboxes($cid_array, $okey = 'query', $country_id = 0) {
        $country_id = (int)$country_id;
        $this->COLOBJ[$okey]['cat_selectboxes'] = array();
        $menutree = new nestedArrClass();
        $menutree->init(array('label_column' => 'ytc_name', 'label_parent' => 'ytc_parent', 'label_id' => 'id', 'sign' => '|_'));
        $menutree->CreateResult("SELECT * FROM " . TBL_CMS_WLU_CATS . " ORDER BY ytc_parent,ytc_name", 0, 0, -1);
        if ($country_id == 0) {
            $this->remove_cats_by_country_relationship($menutree);
        }
        else {
            $this->remove_countries_by_list(&$menutree, array($country_id));
        }
        $k = 0;
        if (is_array($cid_array)) {
            foreach ($cid_array as $key => $cid) {
                $k++;
                if ($k > 1) {
                    $this->COLOBJ[$okey]['cat_selectboxes'][$k] = $menutree->output_as_selectbox((int)$cid, 0, array('key' => 0, 'value' => '- NONE -'));
                }
                else {
                    $this->COLOBJ[$okey]['cat_selectboxes'][$k] = $menutree->output_as_selectbox((int)$cid, 0);
                }
            }
        }
        $diff = 3 - $k;
        if ($diff > 0) {
            for ($i = 1; $i <= $diff; $i++) {
                if ($diff == 3 && $i == 1) {
                    $this->COLOBJ[$okey]['cat_selectboxes'][] = $menutree->output_as_selectbox(0, 0, array());
                }
                else {
                    $this->COLOBJ[$okey]['cat_selectboxes'][] = $menutree->output_as_selectbox(0, 0, array('key' => 0, 'value' => '- NONE -'));
                }
            }
        }

        unset($menutree);
    }

    function cmd_yt_query_edit() {
        $this->load_query($_GET['id']);
    }

    function load_video_pathes($countryid = 0, $videoid = '') {
        $sql = "SELECT *,C.id AS CID
	FROM " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VCATMATRIX . " VCAT, " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " CM, " . TBL_CMS_WLU_APPROVED_VIDEOS . " V
	WHERE C.id=VCAT.vcm_cid
	AND CM.vc_videoid=VCAT.vcm_videoid
	AND VCAT.vcm_videoid=V.yt_videoid
	" . (($countryid > 0) ? " AND CM.vc_countryid=" . (int)$countryid : "") . "
	" . (($videoid != "") ? " AND V.yt_videoid='" . $videoid . "'" : "") . "
	" . (($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 1) ? "" : " AND V.yt_creatorid=" . $this->EMPLOYEE['MID']) . "
	GROUP BY C.id
	ORDER BY C.ytc_path";
        $result = $this->db->query($sql);
        #	echo $sql;die;
        while ($row = $this->db->fetch_array_names($result)) {
            $pathes[$row['vcm_videoid']][] = $row['ytc_path'];
        }
        return $pathes;
    }

    function load_video_srcs() {
        $result = $this->db->query("SELECT yt_stock FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE 1 GROUP BY yt_stock");
        while ($row = $this->db->fetch_array_names($result)) {
            $this->COLOBJ['stock_list'][] = $row;
        }
    }

    function request_videos_from_db($QFILTER, $childs, &$videos, $c_sql, $start = 0, $limit = 50, $orderby, $direc) {
        if ($QFILTER['countryid'] == ALLCOUNTRYID || $QFILTER['countryid'] == 0) {
            $sqladd = " FROM " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VCATMATRIX . " VCAT,	 
	 " . TBL_CMS_WLU_APPROVED_VIDEOS . " V 
	 WHERE
		" . (($QFILTER['yt_stock'] != "") ? "V.yt_stock='" . $QFILTER['yt_stock'] . "' AND " : "") . "
	C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	" . (($childs['sql_cid_filter'] != "") ? " AND (" . $childs['sql_cid_filter'] . ")" : '') . "
	 " . ((is_array($QFILTER) && $QFILTER['queryid'] > 0) ? " AND Q.id='" . $QFILTER['queryid'] . "'" : "") . ((is_array($QFILTER) && $QFILTER['yt_blocked'] > 0) ?
                " AND V.yt_blocked=1" : " AND V.yt_blocked=0") . ((!empty($QFILTER['searchword'])) ? " AND (LOWER(V.yt_videotitle) LIKE LOWER('%" . trim($QFILTER['searchword']) .
                "%') OR LOWER(V.yt_videotags) LIKE LOWER('%" . trim($QFILTER['searchword']) . "%'))" : "");
        }
        else {
            $sqladd = " FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VCATMATRIX . " VCAT,
	 " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L
	WHERE 
	VC.vc_videoid=V.yt_videoid 
	AND VC.vc_countryid=L.id
	" . (($QFILTER['yt_stock'] != "") ? " AND V.yt_stock='" . $QFILTER['yt_stock'] . "'" : "") . "
	AND C.id=VCAT.vcm_cid
	AND V.yt_videoid=VCAT.vcm_videoid
	" . (($childs['sql_cid_filter'] != "") ? " AND (" . $childs['sql_cid_filter'] . ")" : '') . "
	 " . (($QFILTER['countryid'] != ALLCOUNTRYID) ? " AND VC.vc_countryid=" . $QFILTER['countryid'] : $c_sql) . (($QFILTER['queryid'] > 0) ? " AND Q.id='" . $QFILTER['queryid'] .
                "'" : "") . (($QFILTER['yt_blocked'] > 0) ? " AND V.yt_blocked=1" : " AND V.yt_blocked=0") . ((!empty($QFILTER['searchword'])) ?
                " AND LOWER(V.yt_videotitle) LIKE LOWER('%" . trim($QFILTER['searchword']) . "%') " : "");
        }


        #ORDER BY ".$orderby." ".$direc."
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID " . $sqladd . "
	GROUP BY V.yt_videoid
	ORDER BY " . $orderby . " " . $direc . " 
	LIMIT " . (int)$start . "," . (int)$limit;
        #	echo $sql;
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $row['lastexec_datetime'] = ($row['yp_lastexec'] > 0) ? date('d.m.Y H:i:s', $row['yp_lastexec']) : '-';
            $row['approved_date'] = ($row['yt_apptime'] > 0) ? date('d.m.Y H:i:s', $row['yt_apptime']) : '-';
            if ($QFILTER['countryid'] == ALLCOUNTRYID) {
                // bestimme Land
                if (getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, 'vc_videoid', "vc_countryid=" . ALLCOUNTRYID . " AND vc_videoid='" . $row['yt_videoid'] . "'") == 1) {
                    $row['land'] = '{LA_ALLCOUNTRIES}';
                }
                else
                    if (getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, 'vc_videoid', "vc_videoid='" . $row['yt_videoid'] . "'") == 1) {
                        $COUNTRY = $this->db->query_first("SELECT L.* FROM  " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND .
                            " L WHERE VC.vc_countryid=L.id AND VC.vc_videoid='" . $row['yt_videoid'] . "'");
                        $row['land'] = $COUNTRY['land'];
                    }
                    else {
                        $row['land'] = 'some countries';
                    }

            }
            $videos[$row['VID']] = $row;
        }
        #echoarr($videos);
        $C = $this->db->query("SELECT COUNT(V.yt_videoid) AS VCOUNT " . $sqladd . " GROUP BY V.yt_videoid");
        return (int)$this->db->num_rows($C);
    }


    function load_all_queries() {
        $QFILTER = $_REQUEST['QFILTER'];
        if (is_array($QFILTER)) {
            $_SESSION['QFILTER'] = $QFILTER;
        }
        else {
            $QFILTER = $_SESSION['QFILTER'];
        }
        $this->COLOBJ['queries_loaded'] = false;
        if (is_array($QFILTER)) {
            $this->COLOBJ['queries_loaded'] = true;
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE 1");
            while ($row = $this->db->fetch_array_names($result)) {
                $country_index[$row['id']] = $row['land'];
            }
            if ($QFILTER['vp_countryid'] == ALLCOUNTRYID && is_array($this->EMPLOYEE['responsible_countries_ids'])) {
                $c_sql = " AND (Q.vp_countryid=" . ALLCOUNTRYID . " OR Q.vp_countryid IN (" . implode(',', $this->EMPLOYEE['responsible_countries_ids']) . ")) ";
            }
            $queries = array();
            $sql = "SELECT *,Q.id AS QID,C.id AS CID 
		FROM " . TBL_CMS_WLU_VPQUERY . " Q, " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_QUERY_TO_CAT . " M
		WHERE M.qc_cid=C.id
		AND M.qc_qid=Q.id
		AND Q.vp_approval=1 " . ((is_array($QFILTER) && $QFILTER['vp_countryid'] != ALLCOUNTRYID && $QFILTER['vp_countryid'] != 0) ? " AND Q.vp_countryid=" . $QFILTER['vp_countryid'] :
                $c_sql) . "
		" . (($QFILTER['vp_stock'] != "") ? " AND Q.vp_stock='" . $QFILTER['vp_stock'] . "'" : "") . (($QFILTER['word'] != "") ?
                " AND (LOWER(Q.vp_queryname) LIKE LOWER('%" . trim($QFILTER['word']) . "%') 
			 OR LOWER(Q.vp_author) LIKE LOWER('%" . trim($QFILTER['word']) . "%') 
			)" : "") . (($QFILTER['cid'] > 0) ? " AND C.id='" . $QFILTER['cid'] . "'" : "") . "
		GROUP BY QID
		ORDER BY Q.vp_queryname ASC";
            #.	(($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster']==1) ? "" : " AND Q.vp_qcrid=".$this->EMPLOYEE['MID'])

            $result = $this->db->query($sql);
            while ($row = $this->db->fetch_array_names($result)) {
                $this->QUERY->set_query_options($row);
                $row['country_name'] = ($row['vp_countryid'] == ALLCOUNTRYID) ? 'All countries' : $country_index[$row['vp_countryid']];
                $queries[$row['QID']] = $row;
                $pathes[$row['QID']][] = $row['ytc_path'];
            }
            foreach ($queries as $key => $row) {
                $queries[$key]['pathes'] = $pathes[$key];
            }
            //sorting
            $column = ($_GET['col'] == "") ? 'vp_queryname' : strval(trim($_GET['col']));
            $direc = ($_GET['direc'] == 'DESC') ? 'SORT_DESC' : 'SORT_ASC';
            $sorttype = ($_GET['sorttype'] == 'NUM') ? 'SORT_NUMERIC' : 'SORT_STRING';
            $queries = sortDbResult($queries, $column, constant($direc), constant($sorttype));
            $direc = ($_GET['direc'] == 'ASC') ? 'DESC' : 'ASC';
        }
        $this->smarty->assign('FILTER', array('direc' => $direc));
        $this->smarty->assign('QFILTER', $QFILTER);
        $this->COLOBJ['all_queries'] = $queries;
    }

    function load_result($id, $start) {
        $start = (int)$start;
        $id = (int)$id;
        $start = ($start == 0) ? 0 : $start;
        $vresult = array();
        $this->TCR->GET['order'] = ($this->TCR->GET['order'] == "") ? 'M.order' : $this->TCR->GET['order'];
        $order = (strstr($this->TCR->GET['order'], 'VP.')) ? str_replace('VP.', 'VP.yt_', $this->TCR->GET['order']) : str_replace('M.', 'M.vq_', $this->TCR->GET['order']);
        $direc = ($this->TCR->GET['direc'] == "") ? 'ASC' : $this->TCR->GET['direc'];
        $sql = "SELECT * FROM " . TBL_CMS_WLU_VP . " VP, " . TBL_CMS_WLU_VIDEO_TO_QUERY . " M
	WHERE M.vq_videoid=VP.yt_videoid 
	AND M.vq_queryid=" . $id . " 
	AND M.yq_approved=0
	ORDER BY " . $order . " " . $direc . "
	LIMIT " . $start . "," . $this->max_per_page;
        $result = $this->db->query($sql);
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $row['approved_video_count'] = getCount(TBL_CMS_WLU_APPROVED_VIDEOS, 'yt_videoid', "yt_videoid='" . $row['yt_videoid'] . "'");
            $vresult[] = $row;
        }
        $this->COLOBJ['video_sorting']['direc'] = ($direc == 'ASC') ? 'DESC' : 'ASC';
        $this->COLOBJ['video_list'] = $vresult;
        $this->COLOBJ['video_totalcount'] = getCount(TBL_CMS_WLU_VIDEO_TO_QUERY, 'vq_queryid', "yq_approved=0 AND vq_queryid=" . $id);
        $this->genPaging($this->COLOBJ['video_totalcount'], $start, array('order' => $this->TCR->GET['order'], 'direc' => $this->TCR->GET['direc']));
    }


    function cmd_query_runfinished() {
        $smarty = $this->smarty;
        include (CMS_ROOT . 'admin/inc/smarty.inc.php');
        $this->parse_to_smarty();
        $content = '<% include file="wlu_yt_qrun.tpl" %>';

        if ($this->TCR->GET['return'] == 1) {
            header('location: ' . $_SERVER['PHP_SELF'] . '?epage=' . $this->TCR->GET['epage'] . '&section=qrun&aktion=list&msg=' . base64_encode('{LBL_SAVE}'));
            exit;
        }
        else {
            ECHORESULT(translateAdmin(smarty_compile($content)));
        }

    }

    function cmd_query_run() {
        $this->load_query($_REQUEST['id']);
        if ($_REQUEST['YTOPTIONS']['startIndex'] <= 1) {
            $this->YTV->YT['FORM'] = $_REQUEST['YTOPTIONS'] = $this->COLOBJ['query']['qobj'];
            $SU = array('yp_lastexec' => time(), 'vp_lr_empname' => mysql_real_escape_string($this->EMPLOYEE['mitarbeiter_name']), 'vp_lr_empdi' => $this->EMPLOYEE['MID']);
            updateTable(TBL_CMS_WLU_VPQUERY, 'id', $_REQUEST['id'], $SU);
            $this->VPLOG->vp_addlog('run query [' . $_REQUEST['id'] . ']: ' . $this->COLOBJ['query']['vp_queryname'], 'QUERY_RUN');
        }
        if ($this->COLOBJ['query']['vp_stock'] == 'YT') {
            if ($_REQUEST['YTOPTIONS']['startIndex'] < 1000)
                $RET = $this->YTV->sync($_REQUEST['YTOPTIONS'], $_REQUEST['id']);
        }
        if ($this->COLOBJ['query']['vp_stock'] == 'VI') {
            if ($_REQUEST['YTOPTIONS']['startIndex'] < 1000)
                $RET = $this->VI->sync($_REQUEST['YTOPTIONS'], $this->COLOBJ['query']);
        }
        if ($RET['TotalResults'] - $RET['FORM']['YTOPTIONS']['startIndex'] > 0 && $RET['FORM']['YTOPTIONS']['startIndex'] < 1000 && $RET['FORM']['YTOPTIONS']['startIndex'] <=
            $_REQUEST['YTOPTIONS']['maxTotalLimit']) {
            $url = $_SERVER['PHP_SELF'] . "?return=" . $this->TCR->GET['return'] . "&epage=" . $_REQUEST['epage'] . "&id=" . $_REQUEST['id'] . "&section=qrun&cmd=" . $_REQUEST['cmd'] .
                '&' . http_build_query($RET['FORM']);
            $smarty = $this->smarty;
            include (CMS_ROOT . 'admin/inc/smarty.inc.php');
            HEADER("Refresh: 1;  URL=" . $url);
            $this->COLOBJ['sync_status'] = $RET;
            $this->parse_to_smarty();
            $content = '<% include file="wlu_yt_qrun.tpl" %>';
            ECHORESULT(translateAdmin(smarty_compile($content)));
            die;
        }
        else {
            $c = getCount(TBL_CMS_WLU_VIDEO_TO_QUERY, '*', "vq_queryid=" . (int)$_REQUEST['id']);
            $this->db->query("UPDATE " . TBL_CMS_WLU_VPQUERY . " SET vp_vidcount=" . (int)$c . " WHERE id=" . (int)$_REQUEST['id']);
            header('location:' . $_SERVER['PHP_SELF'] . '?return=' . $this->TCR->GET['return'] . '&epage=' . $_REQUEST['epage'] . '&section=qrun&cmd=query_runfinished');
        }
        exit;
    }

    function validate_video_list($video_ids, $FORM = array()) {
        $k = 0;
        if (is_array($video_ids)) {
            foreach ($video_ids as $id) {
                $sql .= (($sql != "") ? " OR " : "") . " yt_videoid='" . $id . "'";
            }
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE " . $sql);
            while ($row = $this->db->fetch_array_names($result)) {
                if ($row['yt_stock'] == 'YT')
                    $http_code = $this->getHttpCode('http://gdata.youtube.com/feeds/api/videos/' . $row['yt_videoid']);
                if ($row['yt_stock'] == 'AH')
                    $http_code = $this->getHttpCode($row['yt_videourl']);
                if ($row['yt_stock'] == 'VI')
                    $http_code = $this->VI->validate_video($row['yt_videoid']);
                if ($http_code != 200) {
                    $this->move_to_exception($row['yt_videoid'], $FORM);
                    $k++;
                }
                else {
                    $this->remove_to_exception($row['yt_videoid'], $FORM);
                }
            }
        }
        return $k;
    }

    function cmd_vp_clean_videos() {
        $count = $this->validate_video_list($_POST['VIDEOIDS'], $_POST['FORM']);
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'videoman');
        $this->TCR->reset_cmd('list');
        $this->TCR->add_msg('{LBL_SAVED}. ' . (int)$count . ' videos move to exception.');
    }

    function cmd_vp_validateandremove() {
        $count = $this->validate_videos_delete($_POST['VIDEOIDS']);
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'videoman');
        $this->TCR->reset_cmd('list');
        $this->TCR->add_msg('{LBL_SAVED}. ' . (int)$count . ' videos deleted.');
    }

    function validate_videos_delete($video_ids) {
        $k = 0;
        if (is_array($video_ids)) {
            foreach ($video_ids as $id) {
                $sql .= (($sql != "") ? " OR " : "") . " yt_videoid='" . $id . "'";
            }
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE " . $sql);
            while ($row = $this->db->fetch_array_names($result)) {
                if ($row['yt_stock'] == 'YT')
                    $http_code = $this->getHttpCode('http://gdata.youtube.com/feeds/api/videos/' . $row['yt_videoid']);
                if ($row['yt_stock'] == 'AH')
                    $http_code = $this->getHttpCode($row['yt_videourl']);
                if ($row['yt_stock'] == 'VI')
                    $http_code = $this->VI->validate_video($row['yt_videoid']);
                if ($http_code != 200) {
                    $this->delete_video($row['yt_videoid']);
                    $k++;
                }
                else {

                }
            }
        }
        return $k;
    }


    function cmd_vp_movetoexception() {
        if (is_array($_POST['VIDEOIDS'])) {
            foreach ($_POST['VIDEOIDS'] as $video_id) {
                $this->move_to_exception($video_id, $_POST['FORM']);
                $this->update_cat_counts_by_video($video_id, false);
            }
        }
        $this->update_location_counts();
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'videoman');
        $this->TCR->reset_cmd('list');
        $this->TCR->add_msg('{LBL_SAVED}');
    }


    function cmd_vp_moveback() {
        if (is_array($_POST['VIDEOIDS'])) {
            foreach ($_POST['VIDEOIDS'] as $video_id) {
                $this->remove_to_exception($video_id, $_POST['FORM']);
                $this->update_cat_counts_by_video($video_id, false);
            }
        }
        $this->update_location_counts();
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'videoman');
        $this->TCR->reset_cmd('list');
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function get_video_name($id) {
        $R = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_VP . " WHERE yt_videoid='" . $id . "'");
        return $R['yt_videotitle'];
    }

    function cmd_vp_delete_videos() {
        $_SESSION['QFILTER'] = $_POST['QFILTER'];
        if (is_array($_POST['VIDEOIDS'])) {
            foreach ($_POST['VIDEOIDS'] as $video_id) {
                $this->delete_video($video_id);
                $this->VPLOG->vp_addlog('delete VP video [' . $video_id . ']: ' . $this->get_video_name($video_id), 'VP_VIDEO_DELETE');
            }
        }
        $this->TCR->set_url_tags(array('start', 'id'));
        $this->TCR->add_url_tag('section', 'videoman');
        $this->TCR->add_url_tag('QFILTER', array('QFILTER' => $_POST['QFILTER']));
        $this->TCR->reset_cmd('list');
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function cmd_vp_clean() {
        $start = (int)$_REQUEST['start'];
        $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE 1 LIMIT " . $start . ",50");
        if ($this->db->num_rows($result) > 0) {
            while ($row = $this->db->fetch_array_names($result)) {
                $V = $this->get_single_video($row['yt_videoid']);
                if ($V['yt_videoid'] != $row['yt_videoid']) {
                    $this->delete_video($row['yt_videoid']);
                }
            }
            $url = $_SERVER['PHP_SELF'] . "?epage=" . $_REQUEST['epage'] . "&section=vptask&cmd=" . $_REQUEST['cmd'] . '&start=' . ($start + 50);
            HEADER("Refresh: 1;  URL=" . $url);
        }
        else {
            $this->TCR->add_url_tag('section', 'vptask');
            $this->TCR->add_msg('{LBL_SAVED}');
        }
        exit;
    }

    function load_videomixer_countries($country_ids) {
        $countries = array();
        if (is_array($country_ids)) {
            foreach ($country_ids as $key => $id) {
                $sql .= (($sql != "") ? " OR " : "") . "id=" . (int)$id;
            }
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " WHERE 1 AND (" . $sql . ") ORDER BY land");
            while ($row = $this->db->fetch_array_names($result)) {
                $countries[] = $row;
            }
        }
        $this->COLOBJ['employee_countries'] = $countries;
    }

    function load_adhoc_video($id) {
        $this->COLOBJ['adhocvideo'] = $this->ADHOCV->load_adhoc_video($id);
    }

    function init_aws() {
        $this->s3->get_bucket_list();
        #$this->load_iso_table();
        #echoarr($this->s3->S3O);
    }

    function cmd_ax_get_cat_boxes_adhoc() {
        $id = $_POST['id'];
        $this->load_adhoc_video($id);
        $FORM['yt_adhoc_countryid'] = (int)$_POST['countryid'];
        if ($id != "") {
            updateTable(TBL_CMS_WLU_APPROVED_VIDEOS, 'yt_videoid', $id, $FORM);
            if ($this->ADHOCVIDEO['yt_adhoc_countryid'] != $FORM['vp_countryid']) {

            }
            $this->load_adhoc_video($id);
        }
        $this->add_tree_selectboxes($this->COLOBJ['adhocvideo']['assigned_cat_ids'], 'adhocvideo', (int)$_POST['countryid']);
        $content = '
	<div><input type="hidden" name="FORM[yt_adhoc_countryid]" value="' . (int)$_POST['countryid'] . '">
	<table border="0" width="100%">
	<% if ($COLOBJ.adhocvideo.land!="") %>
	<tr>
     <td>Assigned country:</td> 
     <td><% $COLOBJ.adhocvideo.land %></td>
     </tr> 
     <%/if%>
	<% foreach from=$COLOBJ.adhocvideo.cat_selectboxes key=qc item=catselectbox %>
	<tr>
	<td>{LA_PLEASESELECTCATEGORY} (<%$qc%>):</td>
	<td><select name="CIDS[]">
	<% $catselectbox %>
	</select>
	</td>
	</tr>
	<%/foreach%>
	</table></div>';
        $this->parse_to_smarty();
        ECHORESULTCOMPILED($content);
    }

    function cmd_ah_video_edit() {
        $this->load_adhoc_video($this->TCR->GET['id']);
    }

    function cmd_ah_save_video() {
        $this->TCR->add_url_tag('section', 'adhocvideo');
        $this->TCR->add_url_tag('type', $this->TCR->REQUEST['type']);
        $this->TCR->reset_cmd('ah_video_edit');
        $FORM = $this->TCR->POST['FORM'];
        $thumb_valid = true;
        if ($_FILES['thumbfile']['name'] != "") {
            $thumb_valid = validateUploadFile($_FILES['thumbfile']);
            if ($thumb_valid == false)
                $FORM['thumbfile'] = $thumb_valid;
        }
        if ($FORM['yt_embvideotitle'] == "" || $FORM['yt_videotitle'] == "" || $FORM['yt_videosrcname'] == "" || $FORM['yt_lastupdate'] == "" || $FORM['yt_author_username'] ==
            "" || $FORM['yt_watchpageurl'] == "" || $FORM['yt_videourl'] == "" || $thumb_valid == False) {
            $this->load_adhoc_video($this->TCR->REQUEST['id']);
            $this->COLOBJ['adhocvideo'] = array_merge($this->COLOBJ['adhocvideo'], $FORM);
            $this->COLOBJ['fault_form'] = TRUE;
            $this->TCR->set_fault_form(true);
        }
        else {
            $id = $this->ADHOCV->save_video($_POST['id'], $FORM, $_POST['CIDS'], $_FILES);
            $this->TCR->add_url_tag('id', $id);
            $this->TCR->add_msg('{LBL_SAVED}');
        }
    }

    function gen_entry_point_list() {

    }


    function cmd_load_comments() {
        $this->COMMENTS->load_comments($this->TCR->REQUEST['vid']);
    }

    function cmd_delete_comment() {
        $this->COMMENTS->cmd_delete_comment();
        $this->TCR->set_just_turn_back(true);
        $this->TCR->add_msg('{LBL_DELETED}');
    }

    function cmd_update_comment_count() { // NONE PUBLIC
        $sql = "SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . "	WHERE 1";
        $result = $this->db->query($sql);
        $C = new wlu_comments_class();
        while ($row = $this->db->fetch_array_names($result)) {
            $C->update_comment_count($row['yt_videoid']);
        }
        unset($C);
    }

    function set_report_filter() {
        $this->COLOBJ['reports']['filter'] = $this->TCR->REQUEST['QFILTER'];
        $FirstDay = mktime(0, 0, 0, date('m'), 1, date('Y'));
        $lastDay = idate('d', mktime(0, 0, 0, (date('m') + 1), 0, date('Y')));
        if ($this->COLOBJ['reports']['filter']['r_from'] == "" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
            $this->COLOBJ['reports']['filter']['r_from'] = date('d.m.Y', $FirstDay);
        }
        if ($this->COLOBJ['reports']['filter']['r_to'] == "" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
            $this->COLOBJ['reports']['filter']['r_to'] = $lastDay . date('.m.Y');
        }

        if ($this->COLOBJ['reports']['filter']['qr_from'] == "" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
            $this->COLOBJ['reports']['filter']['qr_from'] = date('d.m.Y', $FirstDay);
        }
        if ($this->COLOBJ['reports']['filter']['qr_to'] == "" && !is_array($this->TCR->REQUEST['QFILTER']) && !isset($_GET['start'])) {
            $this->COLOBJ['reports']['filter']['qr_to'] = $lastDay . date('.m.Y');
        }

        $E = new wlu_employee_class();
        $E->load_employees();
        $this->COLOBJ['employees'] = $E->employees;
        unset($E);
        $this->COLOBJ['reports']['csv_exists'] = file_exists(CMS_ROOT . 'admin/cache/' . $this->TCR->REQUEST['setcmd'] . '.xls');
    }

    function load_videos_by_cat($cid, $start) {
        $cid = (int)$cid;
        $QFILTER = $_REQUEST['QFILTER'];
        $start = (int)$start;
        $videos = $videos_query = $videos_adhoc = array();
        $c_sql = "";
        if (is_array($_REQUEST['QFILTER'])) {
            $_SESSION['QFILTER'] = $_REQUEST['QFILTER'];
        }
        else {
            $QFILTER = $_SESSION['QFILTER'];
        }

        if ($QFILTER['countryid'] == 0 && is_array($this->EMPLOYEE['responsible_countries_ids'])) {
            if (count($this->EMPLOYEE['responsible_countries_ids']) > 0)
                $c_sql = " AND (VC.vc_countryid=" . ALLCOUNTRYID . " OR VC.vc_countryid IN (" . implode(',', $this->EMPLOYEE['responsible_countries_ids']) . ")) ";
        }

        if ($cid > 0) {
            $childs = $this->build_flatarr_of_children($cid);
            // Validate Access
            if ($this->EMPLOYEE['PERM']->perm['wlu_vp_isvideomaster'] == 0) {
                $country_ids = array();
                $result = $this->db->query("SELECT * FROM " . TBL_CMS_WLU_COUNTRY_TO_CAT . " WHERE cm_cid=" . $cid);
                while ($row = $this->db->fetch_array_names($result)) {
                    $country_ids[] = $row['cm_countryid'];
                }
                $schnittmenge = array_intersect($this->EMPLOYEE['responsible_countries_ids'], $country_ids);
                if (count($schnittmenge) == 0) {
                    $this->TCR->reset_cmd('list');
                    $this->TCR->add_url_tag('section', 'videoman');
                    $this->TCR->add_msge('{LBL_NOACCESS}');
                    return;
                }
            }
        }
        $videos = array();
        $orderby = strval($_GET['col']);
        $orderby = ($orderby == "") ? "yt_lastupdate" : $orderby;
        $orderby = 'V.' . $orderby;
        $direc = ($_GET['direc'] == 'ASC') ? 'ASC' : 'DESC';
        $video_filtered_count = (int)$this->request_videos_from_db($QFILTER, $childs, $videos, $c_sql, $start, 50, $orderby, $direc);

        if (count($videos) > 0) {
            // Queries ermitteln
            $sql_addon = "";
            foreach ($videos as $key => $row) {
                $sql_addon .= (($sql_addon != "") ? " OR " : "") . "vq_videoid='" . $row['yt_videoid'] . "'";
            }
            if (!empty($sql_addon)) {
                $queries = array();
                $result = $this->db->query("SELECT *,Q.id AS QID FROM " . TBL_CMS_WLU_VIDEO_TO_QUERY . " M, " . TBL_CMS_WLU_VPQUERY . " Q 
			WHERE Q.id=M.vq_queryid AND (" . $sql_addon . ")");
                while ($row = $this->db->fetch_array_names($result)) {
                    $queries[$row['vq_videoid']] = $row;
                }
            }
            //adding pathes & queries
            $pathes_by_videos = $this->load_video_pathes((int)$QFILTER['countryid']);
            foreach ($videos as $key => $V) {
                if (is_array($pathes_by_videos[$V['VID']]))
                    $videos[$key]['pathes'] = $pathes_by_videos[$V['VID']];
                $videos[$key]['query'] = array();
                if (is_array($queries[$V['yt_videoid']])) {
                    $this->QUERY->set_query_options($queries[$V['VID']]);
                    $videos[$key]['query'] = $queries[$V['VID']];
                }
            }
        }

        // Total Video Count by responsible countries
        $VC = $this->db->query_first("SELECT COUNT(*) AS VCOUNT FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " V,
		" . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L
		WHERE " . ((is_array($QFILTER) && $QFILTER['yt_blocked'] > 0) ? " V.yt_blocked=1" : " V.yt_blocked=0") . "
		AND VC.vc_videoid=V.yt_videoid
		AND VC.vc_countryid=L.id " . $c_sql);
        // Count of videos having countryid=0 / related to all countries
        /* OLD COUNTING
        $sql="SELECT W.yt_videoid,COUNT(vc_videoid) WCOUNT 
        FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " W  
        LEFT JOIN " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " R ON (R.vc_videoid=W.yt_videoid)
        WHERE 1
        GROUP BY W.yt_videoid
        HAVING COUNT(vc_videoid)=0";
        $result = $this->db->query($sql);        
        $video_count_all_countries = $this->db->num_rows($result);
        */
        $video_count_all_countries = getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, "vc_videoid", "vc_countryid=" . ALLCOUNTRYID);
        $VC['VCOUNT'] += $video_count_all_countries;

        //sorting
        $direc = ($_GET['direc'] == 'ASC') ? 'SORT_ASC' : 'SORT_DESC';
        $sorttype = ($_GET['sorttype'] == 'NUM') ? 'SORT_NUMERIC' : 'SORT_STRING';
        #if (count($videos) > 0) $videos 	= sortDbResult($videos, strval($_GET['col']), constant($direc), constant($sorttype));
        $direc = ($_GET['direc'] == 'ASC') ? 'DESC' : 'ASC';
        $this->smarty->assign('FILTER', array('direc' => $direc));
        $this->smarty->assign('QFILTER', $QFILTER);
        $this->smarty->assign('qfilter_query', http_build_query(array('QFILTER' => $QFILTER)));
        #echoarr($videos);
        $this->COLOBJ['video_list'] = $videos;
        $this->COLOBJ['video_filtered_count'] = $video_filtered_count;
        $this->COLOBJ['video_totalcount'] = $VC['VCOUNT'];
        $this->COLOBJ['video_count_all_countries'] = $video_count_all_countries;
        $this->genPaging($this->COLOBJ['video_filtered_count'], $start);
    }


    function build_grandview_sql($QFILTER) {
        $sql_add = " FROM " . TBL_CMS_WLU_CATS . " C, " . TBL_CMS_WLU_VCATMATRIX . " VCAT,
	" . TBL_CMS_WLU_APPROVED_VIDEOS . " V, " . TBL_CMS_WLU_VIDEO_TO_QUERY . " VQM, " . TBL_CMS_WLU_VPQUERY . " Q
	" . (($QFILTER['countryid'] > 0) ? "," . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND . " L" : '') . "

	WHERE C.id=VCAT.vcm_cid
	" . (($QFILTER['countryid'] > 0) ? " AND VC.vc_videoid=V.yt_videoid AND VC.vc_countryid=L.id " : "") . "
	AND VQM.vq_videoid=V.yt_videoid
	AND VQM.vq_queryid=Q.id
	AND V.yt_videoid=VCAT.vcm_videoid
	AND V.yt_blocked=0
	" . (($QFILTER['r_from'] != "") ? "AND V.yt_apptime>=" . strtotime($QFILTER['r_from']) : "") . "
	" . (($QFILTER['r_to'] != "") ? "AND V.yt_apptime<=" . strtotime($QFILTER['r_to']) : "") . "
	" . (($QFILTER['qr_from'] != "") ? "AND Q.yp_lastexec>=" . strtotime($QFILTER['qr_from']) : "") . "
	" . (($QFILTER['qr_to'] != "") ? "AND Q.yp_lastexec<=" . strtotime($QFILTER['qr_to']) : "") . "
	" . (($QFILTER['countryid'] > 0) ? "AND VC.vc_countryid='" . $QFILTER['countryid'] . "'" : '') . "
	" . (($QFILTER['creator'] > 0) ? "AND Q.vp_qcrid=" . (int)$QFILTER['creator'] : '') . "
	" . (($QFILTER['lastrunby'] > 0) ? "AND Q.vp_lr_empdi=" . (int)$QFILTER['lastrunby'] : '') . "
	";
        return $sql_add;
    }


    function create_regdb_xls($QFILTER, $start = -1) {
        $trenner = "\t";
        $start = (int)$start;
        $fields = array(array('label' => 'Userid', 'sql' => 'wlu_userid'), array('label' => 'Registration Date', 'sql' => 'datum'), array('label' => 'Last Login Date',
            'sql' => 'lastvisit'), array('label' => 'First Name', 'sql' => 'vorname'), array('label' => 'Lastname', 'sql' => 'nachname'), array('label' => 'Gender', 'sql' =>
            'geschlecht'), array('label' => 'Email', 'sql' => 'email'), array('label' => 'Country of Residence', 'sql' => 'land'), array('label' => 'Preferred Destination',
            'sql' => 'PREFDEST'), array('label' => 'Preferred Language', 'sql' => 'post_lang'), array('label' => 'Newsletter', 'sql' => 'mailactive'));

        $fname = CMS_ROOT . 'admin/cache/rp_regdatabase.xls';

        if ($start <= 0) {
            if (file_exists($fname))
                @unlink($fname);
        }

        $fp = fopen($fname, 'a');
        if ($start <= 0) {
            foreach ($fields as $ar)
                $f[] = $ar['label'];
            fputcsv($fp, $f, $trenner, '"');
        }

        $sql = "SELECT K.*,L.land,LL.land AS PREFDEST,LNG.post_lang FROM " . TBL_CMS_LAND . " L, " . TBL_CMS_LANG . " LNG
        ," . TBL_CMS_CUST . " K JOIN " . TBL_CMS_LAND . " LL ON (K.land_destination=LL.id) 
                WHERE K.land=L.id AND LNG.id=preferred_lang
				ORDER BY nachname ASC	
				LIMIT " . (int)$start . ",100";
        $result = $this->db->query($sql);
        #	echo $sql;
        $pcount = 0;
        while ($row = $this->db->fetch_array_names($result)) {
            $row['datum_ger'] = myDate('d.m.Y', $row['datum']);
            $row['lastvisit'] = date('d.m.Y', strtotime($row['lastvisit']));
            $f = array();
            foreach ($fields as $ar) {
                $value = utf8_decode($this->xml_xls_formated(strval($row[$ar['sql']])));
                if (strtotime($value) && strlen($value) == 10)
                    $f[] = date('d.m.Y', strtotime($value));
                else
                    $f[] = $value;
            }
            fputcsv($fp, $f, $trenner, '"');
            $pcount++;
        }
        fclose($fp);
        return $pcount;
    }

    function cmd_create_xls_regdb() {
        global $content, $db_zugriff, $smarty, $crj_obj;
        if ($_REQUEST['start'] == 0) {
            $_SESSION['STATUSBAR']['starttime'] = time();
            $_SESSION['STATUSBAR']['rounds'] = 0;
        }
        $_SESSION['STATUSBAR']['rounds']++;
        $QFILTER = $this->TCR->REQUEST['QFILTER'];
        $pcount = $this->create_regdb_xls($QFILTER, $_REQUEST['start']);
        if ($pcount > 0) {
            $_REQUEST['start'] += 100;
            $VC = $this->db->query_first("SELECT COUNT(*) as VCOUNT FROM " . TBL_CMS_LAND . " L, " . TBL_CMS_LANG . " LNG
        ," . TBL_CMS_CUST . " K JOIN " . TBL_CMS_LAND . " LL ON (K.land_destination=LL.id) 
                WHERE K.land=L.id AND LNG.id=preferred_lang");
            header("Refresh: 1;  URL= " . $_SERVER['PHP_SELF'] . "?" . http_build_query($_REQUEST));
            $STATUSBAR = array('procent' => 100 / $VC['VCOUNT'] * ($_REQUEST['start'] - 100 + $pcount), 'done' => $_REQUEST['start'] - 100 + $pcount, 'total' => $VC['VCOUNT'],
                'timenow' => time(), 'rounds' => $_SESSION['STATUSBAR']['rounds'], 'timediff' => time() - $_SESSION['STATUSBAR']['starttime'], 'timediffmin' => round((time() -
                $_SESSION['STATUSBAR']['starttime']) / 60, 2), 'starttime' => $_SESSION['STATUSBAR']['starttime'], 'totaltime' => round(((((time() - $_SESSION['STATUSBAR']['starttime'])) /
                $_SESSION['STATUSBAR']['rounds']) * ($VC['VCOUNT'] / 100)) / 60, 2), 'resttime' => round((((((time() - $_SESSION['STATUSBAR']['starttime'])) / $_SESSION['STATUSBAR']['rounds']) *
                ($VC['VCOUNT'] / 100)) - (time() - $_SESSION['STATUSBAR']['starttime'])) / 60, 2));
            $this->smarty->assign('STATUSBAR', $STATUSBAR);
            $content .= '<% include file="statusbar.tpl" %>';
            include ("footer.php");
        }
        else {
            header("location: " . $_SERVER['PHP_SELF'] . "?setcmd=rp_regdatabase&epage=" . $_GET['epage'] . "&section=reports&msg=" . base64_encode("Datei erstellt."));
        }
        exit;
    }

    function cmd_rp_regdatabase() {
        if ($this->TCR->REQUEST['BUTTON'] == 'XLS') {
            $this->cmd_create_xls_regdb();
            return;
        }
        $orderby = strval($_GET['col']);
        $orderby = ($orderby == "") ? 'kid' : $orderby;
        $sql = "SELECT K.*,L.land,LL.land AS PREFDEST,LNG.post_lang FROM " . TBL_CMS_LAND . " L, " . TBL_CMS_LANG . " LNG
        ," . TBL_CMS_CUST . " K JOIN " . TBL_CMS_LAND . " LL ON (K.land_destination=LL.id) 
                WHERE K.land=L.id AND LNG.id=preferred_lang
				ORDER BY " . $orderby . " " . (($_GET['direc'] == 'ASC') ? 'ASC' : 'DESC') . "	
				LIMIT " . (int)$start . ",50";
        $result = $this->db->query($sql);
        #	echo $sql;
        $customers = array();
        while ($row = $this->db->fetch_array_names($result)) {
            $row['datum_ger'] = myDate('d.m.Y', $row['datum']);
            $row['lastvisit'] = date('d.m.Y', strtotime($row['lastvisit']));
            $customers[$row['kid']] = $row;
        }
        $VC = $this->db->query_first("SELECT COUNT(*) as VCOUNT FROM " . TBL_CMS_CUST);
        //sorting
        $direc = ($_GET['direc'] == 'ASC') ? 'DESC' : 'ASC';
        $this->smarty->assign('FILTER', array('direc' => $direc));
        $this->smarty->assign('QFILTER', $QFILTER);
        $this->smarty->assign('qfilter_query', http_build_query(array('QFILTER' => $QFILTER)));
        $this->COLOBJ['cu_list'] = $customers;
        $this->COLOBJ['cu_filtered_count'] = $VC['VCOUNT']; #$video_filtered_count;
        $this->COLOBJ['cu_totalcount'] = $VC['VCOUNT'];
        $this->genPaging($this->COLOBJ['cu_filtered_count'], $start, array('setcmd' => $this->TCR->REQUEST['setcmd'], 'section' => $this->TCR->REQUEST['section']));

    }

    function cmd_rp_grandoverview() {
        if ($this->TCR->REQUEST['BUTTON'] == 'XLS') {
            $this->cmd_create_xls();
            return;
        }
        $QFILTER = $this->TCR->REQUEST['QFILTER'];
        $start = (int)$this->TCR->REQUEST['start'];
        $videos = array();
        if (is_array($this->TCR->REQUEST['QFILTER'])) {
            $_SESSION['QFILTER'] = $this->TCR->REQUEST['QFILTER'];
        }
        else {
            $QFILTER = $_SESSION['QFILTER'];
        }
        $orderby = strval($_GET['col']);
        $orderby = ($orderby == "") ? 'V.yt_videotitle' : $orderby;
        $orderby = str_replace('V-', 'V.', $orderby);
        $orderby = str_replace('Q-', 'Q.', $orderby);
        $orderby = str_replace('L-', 'L.', $orderby);
        $videos = array();

        $sql_add = $this->build_grandview_sql($QFILTER);

        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID " . $sql_add . "	
				ORDER BY " . $orderby . " " . (($_GET['direc'] == 'ASC') ? 'ASC' : 'DESC') . "	
				LIMIT " . (int)$start . ",50";
        $result = $this->db->query($sql);
        #	echo $sql;
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $row['lastexec_datetime'] = ($row['yp_lastexec'] > 0) ? date('d.m.Y', $row['yp_lastexec']) : '-';
            $row['approved_date'] = ($row['yt_apptime'] > 0) ? date('d.m.Y', $row['yt_apptime']) : '-';
            if ($QFILTER['countryid'] == ALLCOUNTRYID) {
                // bestimme Land
                if (getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, 'vc_videoid', "vc_countryid=" . ALLCOUNTRYID . " AND vc_videoid='" . $row['yt_videoid'] . "'") == 1) {
                    $row['land'] = '{LA_ALLCOUNTRIES}';
                }
                else
                    if (getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, 'vc_videoid', "vc_videoid='" . $row['yt_videoid'] . "'") == 1) {
                        $COUNTRY = $this->db->query_first("SELECT L.* FROM  " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND .
                            " L WHERE VC.vc_countryid=L.id AND VC.vc_videoid='" . $row['yt_videoid'] . "'");
                        $row['land'] = $COUNTRY['land'];
                    }
                    else {
                        $row['land'] = 'some countries';
                    }

            }
            $videos[$row['VID']] = $row;
        }
        $VC = $this->db->query_first("SELECT COUNT(*) as VCOUNT " . $sql_add);


        //adding pathes & queries
        if (count($videos) > 0) {
            $pathes_by_videos = $this->load_video_pathes(0);
            foreach ($videos as $key => $V) {
                if (is_array($pathes_by_videos[$V['VID']]))
                    $videos[$key]['pathes'] = $pathes_by_videos[$V['VID']];
            }
        }

        //sorting
        $direc = ($_GET['direc'] == 'ASC') ? 'DESC' : 'ASC';
        $this->smarty->assign('FILTER', array('direc' => $direc));
        $this->smarty->assign('QFILTER', $QFILTER);
        $this->smarty->assign('qfilter_query', http_build_query(array('QFILTER' => $QFILTER)));
        $this->COLOBJ['video_list'] = $videos;
        $this->COLOBJ['video_filtered_count'] = $VC['VCOUNT']; #$video_filtered_count;
        $this->COLOBJ['video_totalcount'] = $VC['VCOUNT'];
        $this->genPaging($this->COLOBJ['video_filtered_count'], $start, array('setcmd' => $this->TCR->REQUEST['setcmd'], 'section' => $this->TCR->REQUEST['section']));
    }


    function create_xls($QFILTER, $start = -1) {
        $trenner = "\t";
        $start = (int)$start;
        $fields = array(array('label' => 'Video Source', 'sql' => 'yt_videosrcname'), array('label' => 'Country', 'sql' => 'land'), array('label' => 'WLU Query Title',
            'sql' => 'vp_queryname'), array('label' => 'Video Author', 'sql' => 'author'), array('label' => 'Video Title', 'sql' => 'yt_videotitle'), array('label' =>
            'WLU Categories', 'sql' => 'pathes'), array('label' => 'Language', 'sql' => 'yt_wlulng'), array('label' => 'Video Tags', 'sql' => 'vtags'), array('label' =>
            'Duration', 'sql' => 'yt_videoduration_min'), array('label' => 'Upload Date', 'sql' => 'yt_uploaddate'), array('label' => 'Last query run date', 'sql' =>
            'lastexec_datetime'), array('label' => 'Query Creator', 'sql' => 'vp_querycreator'), array('label' => 'Last run by', 'sql' => 'vp_lr_empname'), array('label' =>
            'Approved Date', 'sql' => 'approved_date'), array('label' => 'Views', 'sql' => 'yt_views'), array('label' => 'Comments', 'sql' => 'yt_comment_count'));

        $fname = CMS_ROOT . 'admin/cache/rp_grandoverview.xls';

        if ($start <= 0) {
            if (file_exists($fname))
                @unlink($fname);
        }

        $fp = fopen($fname, 'a');
        if ($start <= 0) {
            foreach ($fields as $ar)
                $f[] = $ar['label'];
            fputcsv($fp, $f, $trenner, '"');
        }

        $sql_add = $this->build_grandview_sql($QFILTER);
        $sql = "SELECT *,V.yt_videoid AS VID,C.id AS CID " . $sql_add . "
	ORDER BY V.yt_videotitle
	LIMIT " . (int)$start . ",100";
        $result = $this->db->query($sql);
        #	echo $sql;
        $pcount = 0;
        while ($row = $this->db->fetch_array_names($result)) {
            $this->set_video_options($row);
            $row['lastexec_datetime'] = ($row['yp_lastexec'] > 0) ? date('d.m.Y', $row['yp_lastexec']) : '-';
            $row['approved_date'] = ($row['yt_apptime'] > 0) ? date('d.m.Y', $row['yt_apptime']) : '-';
            if ($QFILTER['countryid'] == ALLCOUNTRYID) {
                // bestimme Land
                if (getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, 'vc_videoid', "vc_countryid=" . ALLCOUNTRYID . " AND vc_videoid='" . $row['yt_videoid'] . "'") == 1) {
                    $row['land'] = '{LA_ALLCOUNTRIES}';
                }
                else
                    if (getCount(TBL_CMS_WLU_VIDEO_TO_COUNTRY, 'vc_videoid', "vc_videoid='" . $row['yt_videoid'] . "'") == 1) {
                        $COUNTRY = $this->db->query_first("SELECT L.* FROM  " . TBL_CMS_WLU_VIDEO_TO_COUNTRY . " VC, " . TBL_CMS_LAND .
                            " L WHERE VC.vc_countryid=L.id AND VC.vc_videoid='" . $row['yt_videoid'] . "'");
                        $row['land'] = $COUNTRY['land'];
                    }
                    else {
                        $row['land'] = 'some countries';
                    }

            }
            //adding pathes & queries
            $pathes_by_videos = $this->load_video_pathes((int)$QFILTER['countryid']);
            if (is_array($pathes_by_videos[$row['VID']]))
                $row['pathes'] = $pathes_by_videos[$row['VID']];
            $row['pathes'] = implode('|', $row['pathes']);
            $f = array();
            foreach ($fields as $ar) {
                $value = utf8_decode($this->xml_xls_formated(strval($row[$ar['sql']])));
                if (strtotime($value) && strlen($value) == 10)
                    $f[] = date('d.m.Y', strtotime($value));
                else
                    $f[] = $value;
            }
            fputcsv($fp, $f, $trenner, '"');
            $pcount++;
        }
        fclose($fp);
        return $pcount;
    }

    function cmd_create_xls() {
        global $content, $db_zugriff, $smarty, $crj_obj;
        if ($_REQUEST['start'] == 0) {
            $_SESSION['STATUSBAR']['starttime'] = time();
            $_SESSION['STATUSBAR']['rounds'] = 0;
        }
        $_SESSION['STATUSBAR']['rounds']++;
        $QFILTER = $this->TCR->REQUEST['QFILTER'];
        $pcount = $this->create_xls($QFILTER, $_REQUEST['start']);
        if ($pcount > 0) {
            $_REQUEST['start'] += 100;
            $sql_add = $this->build_grandview_sql($QFILTER);
            $VC = $this->db->query_first("SELECT COUNT(*) as VCOUNT " . $sql_add);
            header("Refresh: 1;  URL= " . $_SERVER['PHP_SELF'] . "?" . http_build_query($_REQUEST));
            $STATUSBAR = array('procent' => 100 / $VC['VCOUNT'] * ($_REQUEST['start'] - 100 + $pcount), 'done' => $_REQUEST['start'] - 100 + $pcount, 'total' => $VC['VCOUNT'],
                'timenow' => time(), 'rounds' => $_SESSION['STATUSBAR']['rounds'], 'timediff' => time() - $_SESSION['STATUSBAR']['starttime'], 'timediffmin' => round((time() -
                $_SESSION['STATUSBAR']['starttime']) / 60, 2), 'starttime' => $_SESSION['STATUSBAR']['starttime'], 'totaltime' => round(((((time() - $_SESSION['STATUSBAR']['starttime'])) /
                $_SESSION['STATUSBAR']['rounds']) * ($VC['VCOUNT'] / 100)) / 60, 2), 'resttime' => round((((((time() - $_SESSION['STATUSBAR']['starttime'])) / $_SESSION['STATUSBAR']['rounds']) *
                ($VC['VCOUNT'] / 100)) - (time() - $_SESSION['STATUSBAR']['starttime'])) / 60, 2));
            $this->smarty->assign('STATUSBAR', $STATUSBAR);
            $content .= '<% include file="statusbar.tpl" %>';
            include ("footer.php");
        }
        else {
            header("location: " . $_SERVER['PHP_SELF'] . "?setcmd=rp_grandoverview&epage=" . $_GET['epage'] . "&section=reports&msg=" . base64_encode("Datei erstellt."));
        }
        exit;
    }

    function cmd_get_xls_file() {
        echo_excel_header($this->TCR->GET['fname']);
        echo file_get_contents(CMS_ROOT . 'admin/cache/' . $this->TCR->GET['fname'] . '.xls');
        exit;
    }

    function cmd_save_link() {
        $this->RL = new wlu_relatedlinks_class();
        $this->RL->load_locations();
        $locations = (array )$this->TCR->POST['LOCATIONS'];
        if (count($locations) == 0) {
            $result = $this->db->query("SELECT * FROM " . TBL_CMS_LAND . " L, " . TBL_CMS_WLU_COUNTRY_TO_CAT . " CL 
		WHERE CL.cm_countryid=L.id 
		AND CL.cm_cid=" . (int)$this->TCR->POST['id'] . "
		ORDER BY land");
            while ($row = $this->db->fetch_array_names($result)) {
                if ($this->RL->RELLINK['ccodes'][$row['country_code_2']] != "")
                    $locations[$row['country_code_2']] = $row['country_code_2'];
            }
        }
        $linkid = $this->RL->save_link($this->TCR->POST['RL'], 0, $_FILES, $locations);
        $this->RL->set_link_to_cat($linkid, $this->TCR->POST['id']);
        $this->TCR->reset_cmd('catedit');
        $this->TCR->add_url_tag('section', 'cats');
        $this->TCR->add_url_tag('id', $this->TCR->POST['id']);
        $this->TCR->add_msg('{LBL_SAVED}');
    }

    function cmd_catadd() {
        $this->cmd_catedit();
    }

    function cmd_catedit() {
        $this->RL = new wlu_relatedlinks_class();
        $rel = array();
        $this->RL->set_link_opt($rel);
        $this->RL->RELLINK['rl'] = $rel;
        $this->RL->load_locations();
        if ($this->TCR->GET['id'] > 0)
            $this->RL->load_links(array('cid' => $this->TCR->GET['id']), 0, '', 'ASC');
        $this->RL->parse_to_smarty();
    }

    function cmd_aws_video_search() {
        $this->s3->aws_file_search($this->TCR->REQUEST['bucket'], $this->TCR->REQUEST['word']);
        $this->parse_to_smarty();
        #echoarr($this->s3->S3O['aws_file_list']);
        ECHORESULTCOMPILED('<% include file="wlu_aws.videosearchtable.tpl" %>');
    }

    function replace_extension($filename) {
        $info = pathinfo($filename);
        return $info['filename'];
    }


    function cmd_aws_setvideo() {
        $this->load_adhoc_video($this->TCR->REQUEST['id']);
        $file = base64_decode($this->TCR->REQUEST['file']);
        $this->s3->aws_get_file_metadata($this->TCR->REQUEST['bucket'], $file);

        $mapping = array('file_name' => 'yt_videotitle', 'file_name' => 'yt_videosrcname', 'file_url' => 'yt_videourl', 'lastmod_date_short' => 'yt_lastupdate', );
        foreach ($mapping as $key => $v) {
            $this->s3->S3O['aws_file_metadata'][$v] = $this->s3->S3O['aws_file_metadata'][$key];
            $this->COLOBJ['adhocvideo'][$v] = $this->s3->S3O['aws_file_metadata'][$key];
        }
        $this->COLOBJ['adhocvideo']['yt_videotitle'] = $this->replace_extension(basename($this->s3->S3O['aws_file_metadata']['file_name']));
        $this->COLOBJ['adhocvideo']['yt_videosrcname'] = 'WiLinkU';
        $this->COLOBJ['adhocvideo']['yt_aws_file'] = $file;
        $this->COLOBJ['adhocvideo']['yt_videoahtags'] = implode(',', explode(' ', $this->gen_plain_text($this->COLOBJ['adhocvideo']['yt_videotitle'])));
        $this->load_iso_table();
        $this->parse_to_smarty();
        #echoarr($this->COLOBJ['adhocvideo']);
        ECHORESULTCOMPILED('<% include file="wlu_adhoc.aws.editor.tpl" %>');
    }

    function cmd_aws_grab_thumbail() {
        $id = $this->TCR->REQUEST['id'];
        $this->load_adhoc_video($id);
        include_once (CMS_ROOT . 'includes/modules/wilinku/wlu_videopic.class.php');
        $VIMG = new wlu_videopic_class();
        $this->set_video_options($this->COLOBJ['adhocvideo']); // set signed URL
        $fname = $VIMG->gen_thumbnail_from_video($this->COLOBJ['adhocvideo']['yt_videourl']);
        unset($VIMG);

        $new_file_name = CMS_ROOT . VIDEOTHUMB_PATH . 'video_thumb_' . $id . '.jpg';
        if (file_exists(CMS_ROOT . 'cache/' . $fname)) {
            copy(CMS_ROOT . 'cache/' . $fname, $new_file_name);
            @unlink(CMS_ROOT . 'cache/' . $fname);
        }
        clean_cache_like($new_file_name);
        if (file_exists($new_file_name)) {
            chmod($new_file_name, 0755);
            $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_preview='" . basename($new_file_name) . "' WHERE yt_videoid='" . $id . "' LIMIT 1");
        }
        $this->COLOBJ['rnd'] = rand(1, 100000);
        $this->load_iso_table();
        $this->parse_to_smarty();
        #echoarr($this->COLOBJ['adhocvideo']);
        ECHORESULTCOMPILED('<% include file="wlu_adhoc.aws.editor.tpl" %>');
    }

    function cmd_delete_video_thumb() {
        $V = $this->db->query_first("SELECT * FROM " . TBL_CMS_WLU_APPROVED_VIDEOS . " WHERE yt_videoid='" . $this->TCR->GET['id'] . "'");
        delete_file(CMS_ROOT . VIDEOTHUMB_PATH . $V['yt_preview']);
        $this->db->query("UPDATE " . TBL_CMS_WLU_APPROVED_VIDEOS . " SET yt_preview='' WHERE yt_videoid='" . $this->TCR->GET['id'] . "' LIMIT 1");
        exit;
    }

} //CLASS


?>
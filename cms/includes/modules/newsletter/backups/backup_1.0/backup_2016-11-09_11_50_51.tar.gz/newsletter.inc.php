<?php



/**
 * @package    newsletter
 *
 * @copyright  Copyright (C) 2006 - 2016 Trebaxa GmbH&Co.KG. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 * @version    1.0
 */
# Or visit our hompage at www.trebaxa.com									  *


$NEWSLETTER_OBJ = new newsletter_class();
$NEWSLETTER_OBJ->TCR->interpreterfe();
$NEWSLETTER_OBJ->parse_to_smarty();

?>
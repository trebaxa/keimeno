<?php

/**
 * @package    forum
 *
 * @copyright  Copyright (C) 2006 - 2016 Trebaxa GmbH&Co.KG. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 * @version    1.0
 */


class forum_search_class extends forum_master_class {
    var $html = "";
    var $langid = 1;
    var $wordscores = array();
    var $blocklist = array();
    var $metas = array();
    var $wortvorkommen = array();
    var $SEO = array();
    var $bonus = array(        
        'h1' => 6,        
        'b' => 5,
        'code' => 4,        
        'legend' => 2,
        'a' =>  1       
        );

    /**
     * forum_search_class::__construct()
     * 
     * @return void
     */
    function __construct() {
        parent::__construct();
    }

    /**
     * forum_search_class::get_words_width_score()
     * 
     * @return void
     */
    function get_words_width_score($inhalt) {
        foreach (array_keys($this->bonus) as $tag) {            
            preg_match_all('/\[' . $tag . '\](.*?)\[\/' . $tag . ']/s', $inhalt, $hits);        
            foreach ($hits[0] as $el) {
                $this->fetch_words($el, $this->bonus[$tag]);
            }
        }
        $this->fetch_words($inhalt, 0);
        
    }

    /**
     * forum_search_class::fetch_words()
     * 
     * @param mixed $_inhalt
     * @param mixed $_score
     * @return void
     */
    function fetch_words($_inhalt, $_score) {
        $_inhalt = mb_strtolower(html_entity_decode($_inhalt, ENT_COMPAT, 'UTF-8'), "UTF-8");
        $_inhalt = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $_inhalt);
        $_inhalt = strip_tags($_inhalt);
        $_inhalt = preg_replace('/\[^\pL]/u', ' ', $_inhalt); //UTF8 kompatibel, umlaute bleiben erhalten
        $_inhalt = preg_replace('/[^\w\pL]/u', ' ', $_inhalt); // entferhnt nun hier sauber alle Satzzeichen
        $words = preg_split('/\s+/', trim($_inhalt));

        # wort h�ufigkeit
        $word_count = array_count_values($words);
        $words = array_unique($words);
        foreach ($words as $word) {
            $word = trim($word);
            if (strlen($word) < 4 )
                continue;
            if (is_numeric($word))
                continue;
            if (in_array($word, $this->blocklist))
                continue;
            // plain text add
            $result = $this->db->query("SELECT id FROM " . TBL_CMS_FORUMSWORDS . " WHERE si_word='" . ($word) . "' COLLATE utf8_bin");
            $word_obj = mysqli_fetch_object($result);
            if ($word_obj->id == 0) {
                $this->word_id = insert_table(TBL_CMS_FORUMSWORDS, array('si_word' => $word));
            }
            else
                $this->word_id = $word_obj->id;
            if (!isset($this->wortvorkommen[$this->word_id]))
                $this->wortvorkommen[$this->word_id] = 0;
            $this->wortvorkommen[$this->word_id] += $_score;
            if (!empty($word)) {
                $this->wordscores[$this->word_id] = array(
                    'score' => $this->wortvorkommen[$this->word_id],
                    'word' => $word,
                    'count' => (int)$word_count[$word]);
            }
        }
    }

    /**
     * forum_search_class::analyse()
     * 
     * @return void
     */
    function analyse($inhalt, $themeid) {
        $this->get_words_width_score($inhalt);
        $this->db->query("DELETE FROM " . TBL_CMS_FORUMSREL . " WHERE sr_themeid=" . $themeid . "
				OR (sr_inserttime>0 AND sr_inserttime<" . (time() - (60 * 60 * 24 * 30 * 12)) . ")"); // aelter 12 Monat
        if (is_array($this->wortvorkommen)) {
            foreach ($this->wortvorkommen as $wordid => $score) {
                $WREL = array(
                    'sr_word_id' => (int)$wordid,
                    'sr_score' => (int)$score,
                    'sr_themeid' => (int)$themeid,
                    'sr_inserttime' => time());
                insert_table(TBL_CMS_FORUMSREL, $WREL);
            }
        }


    }

    /**
     * forum_search_class::index_theme()
     * 
     * @param mixed $themeid
     * @return void
     */
    function index_theme($themeid) {
        $THEME = $this->load_theme_by_id($themeid);
        $inhalt = '[h1]' . $THEME['t_name'] . '[/h1]';
        $threads = $this->load_threads_by_theme($themeid, 0, 30);
        foreach ($threads as $row) {
            $inhalt .= $row['f_text'] . ' ';
        }        
        
        $this->analyse($inhalt, $themeid);
    }
}
